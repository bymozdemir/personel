# 2.3.31 — Sahiplenilmiş pozisyon rotasyonu geri getirildi

**Sorun:** 2.3.30'da hesapta 60 sahiplenilmiş coin varken otonom alım limiti 32 olduğundan `resolveAutonomousPhase` yeni alım slotunu 0 yapıyordu (log: `60/32 coin yönetiliyor… yeni otonom alım sınırı açılmadı`). 2.3.19'daki `engine.rotateAdopted()` çağrısı `server.js`'ten kalkmıştı; bu yüzden yönetilen sayı 32'nin altına inene kadar hiç alım yapılmıyordu.

**Değişiklik:**
- `server.js`: otonom taramada, canlı modda, alım sinyali olup slot/nakit yüzünden bekleyen aday varsa `rotateAdopted` yeniden çağrılıyor (2.3.19 davranışı).
- `liveEngine.rotateAdopted`: tarama başına en fazla 3 (`maxPerScan`, eskiden 2), günde en fazla 30 (`ADOPT_MAX_ROTATIONS_PER_DAY`, eskiden 10) rotasyon satışı; bekleyen aday sayısını da aşmaz. Gün sınırı İstanbul saatine göre sıfırlanır.
- Değişmeyenler: yalnızca sahiplenilmiş (adopted) pozisyonlar, alım sinyali OLMAYANLAR, en az 10 dk tutulmuş olanlar, en büyük değerden başlanarak satılır; `safeToTrade`/kill switch kapıları geçerli. Botun kendi açtığı pozisyonlar rotasyonla satılmaz. Stop, kâr ve strateji çıkışları normal çalışmaya devam eder.
- Test güncellendi: `holdingsAdoption.test.js` (tarama başı 3, günlük 30).

**Doğrulama:** Kullanıcı tam test paketini çalıştırdı ve hatasız geçti bildirdi. Bu yamadan sonra ilgili testler (holdingsAdoption, autonomousScanner, liveAutonomousManagement, autonomousPhase) 57/57 geçti.
