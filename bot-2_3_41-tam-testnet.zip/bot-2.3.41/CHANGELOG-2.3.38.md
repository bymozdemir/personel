# 2.3.38 — 2.3.37 (kullanıcı) + 2.3.36 sessiz dolum kilidi + durdurma-devam düzeltmesi

**Birleştirme:** Kullanıcının 2.3.37 paketi (2.3.35 tabanlı: güvenli durdurma yarışı düzeltmesi, durdurmayı iptal edip devam etme, manuel/dış satış algılama) ile aynı numarayı kullanan ayrı bir 2.3.36 değişikliği (emir dolumu sonrası kısa mutabakat kilidinin bildirimi 5 dakikayı aşmadıkça sessiz) çakışmasız birleştirildi. Kullanıcı sürümünde `liveEngine.js` ve `test/liveNotifications.test.js` 2.3.35 ile aynıydı.

**Düzeltme (`server.js`, `resumeAutonomousStop`):** Durdurmayı iptal edip devam ederken `a.selectedCount` güncelleniyor ama portföy kapısı `state.settings.maxConcurrentPositions` eski değerde kalıyordu (normal başlatma yolu ikisini birlikte ayarlıyor). Artık devamda da eşitleniyor; `previousMaxConcurrentPositions` değişmiyor.

**Bilinen eksik (kullanıcının notuyla aynı, bu sürümde çözülmedi):** Manuel/dış satış algılama yalnızca kaydediyor ve kapıyı geçici kapatıyor. `manualExternalSaleReviewRequired` ve `externalManualSalesPending` kodun başka hiçbir yerinde okunmuyor; bir sonraki mutabakat `safeToTrade`'i yeniden `true` yapabiliyor ve kayıt `awaiting_rest_verification` durumunda kalıyor. Canlı kullanım için hazır sayılmamalı (bkz. MANUAL-SELL-IMPLEMENTATION-NOTE.md).

**Testler:** Bu ortamda tüm `test/*.test.js`: 1411 testten 1410 geçti. Kalan `serverIntegration.test.js` bu ortamda `node_modules` olmadığı için hem 2.3.37 hem 2.3.38'de aynı şekilde başarısız. Telefonda `npm test` çalıştırılmalı. Durdurma-devam akışı (`server.js`) birim testle kapsanmıyor, yalnızca kod okuma ve söz dizimi ile doğrulandı.
