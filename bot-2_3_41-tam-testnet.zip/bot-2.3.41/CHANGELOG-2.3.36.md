# 2.3.36 — Otonom güvenli durdurma sonrası yeniden başlatma yarışı düzeltmesi

- Otonom durdurma sırasında devam eden piyasa taraması bitmeden oturumun `idle` durumuna geçmesi engellendi.
- Tarama sırasında durdurma isteği gelirse, uygunluk/bütçe kontrolü veya rotasyon beklemesinden sonra eski taramanın yeni alım/portföy değişikliği akışına devam etmesi engellendi.
- Durdurma ancak devam eden tarama çıktıktan ve açık pozisyonlar kapandıktan sonra tamamlanır. Bu noktada manuel ayarlar geri yüklenir ve `stopping=false`, `active=false`, `status=idle` olur; otonom yeniden başlatılabilir.
- Açık pozisyonların stop/çıkış yönetimi sürdürülür; bu değişiklik mevcut emirleri iptal etmez veya pozisyonları zorla kapatmaz.
