# 2.3.21 — Termux/Testnet log follow-up and rotation-policy correction

## Intended behavior confirmed by the operator
- The bot starts in Paper mode by default. The operator then saves Binance Spot Testnet API credentials in the panel and explicitly switches the panel to Live/Testnet. The initial Paper boot log followed by later Live engine/order logs is consistent with this intended sequence; it is not, by itself, a mode-transition defect.
- The 60-coin limit is a concurrent tracking/management ceiling, not a permanent whitelist of the first 60 assets. The scanner discovers the broader eligible quote-market universe; when a tracked position exits, candidates outside the currently tracked set can fill the available capacity. When tracked count falls below the limit, the full eligible universe is scanned again for current buy signals.
- If an adopted asset has no known historical entry cost, assigning its first observed market price as the reference entry cost is intentional. Its displayed P/L is therefore measured from adoption time, not the original exchange purchase.

## Changes retained from 2.3.20
- Binance public market-data request budget default increased from 22s to 30s. The first endpoint attempt now receives up to 12s (previously 8s); retry is used only when the remaining total budget permits it. Signed/private order request timeouts are unchanged.
- Network timeout diagnostics report configured DNS order and no longer imply that timeout alone proves an IPv6 fault.
- Failed account reconciliation records the first concrete reconciliation blocker in `live.lockReason` instead of leaving only a generic balance-reconciliation message.

## 2.3.21 rotation correction
- Re-evaluation found that 2.3.20's rotation gate was too restrictive for the intended portfolio behavior: if an available tracking slot existed but quote cash was tied up in adopted holdings, the allocator could select zero new entries and the bot would not rotate an adopted holding to free cash.
- The allocator now reports how many candidates were blocked specifically by spendable quote cash (`cashBlockedCandidates`). It does not count candidates blocked because the exchange minimum is above `maxTradeQuote`, symbol rules could not be fetched, or the live balance is unknown.
- Rotation may now free an adopted, non-buy-signal position when there is a real waiting buy signal and (a) the tracking slots are full, (b) at least one candidate was allocated, or (c) candidates were specifically blocked by available quote cash. The live quote balance must be known; an unknown balance does not trigger liquidation.
- If a candidate cannot be bought because its minimum order exceeds the configured per-trade cap, that alone does not trigger a sale. Rotation remains bounded by the existing per-scan and per-day limits and only considers adopted holdings without a current buy signal.
- After a rotation sale, the next autonomous scan re-runs allocation using the newly available quote balance; this avoids pretending that the pre-sale allocation already funded a buy.

## Validation
- Offline preflight: passed (6 critical files; 19 strategy defaults valid; Paper remains the default; no obvious source secrets).
- Focused tests after the correction: allocator 9/9, autonomous scanner 16/16, holdings adoption 32/32 (57/57 total).
- The 2.3.20 network/reconciliation/live-engine focused test set remains unchanged; full test suite and real Binance Spot Testnet order execution were not completed in this environment.
- No API credentials, `.env`, `data/`, runtime state, logs, or `node_modules` are included in the source archive.

## Log limitations
- The supplied logs showed 60 non-stablecoin assets adopted with first-observed prices as reference cost basis; this is intentional per operator clarification, but is not historical purchase cost.
- `Stop UNKNOWN` events were later followed by logs showing existing exchange protective stops attached. That demonstrates eventual recovery in those examples, not continuous protection during the interval.
- The two historical balance-reconciliation lock periods lasted about 99 and 49 minutes. The supplied excerpts did not contain the concrete reconciliation errors, so their exact historical root cause cannot be proven retrospectively. 2.3.20+ records concrete blockers on subsequent occurrences.
- The repeated Telegram `fetch failed` indicates a separate Telegram/network connectivity issue; it does not itself prove an exchange order failure.
