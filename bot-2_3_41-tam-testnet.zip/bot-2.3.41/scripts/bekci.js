#!/usr/bin/env node
'use strict';
// scripts/bekci.js — yerel bekçi (watchdog). Botun KENDİ sürecinden bağımsız çalışır.
//
// data/runtime-marker.json dosyasındaki "lastAliveAt" nabzını (bot dakikada bir yazar) izler. Nabız 5 dakikadan eskiyse ve bot
// temiz kapanmadıysa (cleanExit=false) Telegram'a ve telefon bildirimine "BOT NABZI KESİLDİ" gönderir; nabız dönünce haber verir.
// Sınır: Telefon tamamen kapanır ya da internet giderse bu betik de durur. Onu yalnızca dışarıdaki bir izleyici (ör. HEALTHCHECK_URL) yakalar.
//
// Çalıştırma (ayrı Termux oturumunda):  node scripts/bekci.js
//   BEKCI_STALE_MIN=5       nabız kaç dakika eskirse alarm (varsayılan 5)
//   BEKCI_POLL_SEC=120      kontrol aralığı (varsayılan 120)
//   BEKCI_REPEAT_MIN=30     alarm sürerse tekrar hatırlatma aralığı (varsayılan 30)
// Telegram için bot klasöründeki .env içindeki TELEGRAM_BOT_TOKEN ve TELEGRAM_CHAT_ID kullanılır (ekrana yazdırılmaz).

const fs = require('fs');
const path = require('path');
const https = require('https');
const { spawn } = require('child_process');

const ROOT = path.join(__dirname, '..');

function parseEnv(text) {
  const out = {};
  for (const raw of String(text || '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const i = line.indexOf('=');
    if (i < 1) continue;
    let v = line.slice(i + 1).trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    out[line.slice(0, i).trim()] = v;
  }
  return out;
}

// Saf karar fonksiyonu: { action: 'dead'|'repeat'|'recovered'|null, ageMs }
function decide({ now, marker, prev = { alerted: false, lastAlertAt: 0 }, staleMs = 5 * 60000, repeatMs = 30 * 60000 }) {
  if (!marker || !Number.isFinite(Number(marker.lastAliveAt))) return { action: null, ageMs: null, reason: 'marker-yok' };
  const ageMs = now - Number(marker.lastAliveAt);
  if (marker.cleanExit === true) return { action: null, ageMs, reason: 'temiz-kapanis' };
  if (ageMs > staleMs) {
    if (!prev.alerted) return { action: 'dead', ageMs };
    if (now - prev.lastAlertAt >= repeatMs) return { action: 'repeat', ageMs };
    return { action: null, ageMs, reason: 'alarm-verildi' };
  }
  return prev.alerted ? { action: 'recovered', ageMs } : { action: null, ageMs };
}

function messageFor(action, ageMs) {
  const dk = ageMs === null ? '?' : Math.round(ageMs / 60000);
  if (action === 'recovered') return '✅ BOT NABZI GERİ GELDİ — bot yeniden çalışıyor.';
  return `🚨 BOT NABZI KESİLDİ — son nabız ${dk} dakika önce. Bot çökmüş ya da donmuş olabilir; Termux'ı kontrol edin.${action === 'repeat' ? ' (hatırlatma)' : ''}`;
}

function telegram(token, chatId, text) {
  return new Promise((resolve) => {
    if (!token || !chatId) return resolve(false);
    const body = JSON.stringify({ chat_id: chatId, text });
    const req = https.request({ hostname: 'api.telegram.org', path: `/bot${token}/sendMessage`, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }, timeout: 15000 },
      (res) => { res.resume(); resolve(res.statusCode === 200); });
    req.on('error', () => resolve(false)); req.on('timeout', () => { req.destroy(); resolve(false); });
    req.write(body); req.end();
  });
}

function termuxNotify(title, text) {
  return new Promise((resolve) => {
    try {
      const p = spawn('termux-notification', ['--title', title, '--content', text, '--priority', 'high'], { stdio: 'ignore' });
      p.on('error', () => resolve(false)); p.on('exit', (c) => resolve(c === 0));
    } catch { resolve(false); }
  });
}

function readMarker(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
}

async function main() {
  const env = { ...parseEnv((() => { try { return fs.readFileSync(path.join(ROOT, '.env'), 'utf8'); } catch { return ''; } })()), ...process.env };
  const markerFile = path.join(ROOT, 'data', 'runtime-marker.json');
  const staleMs = Math.max(1, Number(env.BEKCI_STALE_MIN) || 5) * 60000;
  const pollMs = Math.max(10, Number(env.BEKCI_POLL_SEC) || 120) * 1000;
  const repeatMs = Math.max(1, Number(env.BEKCI_REPEAT_MIN) || 30) * 60000;
  let prev = { alerted: false, lastAlertAt: 0 };
  console.log(`[bekci] basladi: nabiz esigi ${staleMs / 60000} dk, kontrol ${pollMs / 1000} sn, telegram=${Boolean(env.TELEGRAM_BOT_TOKEN && env.TELEGRAM_CHAT_ID)}`);
  const check = async () => {
    const now = Date.now();
    const d = decide({ now, marker: readMarker(markerFile), prev, staleMs, repeatMs });
    if (!d.action) return;
    const text = messageFor(d.action, d.ageMs);
    const ok = await telegram(env.TELEGRAM_BOT_TOKEN, env.TELEGRAM_CHAT_ID, text);
    await termuxNotify('AL-SAT bekçi', text);
    console.log(`[bekci] ${new Date(now).toISOString()} ${d.action} telegram=${ok}`);
    prev = d.action === 'recovered' ? { alerted: false, lastAlertAt: 0 } : { alerted: true, lastAlertAt: now };
  };
  await check();
  setInterval(() => { check().catch(() => {}); }, pollMs);
}

if (require.main === module) main();
module.exports = { parseEnv, decide, messageFor };
