# 2.3.30 — relaxed autonomous management selection

- Restored the 2.3.19 two-stage management profile selection: strict historical candidates are always preferred; only when none pass does the scanner rank relaxed candidates from the same closed-candle history.
- Relaxed selection requires at least one simulated trade and finite return/drawdown metrics. It is marked `relaxed: true` so the existing live-engine hysteresis can replace it immediately when a strict profile later appears.
- Preserved the 2.3.30 scan deadline, fresh-candle checks, incomplete-scan rejection, score hysteresis, exchange stop protection, order sizing, risk gates, and Testnet-only production lock.
- New installs copy `.env.example` with Binance Spot Testnet live permission enabled (`LIVE_TRADING_ENABLED=true`, `BINANCE_ENV=testnet`, `ALLOW_BINANCE_TESTNET_TRADING=true`, `ALLOW_PRODUCTION_TRADING=false`). The bot still starts in paper mode; live mode must be selected explicitly in the panel/Telegram flow. Production trading remains disabled.
- No position cap or 60/32 setting was changed.

Validation run:
- `node --test test/autonomousScanner.test.js test/liveAutonomousManagement.test.js`: 20/20 passed.
- `npm run preflight`: passed.
- Full `npm test` and isolated batched suite did not complete within the execution time limit; no full-suite pass is claimed.
