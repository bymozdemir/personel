# Autonomous live-balance allocator fix — 2.3.13

- Fixed live quote-balance parsing for Binance and reconciliation asset-keyed balance maps (`{ USDT: { free, locked } }`).
- Kept compatibility with array-shaped balance snapshots.
- Added regression coverage for object-shaped Binance balances and live candidate allocation.
- Focused regression suite: `node --test test/autonomousCapitalAllocator.test.js` (6/6 passed).

This patch does not change API credentials, exchange environment, trading-mode flags, risk limits, or existing orders. It only corrects how the autonomous allocator reads the already-reconciled free quote balance.
