# Bot 2.3.22 — Testnet hediye bakiyesi / otonom alım eşiği

## İstenen çalışma modeli

1. Binance Testnet hesabında hazır bulunan coinler kullanıcı tarafından satın alınmış sayılmaz; bot bunları mevcut hesap bakiyesi olarak devralır.
2. Gerçek alış maliyeti bilinmiyorsa ilk görülen piyasa fiyatı referans maliyet olarak kullanılır.
3. Bot bütün uygun USDT piyasa evrenini taramaya devam eder; tarama ve alım izni birbirinden ayrıdır.
4. Sahiplenilmiş açık pozisyon sayısı kullanıcının seçtiği 1/2/4/8/16/32 sınırına eşit veya yüksekken yeni otonom alış slotu açılmaz.
5. Bu aşamada sahiplenilmiş coinler yalnızca kendi strateji/stop/çıkış sinyalleriyle satılır. Tarama sonucu daha iyi aday bulundu diye hediye coinleri erken satılmaz.
6. Bir hediye coin satıldığında, borsadaki diğer uygun ve henüz sahiplenilmemiş bakiyeler 60 pozisyonluk sahiplenme kapasitesi dolana kadar sırayla devralınır.
7. Sahiplenilmiş açık pozisyon sayısı seçilen sınırın altına düştüğünde otonom yeni alım slotu açılır. Bot sıraladığı fırsatlardan coin, strateji ve mum aralığını seçer. LiveEngine'in ayrıca mevcut maxConcurrentPositions güvenlik kontrolü devam eder.

## Kod değişiklikleri

- `src/autonomousPhase.js` eklendi. Hediye-bakiye yönetimi ile otonom yeni-alım aşamasını açık ve test edilebilir şekilde ayırır.
- `server.js` piyasa taramasını olduğu gibi sürekli çalıştırır; yeni alım kapasitesini `selectedCount - allCurrentlyOpenPositions` olarak hesaplar. İlk taramada otonom başlatılmadan önce açık olanlar dahil tüm mevcut pozisyonlar sayılır. Açık pozisyonlar `enabled=false` kalır (pozisyon oldukları için yine yönetilir); yalnızca tarayıcının bu turda seçtiği boş aday yeni girişe açılır. Böylece kapanan eski hediye coin, yeni tarama seçmeden eski profiliyle tekrar alınmaz.
- Önceki sürümde tarama sırasında çağrılan `rotateAdopted()` yolu kaldırıldı. Böylece yalnızca daha iyi aday beklediği için Binance'in verdiği pozisyonları erkenden satan rotasyon yapılmaz.
- `LiveEngine._adoptExistingHoldings()` davranışı korunmuştur: sahiplenme üst sınırı 60'tır ve her tick'te tekrar çalıştığı için satılan hediye varlığın ardından sıradaki uygun hesap bakiyesi devralınabilir.
- Panel durum mesajı hediye-bakiye yönetimi veya otonom alım aşamasını açıklar.
- `package.json` ve `package-lock.json` sürümü 2.3.22 olarak güncellendi.

## Doğrulama

- 118 odaklı Node.js testi: başarılı (0 başarısız).
- 287 JavaScript dosyası: `node --check` başarılı.

- Offline preflight: başarılı.
- Otonom aşama ve tarayıcı testleri: başarılı.
- LiveEngine, recovery ve reconciliation testleri: başarılı.
- Hediye bakiyenin satışından sonra sıradaki varlığın devralınması için test eklendi.
- Gerçek Binance Testnet emirleri bu geliştirme ortamında gönderilmedi; kısmi dolum, telefon kapalıyken stop ve canlı Testnet uçtan uca doğrulaması ayrıca yapılmalıdır.
