# 2.3.33 — Saat başı rapor + yerel bekçi

**Saat başı rapor (`src/hourlyReport.js`, `server.js`):** İstanbul saatiyle her saatin ilk 20 dakikasında, saat başına bir kez sessiz Telegram (ve Termux) mesajı: "🕐 SAAT BAŞI RAPORU — ✅ Sağlıklıyım, çalışıyorum." İçerik: son kontrol, açık pozisyon (sahiplenilmiş / botun kendi aldığı), yönetilen N/32, son 1 saatte alım / satış (K/Z) / sahiplenme sayısı, bugünkü rotasyon satışı, özkaynak, son kayıtlardaki hata/uyarı sayısı. Bot durmuşsa, kill switch açıksa, canlı işlem kilitliyse, son kontrol 15 dakikadan eskiyse veya bekleyen bildirim varsa başlık "⚠️ DİKKAT" olur. `HOURLY_REPORT=0` ile kapanır. Yeniden başlatma aynı saat için ikinci rapor üretmez (`state.notifyMeta.lastHourlyReportKey`).

**Yerel bekçi (`scripts/bekci.js`, `npm run bekci`):** Botun sürecinden bağımsız çalışan küçük Node betiği. `data/runtime-marker.json` içindeki dakikalık nabzı izler; 5 dakikadan eskiyse (ve bot temiz kapanmadıysa) Telegram + telefon bildirimiyle "BOT NABZI KESİLDİ" der, 30 dakikada bir hatırlatır, nabız dönünce haber verir. Ayarlar: `BEKCI_STALE_MIN`, `BEKCI_POLL_SEC`, `BEKCI_REPEAT_MIN`. Sınır: telefon tamamen kapanırsa veya internet giderse bekçi de durur; bunu yalnızca dışarıdaki bir izleyici (`HEALTHCHECK_URL`) yakalar.

**Değişmeyenler:** Rotasyon, sahiplenme sınırı (2.3.32), alım/satış mantığı, portföy kapıları.

**Testler:** `test/hourlyReport.test.js` (5 test). Bu ortamda tüm `test/*.test.js` dosyaları çalıştırıldı: 1402 testten 1401 geçti; `serverIntegration.test.js` (gerçek server.js'i başlatan test) bu ortamda `node_modules` olmadığı için 2.3.32'de de aynı şekilde başarısız; `npm test`'i telefonda çalıştırmanız gerekir.
