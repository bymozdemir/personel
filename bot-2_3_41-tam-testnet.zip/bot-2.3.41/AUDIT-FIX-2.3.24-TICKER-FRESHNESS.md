# Binance ticker freshness fix — Bot 2.3.24

## Scope
Based on the 2.3.23 merged source. This release changes only Binance's all-symbol 24-hour ticker cache behavior and package version metadata.

## Changes
- Reduced the default successful ticker cache lifetime from 30 seconds to 10 seconds.
- Added `BINANCE_TICKER_CACHE_TTL_MS` (or adapter option `tickerCacheTtlMs`) to tune the cache lifetime, clamped to 1–30 seconds.
- Removed the 15-minute stale ticker fallback completely. When a refresh fails after the short cache expires, the request now fails and the caller must defer its scan/audit/reconciliation work rather than make decisions using old market-wide price/volume data.
- Restored in-flight request coalescing: concurrent scanner, account-audit and reconciliation calls share one Binance ticker request instead of issuing duplicate heavy requests.
- Rejects malformed or empty ticker responses and does not cache them.
- Preserved the 2.3.23 Binance public request timeout/fallback behavior and all autonomous phase / selected-position-count logic.

## Validation
- `node scripts/offlinePreflight.js`: passed (6 critical files, 19 strategy defaults, Paper default, live safety lock off, no obvious source secrets).
- Focused tests: 113/113 passed across ticker cache, exchange ticker schema, autonomous scanner, account audit, network fallback, Binance feed/throttle and private-exchange regression tests.
- `node --check` passed for every JavaScript source/test file (recorded in release validation).
- ZIP integrity verified; source-only archive excludes `.env`, `data/`, and `node_modules`.

## Safety behavior
A ticker refresh error is now surfaced; the previous cache remains internal but is never returned after expiry. This is intentional fail-closed behavior: a temporary network outage may pause a market scan or price-reference refresh, but it cannot silently drive a new selection using a ticker snapshot up to 15 minutes old.

## Boundaries
- These are local deterministic tests, not a live Binance Testnet market-data outage drill.
- No real orders were submitted.
- This release does not certify production/live trading readiness.
