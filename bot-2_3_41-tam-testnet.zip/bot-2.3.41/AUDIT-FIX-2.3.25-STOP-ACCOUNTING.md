# 2.3.25 — Protective stop quote-amount accounting repair

## Change
- A protective SELL fill with `executedQty > 0` and `quoteQty/netQuoteQty = 0` is no longer booked as a zero-price sale.
- When the exchange adapter supports order-trade lookup, `OrderManager.verifyFees()` rebuilds the gross quote amount from `price * qty` only after the returned trades cover the full executed quantity.
- The rebuilt quote amount is persisted and used to recompute net quote proceeds after quote-asset fees.
- Incomplete trade history is explicitly marked as incomplete. The protective-stop handler preserves the existing position and cumulative booking counters, records a recovery error, and locks new live trading. Terminal-order reconciliation can retry verification later.
- Added regression coverage for complete trade-based quote recovery and incomplete-trade fail-closed behavior.

## Validation
- `node --check src/liveEngine.js`: passed
- `node --check src/orderManager.js`: passed
- `node --test test/regressionFixes.test.js`: 18/18 passed
- `test/autonomousPhase.test.js`: 4/4 passed
- `test/tickerCacheStale.test.js`: 4/4 passed
- `test/binanceTestnetOptIn.test.js`: 3/3 passed
- `test/exchangeCapabilitySafety.test.js`: 7/7 passed
- `test/exchangeLiveOptIn.test.js`: 9/9 passed
- `test/liveRecovery.test.js`: 7/7 passed
- `test/mergeRegression.test.js`: 15/15 passed
- `test/httpBodyTimeout.test.js`: 2/2 passed
- `node scripts/offlinePreflight.js`: passed

## Not verified
- Full test suite: not run; dependencies are not installed in this build environment.
- Binance Spot Testnet authenticated calls, actual stop fills, partial-fill/restart scenarios, and offline-stop recovery: not run.
- Production trading remains locked for unverified exchanges. This package is not certified for real-money trading.
- Curated test manifest was updated to include the three previously unlisted tests (`autonomousPhase`, `refreshPendingBatch`, `tickerCacheStale`). The isolated batch runner passed its manifest check, but the complete batch did not finish in this environment: it stalled while launching `dailySummary.test.js` even though that file passes when run directly. Therefore no full-suite pass is claimed.
