# Telegram mode and autonomous flow — 2.3.29

## Four independent mode dimensions

- Account execution: Paper or Live (Live is restricted to Binance Spot Testnet in Telegram).
- Control style: Manual or Autonomous.
- Selecting a mode never starts the engine.

## Commands

- `/mod`: reports the exact combined mode, engine state, autonomous state, and live safety gate.
- `/mod_paper`, `/mod_live`, `/mod_man`: request a mode change; `/mod_onay` confirms within two minutes.
- `/mod_oto`: starts the autonomous preparation wizard. It lists every registered strategy, then asks for selected timeframes (15m, 30m, 1h, 4h) and capacity (1, 2, 4, 8, 16, 32). `/mod_onay` saves the selection and switches the UI mode; it does not start the engine.
- `/oto_basla [capacity]`: starts the autonomous engine in Paper. In Live it only prepares a summary; `/oto_basla_onay` is required within two minutes.
- `/oto_bitir`: stops new autonomous entries and keeps position management active until all open positions close.
- `/oto_durdur`, then `/oto_durdur_onay`: immediate manual handoff. Paper positions block handoff. In Live, every tracked position must have a matching quantity-covering sell stop on the exchange; unrelated or non-stop open orders block handoff. No exchange orders are changed.
- `/basla` and `/bitir` remain manual-mode commands.

## Safety rules

- 1m, 3m, and 5m are manual-only. Autonomous selection accepts 15m, 30m, 1h, and 4h only. There is no 1d timeframe in this build.
- Live mode switching via Telegram is limited to Binance Spot Testnet. It checks the explicit environment flags, TLS, API credentials, risk limits, kill switch, supported manual pair timeframes, signed account/balance/open-order access, server clock, User Data Stream authentication, and a read-only inventory audit.
- A Paper switch is rejected if tracked positions or exchange open orders remain. No order is automatically cancelled by a mode switch.
- Live mode selection and autonomous selection do not start trading. Live manual and autonomous starts retain separate explicit confirmations and engine-level safety gates.

## 2.3.28 Telegram entry pause addition
- `/alim_durdur` and `/alim_baslat` persist `settings.entriesPaused`.
- The pause blocks new BUY entries in both Paper and Live engines; existing positions continue through normal exit, risk and protective-stop management.
- The pause is independent of the emergency stop and does not clear kill-switch or live-trading safety locks.
- Status and `/ayarlar` report whether new entries are paused.

## 2.3.29 autonomous entry approval and reporting
- `/alim_mod otomatik` keeps autonomous BUY entries automatic; `/alim_mod onaylı` requires a Telegram approval for each fresh BUY signal.
- `/alim_bekleyen`, `/alim_onay ID`, `/alim_reddet ID` show, approve or reject one pending signal. Approval expires and is bound to the exact closed candle; engine re-evaluation is mandatory.
- `/rapor haftalik`, `/rapor aylik`, `/rapor gunluk`, `/rapor strateji`, `/rapor coin` provide period/group summaries. Weekly/monthly summaries are scheduled at `PERFORMANCE_SUMMARY_TIME` in Istanbul time.
- `/sessiz HH:MM-HH:MM` persists a daily Istanbul-time quiet window. Critical alerts are never muted.
