# 2.3.30 — Denetim düzeltmeleri

- **Sahte kill switch giderildi:** Satış geliri, zaten borsadan yenilenmiş bakiye anlık görüntüsüne ikinci kez ekleniyordu; gün başı bakiyesi şişiyor, sonraki kontrol sahte %25 zarar görüp tüm pozisyonları piyasadan satıyordu. Anlık görüntü dolumdan sonra alındıysa artık yeniden uygulanmıyor (`lastBalanceAtMs`).
- **Çökme sonrası kalıcı kilit giderildi:** Borsa kimliği yerel kayda yazılmadan çökme olursa kurtarma aynı emri `external-unclassified` olarak ikinci kez kaydediyordu. Artık aynı clientOrderId'li kayda borsa kimliği işleniyor; mutabakat ayrıca koruyucu role sahip bir kaydın kopyasını "çözülmemiş emir" saymıyor.
- **Telegram onay kimliği çakışması giderildi:** Kimlik tam sembolden türetiliyor (`1000SATS/USDT` ve `/USDC` artık farklı).
- **Kısmi dolum kilidi:** Davranış (mutabakat bitene kadar duraklatma) bilinçli olarak korundu; kilit nedeni artık açıkça yazılıyor ve mutabakat sonrası otomatik açılıyor.
- **`.env.example`:** Canlı işlem ve Testnet izni varsayılan olarak `false`.
- Yeni test: `test/falsePositiveFixes.test.js`, onay kimliği testi.

## Doğrulama
- Tüm gruplar: 1.394/1.395 geçti. Geçmeyen tek test `serverIntegration` (bu ortamda express/ws/dotenv kurulamadı); cihazda `npm ci` sonrası çalıştırın.
- Genişletilmiş kaos (1500/600/250) 14/14; ek 2.500 görülmemiş tohumda ihlal ve kalıcı kilit yok.
- Gerçek borsa çağrısı yapılmadı. Bu sürüm üretim için sertifikalı DEĞİLDİR.
