# 2.3.32 — Sahiplenme sınırı alım slotlarını boğmasın

**Sorun (2.3.31 canlı logundan):** Rotasyon her turda 3 sahiplenilmiş coin satıyor, ancak 1-2 dakika içinde hesaptaki sıradaki coinler sahipleniliyor ve yönetilen sayı 60'a tamamlanıyordu. Alım kapısı "yönetilen sayı < 32" şartı aradığı için yeni alım hiç açılmıyor, günlük rotasyon hakkı aynı havuzu döndürmekle tükeniyordu.

**Değişiklik (`src/liveEngine.js`, `_adoptExistingHoldings`):**
- Otonom modda sahiplenilmiş (hediye) coin sayısı en fazla `seçilen coin sayısı − 12` olur (32 için 20). Sınır yalnızca `adopted` pozisyonları sayar; botun kendi aldıkları sınırı tüketmez.
- Rezerv sayısı `settings.adoptEntryReserve` ile değiştirilebilir (varsayılan 12).
- Seçilen coin sayısı rezerv sayısından büyük değilse (≤ 12) eski davranış (toplam pozisyon sınırı, en fazla 60) korunur.
- Mevcut 60 pozisyon rotasyonla 20'ye iner; sayı 20'nin altına inmedikçe yeniden sahiplenme olmaz. 32'nin altına inince otonom alımlar açılır.
- Değişmeyenler: portföy kapısı (`maxConcurrentPositions`), rotasyon (tarama başı 3, gün başı 30), stop/kâr çıkışları, BNB dahil tüm coinlerin sahiplenilmesi.
- Testler: `holdingsAdoption.test.js`'e 2 yeni test.

**Doğrulama:** Kullanıcı tam test paketini 2.3.30/2.3.31 üzerinde çalıştırdı ve hatasız geçti bildirdi. 2.3.32 değişikliğinden sonra ilgili 9 test dosyası (120 test) geçti; tam paket yeniden çalıştırılmadı.
