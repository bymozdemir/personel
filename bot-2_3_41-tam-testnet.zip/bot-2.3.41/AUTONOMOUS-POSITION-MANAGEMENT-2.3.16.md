# Otonom açık pozisyon yönetimi – 2.3.16

- Otonom canlı mod açıldığında, borsa mutabakatından sonra yerel pozisyon defterindeki tüm desteklenen açık pozisyonlar otonom yönetim listesine alınır.
- Her pozisyon için seçili stratejilerin ve zaman dilimlerinin tarihsel doğrulaması yapılır; yalnızca maliyetler sonrası pozitif net sonuç, yeterli işlem sayısı ve düşüş sınırını geçen profiller aday olabilir.
- İlk geçişte eski manuel strateji yapılandırması yerine en iyi doğrulanmış profil uygulanır. Sonraki geçişler, önceki seçime göre anlamlı derecede daha iyi skor gerektirir. Tarama 30 dakikada bir ve her yeniden başlatmada ilk tick'te yapılır.
- Giriş stratejisi/zaman dilimi geçmiş metadata olarak saklanır; aktif yönetim stratejisi ve zaman dilimi ayrı kaydedilir.
- Strateji geçişi mevcut miktarı, giriş referansını, stop fiyatını veya mevcut borsa stop emir kimliğini değiştirmez. Bekleyen koruyucu olmayan emir varsa geçiş ertelenir.
- Mevcut koruyucu stop, yeni strateji seçildi diye iptal edilmez veya ikinci stop gönderilmez. Sonraki normal trailing-stop yönetimi yalnızca mevcut stopu güvenli iptal-doğrula-yenile akışından geçirerek sıkılaştırabilir.
- Strateji taramasında doğrulanmış aday bulunamazsa mevcut yönetim ve stop korunur; bot doğrulanmamış bir stratejiye zorla geçmez.

## Doğrulama kapsamı

Bu sürümde otomatik testler mevcut pozisyonun devralınmasını, strateji/zaman dilimi geçişini, giriş metadata'sının ve mevcut stop kimliğinin korunmasını, tarama aralığını, hesap referans fiyatı ve offline preflight'ı kapsar. Gerçek Binance Testnet API bağlantısı, borsa üzerindeki açık emir/stop mutabakatı, kısmi dolum ve bot kapalıyken stop dolumu bu ortamda çalıştırılmamıştır. Canlı/gerçek para hazır olduğu anlamına gelmez.
