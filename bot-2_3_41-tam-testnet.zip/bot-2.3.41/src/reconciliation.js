// src/reconciliation.js
//
// Canli moda gecmeden once borsadaki gercek Spot hesabinin botun yerel
// durumuyla uyumlu olup olmadigini kontrol eder.
//
// Bu katman kasitli olarak "beklenen coin miktari" uydurmaz. Henuz canli
// pozisyon defterimiz olmadigi icin sadece kesin olarak bildigimiz seyleri
// dogrular: hesap okunabiliyor mu, belirsiz emir var mi, borsada botun
// tanimadigi acik emir var mi?

const TERMINAL = new Set(['FILLED', 'CANCELED', 'REJECTED', 'EXPIRED']);

function normalizeBalances(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    throw new Error('Borsa bakiye cevabı nesne değil veya boş.');
  }
  const out = {};
  for (const [asset, value] of Object.entries(raw)) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      throw new Error(`Geçersiz bakiye verisi: ${asset}`);
    }
    const free = Number(value.free ?? 0);
    const locked = Number(value.locked ?? 0);
    if (!Number.isFinite(free) || !Number.isFinite(locked) || free < 0 || locked < 0 || !Number.isFinite(free + locked)) {
      throw new Error(`Geçersiz bakiye verisi: ${asset}`);
    }
    out[String(asset).toUpperCase()] = { free, locked, total: free + locked };
  }
  return out;
}



function normalizeQuotePrices(rows, quote = 'USDT') {
  const q = String(quote || 'USDT').toUpperCase();
  const prices = {};
  for (const row of Array.isArray(rows) ? rows : []) {
    const symbol = String(row?.symbol || '').toUpperCase();
    const price = Number(row?.lastPrice ?? row?.price);
    if (symbol.endsWith(`/${q}`) && /^[A-Z0-9]{2,20}$/.test(symbol.slice(0, -(q.length + 1))) && Number.isFinite(price) && price > 0) {
      prices[symbol.slice(0, -(q.length + 1))] = price;
    }
  }
  return prices;
}

function normalizeUsdtPrices(rows) { return normalizeQuotePrices(rows, 'USDT'); }

// First-seen market price is a persistent reference basis, NOT the real purchase cost.
// Quantity changes update the snapshot only; the reference price is never silently reset.
function updateExternalInventoryReferences(state, balances, prices, checkedAt, quote = 'USDT') {
  if (!state.live || typeof state.live !== 'object') state.live = {};
  if (!state.live.externalInventoryByAsset || typeof state.live.externalInventoryByAsset !== 'object') {
    state.live.externalInventoryByAsset = {};
  }
  const tracked = state.live.externalInventoryByAsset;
  for (const [asset, amount] of Object.entries(balances || {})) {
    if (asset === quote || !(Number(amount?.total) > 0)) continue;
    const price = Number(prices?.[asset]);
    const prior = tracked[asset];
    if (!prior && Number.isFinite(price) && price > 0) {
      tracked[asset] = {
        asset, symbol: `${asset}/${quote}`, quote, provenance: 'exchange-discovered',
        referencePrice: price, referenceQuantity: Number(amount.total),
        referenceValueUSDT: Number(amount.total) * price,
        currentQuantity: Number(amount.total), currentPrice: price,
        referenceObservedAt: checkedAt, lastObservedAt: checkedAt,
        referenceType: 'first-observed-market-price', initialized: true
      };
    } else if (prior) {
      prior.currentQuantity = Number(amount.total);
      prior.lastObservedAt = checkedAt;
      if (Number.isFinite(price) && price > 0) prior.currentPrice = price;
      // Never guess a reference price when the first observation had no valid quote.
      if (!(Number(prior.referencePrice) > 0) && Number.isFinite(price) && price > 0) {
        prior.referencePrice = price;
        prior.referenceQuantity = Number(amount.total);
        prior.referenceValueUSDT = Number(amount.total) * price;
        prior.referenceObservedAt = checkedAt;
        prior.referenceType = 'first-valid-market-price';
        prior.initialized = true;
      }
    } else {
      tracked[asset] = {
        asset, symbol: `${asset}/${quote}`, quote, provenance: 'exchange-discovered',
        referencePrice: null, referenceQuantity: Number(amount.total),
        referenceValueUSDT: null, currentQuantity: Number(amount.total), currentPrice: null,
        referenceObservedAt: null, lastObservedAt: checkedAt,
        referenceType: 'awaiting-valid-market-price', initialized: false
      };
    }
  }
  // Keep absent assets as history; do not delete their reference basis.
}

function splitPair(symbol) {
  const parts = String(symbol || '').toUpperCase().split('/');
  return parts.length === 2 && parts[0] && parts[1] ? { base: parts[0], quote: parts[1] } : { base: null, quote: null };
}

function managedBaseAssets(state) {
  const out = new Set();
  for (const symbol of Object.keys(state?.pairs || {})) {
    const { base } = splitPair(symbol);
    if (base) out.add(base);
  }
  for (const position of Object.values(state?.live?.positions || {})) {
    const { base } = splitPair(position?.symbol);
    if (base) out.add(base);
    else if (position?.baseAsset) out.add(String(position.baseAsset).toUpperCase());
  }
  return out;
}

function checkManagedBalances(state, balances) {
  const positions = state?.live?.positions || {};
  const assets = managedBaseAssets(state);
  const mismatches = [];

  // The exchange is the source of truth for account inventory. A pre-existing
  // balance is not automatically a bot-owned position, and legacy
  // balanceBaselineByAsset snapshots must not be added to the exchange balance.
  // Only verify that the exchange still holds enough of each asset to cover
  // positions and tracked dust owned by this bot. Surplus inventory is allowed.
  for (const asset of assets) {
    const rawTotal = balances?.[asset]?.total ?? 0;
    const total = Number(rawTotal);
    if (!Number.isFinite(total) || total < 0) {
      mismatches.push({ asset, expected: null, actual: total, reason: 'invalid_exchange_balance' });
      continue;
    }

    let expected = 0;
    let invalidPosition = false;
    for (const p of Object.values(positions)) {
      const parsed = splitPair(p?.symbol);
      const positionBase = String(p?.baseAsset || parsed.base || '').toUpperCase();
      if (positionBase !== asset) continue;
      const quantity = Number(p?.quantity);
      const costQuote = Number(p?.costQuote ?? 0);
      if (!Number.isFinite(quantity) || quantity < 0 || !Number.isFinite(costQuote) || costQuote < 0) {
        mismatches.push({ asset, expected: null, actual: total, reason: 'invalid_local_position' });
        invalidPosition = true;
        continue;
      }
      expected += quantity;
    }
    if (invalidPosition) continue;

    // Dust remains part of the bot's recorded inventory. Legacy baselines are
    // intentionally ignored: they are snapshots, not a live balance source.
    const rawDust = state?.live?.dustByAsset?.[asset] ?? 0;
    const dust = Number(rawDust);
    if (!Number.isFinite(dust) || dust < 0) {
      mismatches.push({ asset, expected: null, actual: total, reason: 'invalid_local_dust' });
      continue;
    }
    expected += dust;
    const tolerance = Math.max(1e-12, expected * 1e-8);

    // Existing/manual/exchange-provided inventory may make actual > expected.
    // That is not a reconciliation failure. A shortfall against bot-managed
    // positions or dust is a failure because protective exits may not be funded.
    if (total + tolerance < expected) {
      mismatches.push({
        asset,
        expected,
        actual: total,
        reason: 'position_balance_shortfall'
      });
    }
  }
  return mismatches;
}

function localOpenOrderIds(state) {
  const ids = new Set();
  for (const order of Object.values(state?.liveOrders || {})) {
    if (!order || TERMINAL.has(String(order.status || '').toUpperCase())) continue;
    if (order.exchangeOrderId !== null && order.exchangeOrderId !== undefined) {
      ids.add(String(order.exchangeOrderId));
    }
  }
  return ids;
}

class AccountReconciler {
  constructor({ exchange, state, store, nowFn } = {}) {
    if (!exchange) throw new Error('AccountReconciler için exchange gerekli.');
    if (!state) throw new Error('AccountReconciler için state gerekli.');
    if (!store || typeof store.save !== 'function') throw new Error('AccountReconciler için store.save gerekli.');
    this.exchange = exchange;
    this.state = state;
    this.store = store;
    this.nowFn = nowFn || (() => Date.now());
  }

  async reconcile({ requireOpenOrders = true } = {}) {
    const checkedAt = new Date(this.nowFn()).toISOString();
    const result = {
      safeToTrade: false,
      checkedAt,
      exchange: this.exchange.id || this.exchange.name || 'unknown',
      balances: {},
      openOrders: [],
      unknownLocalOrders: [],
      orphanOpenOrders: [],
      unresolvedLocalOpenOrders: [],
      errors: []
    };

    if (typeof this.exchange.fetchBalance !== 'function') {
      result.errors.push('Borsa bakiye sorgusunu desteklemiyor.');
      return this._save(result);
    }

    try {
      result.balances = normalizeBalances(await this.exchange.fetchBalance());
    } catch (err) {
      result.errors.push(`Bakiye sorgulanamadı: ${err?.message || String(err)}`);
      return this._save(result);
    }

    // Persist first-seen reference prices for pre-existing exchange holdings. This is
    // accounting metadata only: it does not claim ownership or create trading positions.
    if (typeof this.exchange.fetchAllTickers24h === 'function') {
      try {
        const rows = await this.exchange.fetchAllTickers24h();
        const quotes = [...new Set([...(this.exchange.quoteAssets || []), 'USDT'].map((q) => String(q).toUpperCase()))];
        const byQuote = {};
        for (const q of quotes) byQuote[q] = normalizeQuotePrices(rows, q);
        if (!this.state.live || typeof this.state.live !== 'object') this.state.live = {};
        this.state.live.assetPricesByQuote = byQuote;
        this.state.live.assetPricesAt = checkedAt;
        const primary = String(this.state.settings?.quoteAsset || 'USDT').toUpperCase();
        const refQuote = byQuote[primary] ? primary : 'USDT';
        updateExternalInventoryReferences(this.state, result.balances, byQuote[refQuote] || {}, checkedAt, refQuote);
        result.externalInventoryReferences = Object.values(this.state.live?.externalInventoryByAsset || {});
      } catch (err) {
        result.referencePriceWarning = `Başlangıç referans fiyatları alınamadı: ${err?.message || String(err)}`;
      }
    }

    // UNKNOWN/PENDING/PARTIALLY_FILLED gibi kapanmamis yerel emirler varsa,
    // bunlar cozulmeden yeni canli islem baslatmak guvenli degildir.
    const localPending = Object.values(this.state.liveOrders || {})
      .filter((o) => o && !TERMINAL.has(String(o.status || '').toUpperCase()));

    const caps = this.exchange.capabilities || {};
    if (requireOpenOrders && caps.openOrdersQuery && typeof this.exchange.fetchOpenOrders === 'function') {
      try {
        // Hesaptaki tum acik emirler sahiplenme/recovery icin gorulmeli; yalnizca
        // panelde tanimli pariteleri sorgulamak baska sembollerdeki emirleri gizler.
        result.openOrders = await this.exchange.fetchOpenOrders();
        if (!Array.isArray(result.openOrders)) throw new Error('Borsa açık emir cevabı dizi değil.');
        const invalidOpenOrders = result.openOrders.filter((o) =>
          !o || typeof o !== 'object' || Array.isArray(o) ||
          o.orderId === null || o.orderId === undefined || String(o.orderId).trim() === '' ||
          typeof o.symbol !== 'string' || !o.symbol.trim() ||
          !['NEW', 'PARTIALLY_FILLED'].includes(String(o.status || '').toUpperCase())
        );
        if (invalidOpenOrders.length) {
          result.errors.push(`Borsa açık emir yanıtında ${invalidOpenOrders.length} kayıt kimlik/sembol/durum doğrulamasını geçemedi.`);
        }
        const maxOpenOrders = Number(this.state.settings?.maxOpenOrders || 12);
        // Bu limit botun YENI emirleri icindir. Borsada onceden bulunan emirleri
        // sirf sayilari fazla diye recovery hatasina cevirmeyiz.
        if (result.openOrders.length > maxOpenOrders) result.warnings = [...(result.warnings || []), `Borsadaki açık emir sayısı ${result.openOrders.length}/${maxOpenOrders} (bilgi amaçlı); ${maxOpenOrders} sınırı yalnızca botun bekleyen koruma dışı emirlerine uygulanır.`];
        const knownIds = localOpenOrderIds(this.state);
        result.orphanOpenOrders = result.openOrders
          .filter((o) => o?.orderId !== undefined && o?.orderId !== null)
          .filter((o) => !knownIds.has(String(o.orderId)))
          .map((o) => ({ ...o,
            orderId: o.orderId,
            clientOrderId: o.clientOrderId || null,
            symbol: o.symbol,
            side: o.side,
            status: o.status,
            executedQty: Number(o.executedQty || 0)
          }));

        // Kendi açık emirlerimiz (özellikle koruyucu stoplar) güvenlidir;
        // bunları sadece açık oldukları için "belirsiz" sayamayız. Ancak yerel
        // kayıt borsada artık açık değilse, WebSocket kaçırılmış olabilir; bu
        // durumda order manager'ın ayrıca sorgulaması gerekir ve canlı kapı kapanır.
        const openIdSet = new Set(result.openOrders.map((o) => String(o.orderId)));
        const protectiveRoles = new Set(['protective-stop', 'protective-stop-recovery', 'profit-protection-stop', 'protective-tp']);
        // Aynı borsa emrini gösteren birden çok yerel kayıt olabilir (kurtarma sırasında oluşan 'external' kopya). Biri koruyucu
        // role sahipse kopya ayrı bir çözülmemiş emir değildir.
        const protectedExchangeIds = new Set(Object.values(this.state.liveOrders || {})
          .filter((o) => o?.exchangeOrderId != null && protectiveRoles.has(String(o?.meta?.role || '')))
          .map((o) => String(o.exchangeOrderId)));
        result.unresolvedLocalOpenOrders = localPending
          .filter((o) => o?.exchangeOrderId != null && openIdSet.has(String(o.exchangeOrderId)))
          .filter((o) => !protectiveRoles.has(String(o?.meta?.role || '')))
          .filter((o) => !(o?.meta?.external === true && protectedExchangeIds.has(String(o.exchangeOrderId))))
          .map((o) => ({
            clientOrderId: o.clientOrderId || null,
            exchangeOrderId: o.exchangeOrderId,
            symbol: o.symbol,
            status: o.status,
            role: o?.meta?.role || null
          }));
        if (result.unresolvedLocalOpenOrders.length) {
          result.errors.push(`Borsada ${result.unresolvedLocalOpenOrders.length} çözülmemiş giriş/çıkış emri hâlâ açık; yeni işlem güvenli değil.`);
        }
        result.unknownLocalOrders = localPending
          .filter((o) => o.exchangeOrderId == null || !openIdSet.has(String(o.exchangeOrderId)))
          .map((o) => ({
            clientOrderId: o.clientOrderId,
            exchangeOrderId: o.exchangeOrderId ?? null,
            symbol: o.symbol,
            status: o.status
          }));
      } catch (err) {
        result.errors.push(`Açık emirler sorgulanamadı: ${err?.message || String(err)}`);
      }
    } else if (requireOpenOrders) {
      result.errors.push('Açık emir sorgulama desteği yok; canlı işlem güvenli şekilde başlatılamaz.');
    }

    // Quote bakiyeleri de pozisyonlar gibi parite bazında anlamlıdır. TRY ve USDT
    // aynı 'cash' havuzu değildir; bu yüzden beklenen quote varlıklarını ayrı izleriz.
    const expectedQuotes = new Set();
    for (const symbol of Object.keys(this.state.pairs || {})) { const { quote } = splitPair(symbol); if (quote) expectedQuotes.add(quote); }
    for (const position of Object.values(this.state.live?.positions || {})) { if (position?.quoteAsset) expectedQuotes.add(String(position.quoteAsset).toUpperCase()); else { const { quote } = splitPair(position?.symbol); if (quote) expectedQuotes.add(quote); } }
    result.quoteBalances = {};
    for (const quote of expectedQuotes) result.quoteBalances[quote] = result.balances?.[quote] || { free: 0, locked: 0, total: 0 };

    result.balanceMismatches = checkManagedBalances(this.state, result.balances);
    if (result.balanceMismatches.length) {
      result.errors.push('Yönetilen varlık bakiyesi yerel pozisyon defteriyle uyuşmuyor.');
    }

    // Tanınmayan manuel/dış SELL fill olayları yalnızca User Data Stream'den
    // tespit edilmiş olabilir. REST myTrades ile muhasebe doğrulanmadan bir sonraki
    // temiz bakiye mutabakatı bu güvenlik kilidini sessizce açamaz.
    const pendingExternalSales = Array.isArray(this.state.live?.externalManualSalesPending)
      ? this.state.live.externalManualSalesPending.filter((x) => x && x.state !== 'resolved') : [];
    if (this.state.live?.manualExternalSaleReviewRequired === true || pendingExternalSales.length) {
      result.pendingExternalSales = pendingExternalSales.length;
      result.errors.push(`Manuel/dış satış incelemesi bekliyor (${pendingExternalSales.length} kayıt); REST işlem geçmişiyle muhasebe doğrulanmadan canlı işlemler açılmaz.`);
    }

    // Açık bir pozisyon varsa, onun koruyucu stopunun da borsada gerçekten
    // açık olması gerekir. Sadece bakiye eşleşmesi yeterli değildir: stop
    // iptal edilmiş, dolmuş veya WebSocket mesajı kaçırılmış olabilir.
    // Böyle bir pozisyonu yeni işlem kapısından güvenli kabul etmiyoruz.
    const positions = this.state.live?.positions || {};
    for (const [symbol, position] of Object.entries(positions)) {
      const stopId = position?.stopOrderId;
      if (!stopId) {
        // Sahiplenilmis (kullanicinin onceden sahip oldugu) coinde stop henuz kurulamadiysa bu botu kilitlemez:
        // pozisyon sahiplenmeden onceki durumundan kotu degil ve motor birkac denemeden sonra onu yonetimden birakir.
        if (position?.adopted === true) { (result.warnings ||= []).push(`Sahiplenilmiş pozisyonda stop yok: ${symbol}`); continue; }
        result.errors.push(`Koruyucu stop kaydı yok: ${symbol}`);
        continue;
      }
      const localStop = this.state.liveOrders?.[stopId];
      if (!localStop) {
        result.errors.push(`Koruyucu stop yerel kayıtta yok: ${symbol} / ${stopId}`);
        continue;
      }
      const stopStatus = String(localStop.status || '').toUpperCase();
      if (stopStatus !== 'NEW' && stopStatus !== 'PARTIALLY_FILLED') {
        result.errors.push(`Koruyucu stop açık değil: ${symbol} / ${stopId} / ${stopStatus}`);
        continue;
      }
      const exchangeOpen = result.openOrders.find((o) =>
        String(o.orderId) === String(localStop.exchangeOrderId) ||
        (o.clientOrderId && String(o.clientOrderId) === String(stopId))
      );
      if (!exchangeOpen) {
        result.errors.push(`Koruyucu stop borsada açık değil: ${symbol} / ${stopId}`);
      }
    }

    result.safeToTrade = result.errors.length === 0 &&
      result.unknownLocalOrders.length === 0 &&
      result.orphanOpenOrders.length === 0 &&
      result.unresolvedLocalOpenOrders.length === 0;

    return this._save(result);
  }

  _save(result) {
    this.state.liveReconciliation = result;
    this.store.save(this.state);
    return result;
  }
}

module.exports = { AccountReconciler, normalizeBalances, normalizeUsdtPrices, normalizeQuotePrices, updateExternalInventoryReferences, localOpenOrderIds, managedBaseAssets, checkManagedBalances };
