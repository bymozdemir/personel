'use strict';
// src/hourlyReport.js
//
// Saat basi Telegram raporu ("saglikliyim, calisiyorum, su kadar alim-satim yaptim").
// Istanbul saatiyle her saatin ilk 20 dakikasinda bir kez gonderilir (sessiz bildirim; sorun varsa baslikta uyarir).
//   HOURLY_REPORT=0   -> kapatir (varsayilan acik)
// "Hangi saat gonderildi" bilgisi state.notifyMeta.lastHourlyReportKey icinde saklanir; yeniden baslatma ayni saat icin
// ikinci rapor uretmez. Telegram ve Termux kanallarina notifier uzerinden gider.

const { istanbulDayKey, istanbulMinuteOfDay, formatIstanbulTime } = require('./istanbulTime');

const esc = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const b = (v) => `<b>${esc(v)}</b>`;
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : null; };
const signed = (v) => { const n = num(v) ?? 0; return `${n >= 0 ? '+' : ''}${n.toFixed(2)}`; };
const money = (v) => { const n = num(v); return n === null ? '?' : n.toLocaleString('en-US', { maximumFractionDigits: 2 }); };
const HOUR_MS = 60 * 60 * 1000;
const STALE_TICK_MS = 15 * 60 * 1000;

function toMs(v) {
  if (v === undefined || v === null || v === '') return null;
  const n = Number(v);
  if (Number.isFinite(n) && n > 1e11) return n;
  const p = Date.parse(v);
  return Number.isFinite(p) ? p : null;
}

// Durum anlik goruntusunden son 1 saatlik ozet cikarir (saf fonksiyon).
function buildHourlyData({ base = {}, state = {}, nowMs = Date.now(), notifyPending = 0 } = {}) {
  const live = String(base.mode || state.settings?.mode || 'paper').toLowerCase() === 'live';
  const since = nowMs - HOUR_MS;
  const book = live ? (state.live || {}) : (state.paper || {});
  const trades = Array.isArray(book.trades) ? book.trades : [];
  const lastHourSells = trades.filter((t) => { const c = toMs(t && t.closedAt); return c !== null && c >= since && c <= nowMs; });
  const orders = live && state.liveOrders && typeof state.liveOrders === 'object' ? Object.values(state.liveOrders) : [];
  const buys = orders.filter((o) => o && String(o.side).toLowerCase() === 'buy' && ['FILLED', 'PARTIALLY_FILLED'].includes(String(o.status).toUpperCase())
    && (toMs(o.createdAt) ?? 0) >= since).length;
  const positions = Object.values(book.positions || {}).filter(Boolean);
  const adopted = positions.filter((p) => p.adopted === true);
  const adoptions = adopted.filter((p) => (toMs(p.adoptedAt) ?? 0) >= since).length;
  const auto = base.autonomous || {};
  const m = /(\d+)\s*\/\s*(\d+)\s+coin yönetiliyor/.exec(String(auto.message || ''));
  return {
    nowMs, mode: base.mode, running: base.running, killSwitch: base.killSwitch, safeToTrade: base.safeToTrade,
    lastTickAt: base.lastTickAt, quoteAsset: base.quoteAsset, equity: base.equity,
    positions: { total: positions.length, adopted: adopted.length, own: positions.length - adopted.length },
    autonomous: { active: Boolean(auto.active), lastScanAt: auto.lastScanAt || null, managed: m ? `${m[1]}/${m[2]}` : null, message: auto.message || '',
      scanSec: num(state.autonomous?.lastScanDurationMs) !== null ? Math.round(state.autonomous.lastScanDurationMs / 1000) : null, scanned: num(state.autonomous?.scanned), universe: num(state.autonomous?.universeSize) },
    lastHour: { buys, sells: lastHourSells.length, pnl: lastHourSells.reduce((s, t) => s + (Number(t.pnl) || 0), 0), adoptions },
    rotationToday: live ? (num(state.live?.rotation?.count) ?? 0) : null,
    errorCount: base.errorCount || 0, warnCount: base.warnCount || 0, lastError: base.lastError || null,
    notifyPending
  };
}

function problems(d) {
  const out = [];
  if (!d.running) out.push('bot durmuş');
  if (d.killSwitch) out.push('kill switch AÇIK');
  if (String(d.mode).toLowerCase() === 'live' && d.safeToTrade === false) out.push('canlı işlem kilitli');
  const tick = num(d.lastTickAt);
  if (d.running && tick !== null && d.nowMs - tick > STALE_TICK_MS) out.push(`son kontrol ${Math.round((d.nowMs - tick) / 60000)} dk önce`);
  if (num(d.notifyPending) > 0) out.push(`${d.notifyPending} bildirim gönderilmeyi bekliyor`);
  return out;
}

function hourlyText(d) {
  const live = String(d.mode || 'paper').toLowerCase() === 'live';
  const q = esc(d.quoteAsset || '');
  const issues = problems(d);
  const lines = [`🕐 ${b('SAAT BAŞI RAPORU')} — ${esc(formatIstanbulTime(d.nowMs))} (${live ? 'CANLI' : 'PAPER'})`];
  lines.push(issues.length ? `⚠️ ${b('DİKKAT')}: ${esc(issues.join(', '))}` : '✅ Sağlıklıyım, çalışıyorum.');
  if (num(d.lastTickAt) !== null) lines.push(`Son kontrol: ${esc(formatIstanbulTime(d.lastTickAt))}`);
  lines.push('');
  const p = d.positions || { total: 0, adopted: 0, own: 0 };
  lines.push(`Açık pozisyon: ${b(p.total)} (sahiplenilmiş ${esc(p.adopted)}, botun kendi aldığı ${esc(p.own)})`);
  const a = d.autonomous || {};
  if (a.active || a.managed) lines.push(`Otonom: ${a.active ? 'aktif' : 'pasif'}${a.managed ? ` | yönetilen ${b(a.managed)}` : ''}${a.lastScanAt ? ` | son tarama ${esc(formatIstanbulTime(a.lastScanAt))}` : ''}`);
  if (num(a.scanSec) !== null) lines.push(`Son tarama: ${esc(a.scanSec)} sn${num(a.scanned) !== null && num(a.universe) !== null ? ` (${esc(a.scanned)}/${esc(a.universe)} coin)` : ''}`);
  lines.push('');
  const h = d.lastHour || { buys: 0, sells: 0, pnl: 0, adoptions: 0 };
  lines.push(`${b('Son 1 saat')}: alım ${esc(h.buys)} | satış ${esc(h.sells)}${h.sells ? ` (K/Z ${esc(signed(h.pnl))} ${q})` : ''} | sahiplenme ${esc(h.adoptions)}`);
  if (d.rotationToday !== null && d.rotationToday !== undefined) lines.push(`Rotasyon satışı (bugün): ${esc(d.rotationToday)}`);
  if (num(d.equity) !== null) lines.push(`Özkaynak: ${esc(money(d.equity))} ${q}`);
  if (d.errorCount || d.warnCount) lines.push(`Son kayıtlarda: ${esc(d.errorCount)} hata, ${esc(d.warnCount)} uyarı${d.lastError ? ` — ${esc(String(d.lastError).slice(0, 120))}` : ''}`);
  return lines.join('\n');
}

function createHourlyReport({ getData, notifier, state, store, env = process.env, nowFn = () => Date.now(), logger = console, intervalMs = 30000, windowMinutes = 20 } = {}) {
  const disabled = ['0', 'false', 'off', 'hayir', 'hayır'].includes(String(env.HOURLY_REPORT || '').toLowerCase());
  const MAX_FAILS_PER_HOUR = 3;
  let timer = null; let failKey = null; let fails = 0;
  const meta = () => { if (!state.notifyMeta || typeof state.notifyMeta !== 'object') state.notifyMeta = {}; return state.notifyMeta; };
  const text = (nowMs = nowFn()) => hourlyText(getData(nowMs));

  async function tick() {
    if (disabled || !notifier) return false;
    const now = nowFn();
    const dayKey = istanbulDayKey(now); const minuteOfDay = istanbulMinuteOfDay(now);
    if (!dayKey || minuteOfDay === null) return false;
    const key = `${dayKey}-${String(Math.floor(minuteOfDay / 60)).padStart(2, '0')}`;
    if (minuteOfDay % 60 >= windowMinutes) return false;
    if (meta().lastHourlyReportKey === key) return false;
    if (failKey !== key) { failKey = key; fails = 0; }
    if (fails >= MAX_FAILS_PER_HOUR) return false;
    let body;
    try { body = text(now); } catch (e) { fails += 1; logger.warn(`[saat-basi-rapor] olusturulamadi: ${e.message}`); return false; }
    const st = notifier.status ? notifier.status() : { telegram: true };
    const result = await notifier.send(body, { priority: 'quiet', html: true, title: 'AL-SAT saat başı raporu' });
    const anyConfigured = st.telegram || st.termux;
    const delivered = !anyConfigured || result.skipped === true || Object.values(result).some((v) => v === true);
    if (delivered) {
      meta().lastHourlyReportKey = key;
      try { if (store && typeof store.save === 'function') store.save(state); } catch (e) { logger.warn(`[saat-basi-rapor] durum kaydedilemedi: ${e.message}`); }
      return true;
    }
    fails += 1;
    return false;
  }

  function start() { if (disabled || timer) return false; timer = setInterval(() => { tick().catch(() => {}); }, intervalMs); if (timer.unref) timer.unref(); return true; }
  function stop() { if (timer) clearInterval(timer); timer = null; }
  return { start, stop, tick, text, isEnabled: () => !disabled };
}

module.exports = { createHourlyReport, buildHourlyData, hourlyText, problems };
