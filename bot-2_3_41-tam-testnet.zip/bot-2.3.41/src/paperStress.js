'use strict';

// KAGIT MODU STRES PROFILLERI
//
// Paper motoru varsayilan olarak iyimser dolum yapar: emir hep dolar, hep tam dolar, kayma sabittir.
// Gercek borsada emir reddedilebilir, gec dolabilir, yarim dolabilir; stop'lar kotu fiyattan calisir.
// Bu modul, paper dolumlarina kontrollu olarak bu kotu durumlari ekler. Bot mantigi DEGISMEZ;
// yalniz dolum sonucu kotulesir. Boylece "en kotu durumda bot ne yapiyor" paper'da gorulebilir.
//
// Secim: ortam degiskeni PAPER_STRESS_PROFILE=off|realistic|pessimistic|extreme
// (state.settings.paperStressProfile varsa o onceliklidir). Varsayilan: off (davranis degismez).
// Tekrarlanabilirlik icin PAPER_STRESS_SEED (sayi) verilebilir.

const PROFILES = Object.freeze({
  off: Object.freeze({
    feeMult: 1, entrySlipPct: [0, 0], exitSlipPct: [0, 0], stopExitSlipPct: [0, 0],
    entryRejectProb: 0, entryPartialProb: 0, entryPartialFill: [1, 1],
    exitFailProb: 0, exitPartialProb: 0, exitPartialFill: [1, 1]
  }),
  realistic: Object.freeze({
    feeMult: 1, entrySlipPct: [0.02, 0.10], exitSlipPct: [0.02, 0.08], stopExitSlipPct: [0.10, 0.30],
    entryRejectProb: 0.03, entryPartialProb: 0.10, entryPartialFill: [0.5, 0.9],
    exitFailProb: 0.03, exitPartialProb: 0.05, exitPartialFill: [0.5, 0.9]
  }),
  pessimistic: Object.freeze({
    feeMult: 1.5, entrySlipPct: [0.10, 0.40], exitSlipPct: [0.10, 0.30], stopExitSlipPct: [0.40, 1.00],
    entryRejectProb: 0.10, entryPartialProb: 0.25, entryPartialFill: [0.3, 0.7],
    exitFailProb: 0.10, exitPartialProb: 0.15, exitPartialFill: [0.3, 0.7]
  }),
  extreme: Object.freeze({
    feeMult: 2, entrySlipPct: [0.30, 1.00], exitSlipPct: [0.30, 0.80], stopExitSlipPct: [1.00, 3.00],
    entryRejectProb: 0.25, entryPartialProb: 0.40, entryPartialFill: [0.2, 0.6],
    exitFailProb: 0.25, exitPartialProb: 0.30, exitPartialFill: [0.2, 0.6]
  })
});

const STOP_LIKE = /stop|loss|zarar|kill|acil|emergency|trail/i;

// Kucuk, tohumlanabilir ve bagimliliksiz rastgele sayi uretici (mulberry32).
function makeRng(seed) {
  let a = (Number.isFinite(Number(seed)) ? Number(seed) : Date.now()) >>> 0;
  return function rng() {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function profileName(settings) {
  const raw = String((settings && settings.paperStressProfile) || process.env.PAPER_STRESS_PROFILE || 'off').trim().toLowerCase();
  return Object.prototype.hasOwnProperty.call(PROFILES, raw) ? raw : 'off';
}

class PaperStress {
  constructor({ settings, rng } = {}) {
    this.settings = settings || {};
    const seedEnv = process.env.PAPER_STRESS_SEED;
    this.rng = rng || makeRng(seedEnv !== undefined && seedEnv !== '' ? Number(seedEnv) : undefined);
    this.counts = { entryRejected: 0, entryPartial: 0, exitFailed: 0, exitPartial: 0, stopSlipped: 0 };
  }

  get name() { return profileName(this.settings); }
  get profile() { return PROFILES[this.name]; }
  get active() { return this.name !== 'off'; }
  get feeMult() { return this.profile.feeMult; }

  _between([lo, hi]) { return lo + (hi - lo) * this.rng(); }

  // Alis: sinyal ile dolum arasindaki gecikme + ince emir defteri -> ek kayma yuzdesi (>=0).
  entryExtraSlipPct() { return this.active ? this._between(this.profile.entrySlipPct) : 0; }

  // Satis: stop benzeri cikislar kotu piyasada calisir, daha buyuk ek kayma alir.
  exitExtraSlipPct(reason) {
    if (!this.active) return 0;
    if (STOP_LIKE.test(String(reason || ''))) { this.counts.stopSlipped++; return this._between(this.profile.stopExitSlipPct); }
    return this._between(this.profile.exitSlipPct);
  }

  rejectEntry() {
    if (!this.active || !(this.rng() < this.profile.entryRejectProb)) return false;
    this.counts.entryRejected++;
    return true;
  }

  // 1 = tam dolum; <1 = kismi dolum orani.
  entryFillFraction() {
    if (!this.active || !(this.rng() < this.profile.entryPartialProb)) return 1;
    this.counts.entryPartial++;
    return this._between(this.profile.entryPartialFill);
  }

  failExit() {
    if (!this.active || !(this.rng() < this.profile.exitFailProb)) return false;
    this.counts.exitFailed++;
    return true;
  }

  exitFillFraction() {
    if (!this.active || !(this.rng() < this.profile.exitPartialProb)) return 1;
    this.counts.exitPartial++;
    return this._between(this.profile.exitPartialFill);
  }

  summary() { return { profile: this.name, ...this.counts }; }
}

module.exports = { PaperStress, PROFILES, makeRng, profileName, STOP_LIKE };
