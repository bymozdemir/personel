'use strict';

// Binance Testnet'in hazır verdiği bakiyeler önce sinyal bazlı yönetilir.
// Otonom yeni alım kapasitesi ancak yönetilen açık pozisyon sayısı kullanıcının
// seçtiği sınırın ALTINA indiğinde açılır. Tarama bu aşamada da devam eder.
function resolveAutonomousPhase({ managedPositionCount, selectedCount }) {
  const managed = Math.max(0, Math.floor(Number(managedPositionCount) || 0));
  const limit = Math.max(1, Math.floor(Number(selectedCount) || 1));
  const entrySlots = Math.max(0, limit - managed);
  return {
    managedPositionCount: managed,
    selectedCount: limit,
    entrySlots,
    phase: managed >= limit ? 'gift-management' : 'autonomous-entry',
    canOpenAutonomousEntries: managed < limit
  };
}

function canEnableAutonomousEntry({ selectedAsEntryCandidate, hasOpenPosition }) {
  // Açık pozisyon, strateji/stop yönetimi için zaten tick'e dahil edilir;
  // yeni giriş izni yalnızca tarayıcının bu turda seçtiği boş pariteye verilir.
  return selectedAsEntryCandidate === true && hasOpenPosition !== true;
}

module.exports = { resolveAutonomousPhase, canEnableAutonomousEntry };
