// Exchange verification is evidence, not a user preference.
// ALLOW_*_TRADING is checked separately by LiveEngine as an operator opt-in;
// it must never turn an untested adapter into a verified production adapter.
const ENV_BY_ID = {
  binance: null,
  btcturk: 'ALLOW_BTCTURK_TRADING',
  binancetr: 'ALLOW_BINANCE_TR_TRADING',
  paribu: 'ALLOW_PARIBU_TRADING',
  coinbaseexchange: 'ALLOW_COINBASEEXCHANGE_TRADING',
  kraken: 'ALLOW_KRAKEN_TRADING',
  bitstamp: 'ALLOW_BITSTAMP_TRADING',
  okx: 'ALLOW_OKX_TRADING',
  okxtr: 'ALLOW_OKXTR_TRADING',
  bybittr: 'ALLOW_BYBITTR_TRADING'
};

function liveEnvName(id) { return ENV_BY_ID[String(id || '').toLowerCase()] || null; }

// No environment flag can manufacture exchange-side verification evidence.
// A test may override the property in-process to exercise downstream logic.
function bindLiveVerified(adapter) {
  let override;
  Object.defineProperty(adapter.capabilities, 'liveTradingVerified', {
    enumerable: true,
    configurable: true,
    get() { return override === undefined ? false : override; },
    set(value) { override = Boolean(value); }
  });
}

module.exports = { ENV_BY_ID, liveEnvName, bindLiveVerified };
