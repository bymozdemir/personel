// Volatiliteye gore pozisyon boyutu (Hummingbot'un volatilite-ayarli bariyer fikrinin GUVENLI uyarlamasi).
// Stop mesafesini DEGISTIRMEZ (canli koruyucu stop yolu aynen kalir); bunun yerine oynak pariteye daha az sermaye ayirir:
//   olcek = clamp(hedefATR% / guncelATR%, minScale, 1)      -> yalnizca KUCULTUR, asla buyutmez.
// Varsayilan: kapali (settings.volatilitySizing.enabled=false).
const { atr } = require('./indicators');

const DEFAULTS = Object.freeze({ enabled: false, targetAtrPct: 1.5, atrPeriod: 14, minScale: 0.25 });
const n = (v, fb, min, max, integer = false) => {
  const x = Number(v);
  return Number.isFinite(x) && x >= min && x <= max && (!integer || Number.isInteger(x)) ? x : fb;
};

function normalizeVolatilitySizing(input) {
  const s = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
  return {
    enabled: typeof s.enabled === 'boolean' ? s.enabled : DEFAULTS.enabled,
    targetAtrPct: n(s.targetAtrPct, DEFAULTS.targetAtrPct, 0.05, 50),
    atrPeriod: n(s.atrPeriod, DEFAULTS.atrPeriod, 2, 200, true),
    minScale: n(s.minScale, DEFAULTS.minScale, 0.01, 1)
  };
}

// closedCandles: kapanmis mumlar. Donus 0.01..1; veri/hesap yoksa 1 (boyut degismez, alim engellenmez).
function volatilitySizeScale(closedCandles, config) {
  const cfg = normalizeVolatilitySizing(config);
  if (!cfg.enabled || !Array.isArray(closedCandles) || closedCandles.length < cfg.atrPeriod + 2) return 1;
  const px = Number(closedCandles[closedCandles.length - 1].c);
  const a = atr(closedCandles, cfg.atrPeriod);
  const v = a[a.length - 1];
  if (!(px > 0) || v === null || v === undefined || !(v > 0)) return 1;
  const atrPct = (v / px) * 100;
  return Math.min(1, Math.max(cfg.minScale, cfg.targetAtrPct / atrPct));
}

module.exports = { DEFAULTS, normalizeVolatilitySizing, volatilitySizeScale };
