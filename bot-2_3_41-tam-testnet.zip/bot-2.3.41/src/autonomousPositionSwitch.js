'use strict';

// New-entry candidates must not overwrite the manager of an open position.
// Open positions are switched only by the dedicated historical management scan.
function shouldDeferConfigSwitch({ hasOpenPosition, activeStrategyId, activeTimeframe, candidate } = {}) {
  if (!candidate || candidate.action !== 'buy' || !candidate.strategyId || !candidate.timeframe) {
    return { defer: true, reason: 'no-qualified-candidate' };
  }
  if (hasOpenPosition) {
    return { defer: true, reason: 'position-open' };
  }
  if (String(activeStrategyId || '') === String(candidate.strategyId) &&
      String(activeTimeframe || '') === String(candidate.timeframe)) {
    return { defer: true, reason: 'same-config' };
  }
  return { defer: false, reason: 'flat-position-qualified-candidate' };
}

function buildPositionManagementUpdate({ pair, position, selected, now = new Date().toISOString() } = {}) {
  if (!pair || !position || !selected || !selected.strategyId || !selected.timeframe) return null;
  const strategyId = String(selected.strategyId);
  const timeframe = String(selected.timeframe);
  if (String(pair.strategyId || '') === strategyId && String(pair.timeframe || '') === timeframe) return null;
  const score = Number(selected.score);
  return {
    pair: {
      strategyId, timeframe, params: { ...(selected.params || {}) },
      autonomousManaged: true, autonomousWatchOnly: false,
      managementSelectionPending: false,
      managementScore: Number.isFinite(score) ? score : null,
      managementSelectedAt: now
    },
    position: {
      entryStrategyId: position.entryStrategyId || position.strategyId || pair.strategyId || null,
      entryTimeframe: position.entryTimeframe || pair.timeframe || null,
      activeManagementStrategyId: strategyId,
      activeManagementTimeframe: timeframe,
      managementSwitchedAt: now
      // stopOrderId, tpOrderId, stopPrice, quantity intentionally untouched.
    }
  };
}

module.exports = { shouldDeferConfigSwitch, buildPositionManagementUpdate };
