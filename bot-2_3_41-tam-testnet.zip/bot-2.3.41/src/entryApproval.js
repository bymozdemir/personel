'use strict';
const TTL_MS = 10 * 60 * 1000;
function ensure(state) {
  const a = state.autonomous || (state.autonomous = {});
  if (!['auto','telegram'].includes(a.entryApprovalMode)) a.entryApprovalMode = 'auto';
  if (!Array.isArray(a.pendingEntries)) a.pendingEntries = [];
  if (!a.approvedEntries || typeof a.approvedEntries !== 'object') a.approvedEntries = {};
  return a;
}
// Kimlik tam sembolden türetilir (ilk 8 karakter kesmesi 1000SATS/USDT ve /USDC gibi çiftleri çakıştırıyordu).
function approvalId(symbol, candleT) {
  const base = String(symbol).toUpperCase().replace(/[^A-Z0-9]/g, '');
  let h = 0;
  for (const ch of String(symbol).toUpperCase()) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return `${base.slice(0, 4)}${h.toString(36)}-${Number(candleT).toString(36)}`;
}
function request(state, { symbol, candleT, price, reason, strategyId, timeframe, now = Date.now() }) {
  const a = ensure(state);
  a.pendingEntries = a.pendingEntries.filter(x => Number(x.expiresAt) > now);
  const existing = a.pendingEntries.find(x => x.symbol === symbol && Number(x.candleT) === Number(candleT));
  if (existing) return { created: false, item: existing };
  const item = { id: approvalId(symbol, candleT), symbol, candleT: Number(candleT), price: Number(price), reason: String(reason || '').slice(0,180), strategyId: strategyId || null, timeframe: timeframe || null, createdAt: now, expiresAt: now + TTL_MS };
  a.pendingEntries.push(item);
  a.pendingEntries = a.pendingEntries.slice(-20);
  return { created: true, item };
}
function approve(state, id, now = Date.now()) {
  const a = ensure(state);
  a.pendingEntries = a.pendingEntries.filter(x => Number(x.expiresAt) > now);
  const i = a.pendingEntries.findIndex(x => x.id === id || x.symbol === id);
  if (i < 0) return { ok: false, message: 'Bekleyen onay bulunamadı veya süresi doldu.' };
  const item = a.pendingEntries.splice(i, 1)[0];
  a.approvedEntries[item.symbol] = { id: item.id, candleT: item.candleT, expiresAt: Math.min(item.expiresAt, now + 2 * 60 * 1000) };
  return { ok: true, item };
}
function reject(state, id, now = Date.now()) {
  const a = ensure(state);
  a.pendingEntries = a.pendingEntries.filter(x => Number(x.expiresAt) > now);
  const i = a.pendingEntries.findIndex(x => x.id === id || x.symbol === id);
  if (i < 0) return { ok: false, message: 'Bekleyen onay bulunamadı.' };
  const [item] = a.pendingEntries.splice(i, 1);
  return { ok: true, item };
}
function consume(state, symbol, candleT, now = Date.now()) {
  const a = ensure(state);
  const item = a.approvedEntries[symbol];
  if (!item) return false;
  delete a.approvedEntries[symbol];
  return Number(item.expiresAt) > now && Number(item.candleT) === Number(candleT);
}
function pending(state, now = Date.now()) {
  const a = ensure(state);
  a.pendingEntries = a.pendingEntries.filter(x => Number(x.expiresAt) > now);
  return a.pendingEntries.slice();
}
module.exports = { ensure, request, approve, reject, consume, pending, TTL_MS };
