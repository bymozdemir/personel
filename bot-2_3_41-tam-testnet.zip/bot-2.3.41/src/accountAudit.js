'use strict';

const { normalizeBalances } = require('./reconciliation');

const CASH_LIKE = new Set(['USDT']);

function normalizeTickers(rows) {
  const prices = new Map();
  for (const row of Array.isArray(rows) ? rows : []) {
    const symbol = String(row?.symbol || '').toUpperCase();
    const price = Number(row?.lastPrice ?? row?.price);
    if (!/^[A-Z0-9]{2,20}\/USDT$/.test(symbol) || !Number.isFinite(price) || price <= 0) continue;
    prices.set(symbol.slice(0, -5), price);
  }
  return prices;
}

/**
 * Read-only account inventory report. This helper never submits, cancels, or
 * modifies orders. Sale candidates are only a preview, not an instruction.
 */
async function buildReadOnlyAccountAudit(exchange, { now = () => new Date() } = {}) {
  if (!exchange || exchange.id !== 'binance' || exchange.environment !== 'testnet') {
    throw new Error('Salt-okunur envanter raporu yalnızca Binance Spot Testnet adaptöründe çalışır.');
  }
  if (typeof exchange.fetchBalance !== 'function') throw new Error('Bakiye sorgusu desteklenmiyor.');

  const rawBalances = await exchange.fetchBalance();
  const balances = normalizeBalances(rawBalances);
  let openOrders = [];
  let openOrdersError = null;
  if (typeof exchange.fetchOpenOrders === 'function') {
    try {
      const rows = await exchange.fetchOpenOrders([]);
      if (!Array.isArray(rows)) throw new Error('Açık emir yanıtı dizi değil.');
      openOrders = rows;
    } catch (error) {
      openOrdersError = String(error?.message || error).slice(0, 240);
    }
  } else {
    openOrdersError = 'Açık emir sorgusu desteklenmiyor.';
  }

  let prices = new Map();
  let priceError = null;
  if (typeof exchange.fetchAllTickers24h === 'function') {
    try {
      prices = normalizeTickers(await exchange.fetchAllTickers24h());
    } catch (error) {
      priceError = String(error?.message || error).slice(0, 240);
    }
  } else {
    priceError = 'USDT fiyat listesi desteklenmiyor.';
  }

  const assets = [];
  const saleCandidates = [];
  const unpricedAssets = [];
  let estimatedEquityUSDT = 0;
  let pricedValueUSDT = 0;

  for (const [asset, amount] of Object.entries(balances).sort(([a], [b]) => a.localeCompare(b))) {
    const price = asset === 'USDT' ? 1 : prices.get(asset);
    const value = Number.isFinite(price) ? amount.total * price : null;
    if (value !== null) {
      estimatedEquityUSDT += value;
      pricedValueUSDT += value;
    } else if (amount.total > 0) {
      unpricedAssets.push(asset);
    }

    const row = {
      asset,
      free: amount.free,
      locked: amount.locked,
      total: amount.total,
      priceUSDT: Number.isFinite(price) ? price : null,
      estimatedValueUSDT: value
    };
    assets.push(row);

    if (!CASH_LIKE.has(asset) && amount.free > 0) {
      const candidate = {
        asset,
        symbol: prices.has(asset) ? `${asset}/USDT` : null,
        freeQuantity: amount.free,
        lockedQuantity: amount.locked,
        priceUSDT: Number.isFinite(price) ? price : null,
        estimatedValueUSDT: value === null ? null : amount.free * price,
        status: prices.has(asset) ? 'preview_only' : 'no_direct_usdt_market',
        note: prices.has(asset)
          ? 'Tahmini aday; minimum emir miktarı, komisyon ve işlem kuralları henüz doğrulanmadı.'
          : 'Doğrudan USDT fiyatı bulunamadı; satış adayı olarak doğrulanamadı.'
      };
      saleCandidates.push(candidate);
    }
  }

  saleCandidates.sort((a, b) => (b.estimatedValueUSDT ?? -1) - (a.estimatedValueUSDT ?? -1));

  return {
    readOnly: true,
    ordersSubmitted: 0,
    readyForManualStart: !openOrdersError && !priceError,
    exchange: 'binance',
    environment: 'testnet',
    checkedAt: now().toISOString(),
    quoteAsset: 'USDT',
    freeUSDT: balances.USDT?.free ?? 0,
    lockedUSDT: balances.USDT?.locked ?? 0,
    estimatedEquityUSDT,
    pricedValueUSDT,
    unpricedAssets,
    assets,
    saleCandidates,
    openOrderCount: openOrders.length,
    openOrders: openOrders.map((o) => ({
      orderId: o.orderId ?? null,
      symbol: String(o.symbol || ''),
      side: String(o.side || ''),
      status: String(o.status || ''),
      executedQty: Number(o.executedQty || 0)
    })),
    openOrdersError,
    priceError,
    warning: 'Bu rapor salt okunurdur. Hiçbir satış, alış, iptal veya başka emir gönderilmedi. Tahmini değerler yalnızca doğrudan USDT paritesi bulunan varlıkları kapsar.'
  };
}

module.exports = { buildReadOnlyAccountAudit, normalizeTickers };
