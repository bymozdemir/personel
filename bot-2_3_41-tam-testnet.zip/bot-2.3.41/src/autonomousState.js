'use strict';

// Otonom modun parite durumunu degistiren saf fonksiyonlar (server.js ve testler ortak kullanir).

function restoreManualPairs(state) {
  const a = state.autonomous;
  const snapshot = a.manualEnabledSnapshot;
  if (snapshot && typeof snapshot === 'object') {
    for (const [symbol, enabled] of Object.entries(snapshot)) {
      if (state.pairs[symbol]) state.pairs[symbol].enabled = enabled === true;
    }
  }
  if (Number.isFinite(Number(a.previousMaxConcurrentPositions)) && Number(a.previousMaxConcurrentPositions) > 0) {
    state.settings.maxConcurrentPositions = Number(a.previousMaxConcurrentPositions);
  }
  a.manualEnabledSnapshot = null;
  a.previousMaxConcurrentPositions = null;
  a.managedSymbols = [];
  a.stopping = false;
  a.active = false;
  a.status = 'idle';
}


// Borsanın keşif evrenindeki pariteleri Ayarlar'daki izleme listesine ekler.
// Bunlar watch-only'dir: motor enabled=false nedeniyle alım/satım kararı üretmez;
// otonom tarayıcı daha sonra seçerse aynı kayıt yönetilen pariteye dönüştürülür.
function addWatchOnlyPairs(state, symbols) {
  if (!state.pairs || typeof state.pairs !== 'object') state.pairs = {};
  const strategies = require('./strategies');
  const strategy = strategies.get('trend_regime'); // izleme etiketi: seyrek sinyalli rsi_ema_macd değil, trend stratejisi
  const added = [];
  for (const raw of (Array.isArray(symbols) ? symbols : [])) {
    const symbol = String(raw || '').toUpperCase();
    if (!/^[A-Z0-9]{2,20}\/[A-Z0-9]{2,10}$/.test(symbol) || state.pairs[symbol]) continue;
    state.pairs[symbol] = {
      symbol, enabled: false, strategyId: strategy.id, timeframe: '1h', budgetPct: 0,
      params: { ...strategy.defaultParams }, portfolioClass: 'core',
      autonomousManaged: false, autonomousWatchOnly: true
    };
    added.push(symbol);
  }
  return added;
}

function removeUnheldAutonomousPairs(state, hasAutonomousPosition) {
  const a = state.autonomous;
  for (const symbol of [...(a.managedSymbols || [])]) {
    if (hasAutonomousPosition(symbol)) {
      if (state.pairs[symbol]) state.pairs[symbol].enabled = false; // motor acik pozisyonu yine yonetir, yeni alim yapmaz
    } else if (state.pairs[symbol]?.autonomousManaged) {
      // Pozisyon kapandıysa otonom kayıt Ayarlar listesinden çıkarılır.
      // Piyasa tarayıcısı her döngüde borsa evrenini baştan taradığı için
      // coin daha sonra yeniden alıma uygunsa watchlist kaydı gerekmez.
      delete state.pairs[symbol];
    }
  }
}

// Acil durdurma: otonom tarama biter, kullanicinin manuel parite ayarlari ve pozisyon siniri GERI YUKLENIR
// (eskiden geri yuklenmiyor, manuel coinler kapali kaliyor ve sonraki otonom baslangici bu kapali hali
// "kullanici ayari" diye kaydedip eski ayarlari kalici kaybettiriyordu). Acik pozisyonlu otonom pariteler
// yonetilen liste olarak kalir; yeni alim yapmaz.
function applyEmergencyStop(state, hasAutonomousPosition, message) {
  const a = state.autonomous || (state.autonomous = {});
  const managedBefore = [...(a.managedSymbols || [])];
  const held = managedBefore.filter((symbol) => hasAutonomousPosition(symbol));
  removeUnheldAutonomousPairs(state, hasAutonomousPosition);
  restoreManualPairs(state);
  a.managedSymbols = held.filter((symbol) => state.pairs[symbol]?.autonomousManaged);
  for (const symbol of a.managedSymbols) state.pairs[symbol].enabled = false;
  a.active = false;
  a.stopping = false;
  a.status = 'emergency_stopped';
  a.message = message;
  return a;
}

module.exports = { restoreManualPairs, addWatchOnlyPairs, removeUnheldAutonomousPairs, applyEmergencyStop };
