'use strict';

// Aggregate only closed paper trades with explicit strategy/timeframe attribution.
// Legacy trades without those fields are intentionally excluded rather than guessed.
function buildPaperStrategyTradeStats(trades) {
  const stats = {};
  for (const trade of Array.isArray(trades) ? trades : []) {
    const strategyId = String(trade?.strategyId || '').trim();
    const timeframe = String(trade?.timeframe || '').trim();
    if (!strategyId || !timeframe) continue;
    const key = `${strategyId}/${timeframe}`;
    if (!stats[key]) stats[key] = { trades: 0, netPnl: 0, wins: 0 };
    stats[key].trades += 1;
    const pnl = Number(trade.pnl);
    if (Number.isFinite(pnl)) {
      stats[key].netPnl += pnl;
      if (pnl > 0) stats[key].wins += 1;
    }
  }
  return stats;
}

module.exports = { buildPaperStrategyTradeStats };
