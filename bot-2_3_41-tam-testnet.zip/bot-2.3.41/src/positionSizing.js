// src/positionSizing.js
// Jesse'nin risk_to_qty mantığının (işlem başına risk yüzdesi) bu bota uyarlanmış SAF hali.
//
// Fikir: stop-loss tetiklenirse kaybedilecek tutar = alım tutarı * stop%. Kullanıcı "bir işlemde
// kasanın en fazla %R'sini riske atarım" derse alım tutarı en fazla  kasa * R% / stop%  olur.
//
// Güvenlik tasarımı: bu fonksiyon yalnızca tutarı KÜÇÜLTEBİLİR. Mevcut bütçe, maxTradeQuote,
// portföy politikası ve borsa minimumları aynen geçerlidir; bu katman hiçbirini gevşetmez.
// riskPct = 0 (varsayılan) = kapalı. Etkin risk kontrolünde geçersiz girdi fail-closed olur.

function capByRisk({ amount, equity, riskPct, stopLossPct }) {
  const a = Number(amount);
  if (!Number.isFinite(a) || a <= 0) return { amount: a, capped: false, cap: null };
  // Only an explicit zero disables the optional risk cap. Missing, malformed,
  // negative or out-of-range settings must not silently turn risk sizing off.
  if (riskPct === 0 || riskPct === '0') return { amount: a, capped: false, cap: null };
  const r = Number(riskPct);
  const eq = Number(equity);
  const sl = Number(stopLossPct);
  if (!Number.isFinite(r) || r <= 0 || r > 10 || !(eq > 0) || !Number.isFinite(eq) || !(sl > 0) || sl >= 100 || !Number.isFinite(sl)) {
    return { amount: 0, capped: false, cap: 0, invalid: true };
  }
  const cap = (eq * (r / 100)) / (sl / 100);
  if (!Number.isFinite(cap) || cap <= 0) return { amount: a, capped: false, cap: null, invalid: true };
  return cap < a ? { amount: cap, capped: true, cap } : { amount: a, capped: false, cap };
}

module.exports = { capByRisk };
