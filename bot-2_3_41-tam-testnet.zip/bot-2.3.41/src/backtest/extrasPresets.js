// Portfoy backtest icin hazir ek katman ayarlari (--extras koruma | tam | {json} | @dosya.json).
// Bunlar BASLANGIC noktasidir, optimize edilmis degerler degildir.
const fs = require('fs');

const PRESETS = {
  koruma: {
    protections: { enabled: true,
      cooldown: { enabled: true, minutes: 240 },
      stoplossGuard: { enabled: true, tradeLimit: 3, lookbackMinutes: 7 * 24 * 60, lockMinutes: 24 * 60 },
      maxDrawdown: { enabled: true, tradeLimit: 6, lookbackMinutes: 14 * 24 * 60, maxDrawdownPct: 6, lockMinutes: 3 * 24 * 60 } }
  },
  tam: {
    protections: { enabled: true,
      cooldown: { enabled: true, minutes: 240, adverseMinutes: 480 },
      stoplossGuard: { enabled: true, tradeLimit: 3, lookbackMinutes: 7 * 24 * 60, lockMinutes: 24 * 60 },
      maxDrawdown: { enabled: true, tradeLimit: 6, lookbackMinutes: 14 * 24 * 60, maxDrawdownPct: 6, lockMinutes: 3 * 24 * 60 },
      lowProfitPairs: { enabled: true, tradeLimit: 4, lookbackMinutes: 14 * 24 * 60, requiredProfitPct: 0, lockMinutes: 3 * 24 * 60 },
      equityDrawdown: { enabled: true, maxDrawdownPct: 6, lookbackMinutes: 7 * 24 * 60, emaSamples: 3 } },
    pairFilters: { enabled: true, minCandles: 200 },
    timeBarrier: { enabled: true, maxHoldBars: 60, minProfitPct: 0.5 },
    forager: { enabled: true, volumeDropPct: 20, spanBars: 20, weights: { volume: 1, volatility: 1, unilateralness: 0.5 } },
    volatilitySizing: { enabled: true, targetAtrPct: 1.5, minScale: 0.25 }
  }
};

function parseExtras(arg) {
  if (arg === undefined || arg === null || arg === '') return null;
  if (PRESETS[arg]) return JSON.parse(JSON.stringify(PRESETS[arg]));
  let text = String(arg);
  if (text.startsWith('@')) {
    try { text = fs.readFileSync(text.slice(1), 'utf8'); }
    catch (e) { throw new Error(`--extras dosyası okunamadı: ${e.message}`); }
  }
  let v;
  try { v = JSON.parse(text); } catch (e) { throw new Error(`--extras geçerli JSON ya da hazır ayar adı (${Object.keys(PRESETS).join(', ')}) olmalı.`); }
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('--extras bir JSON nesnesi olmalı.');
  const known = ['protections', 'pairFilters', 'timeBarrier', 'forager', 'volatilitySizing'];
  const bad = Object.keys(v).filter((k) => !known.includes(k));
  if (bad.length) throw new Error(`--extras bilinmeyen anahtar: ${bad.join(', ')} (geçerli: ${known.join(', ')})`);
  return v;
}

module.exports = { PRESETS, parseExtras };
