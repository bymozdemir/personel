'use strict';

// Select only as many top-ranked autonomous candidates as can plausibly meet
// exchange minimums with spendable quote cash. The requested count is a ceiling,
// never a target. Unknown balance/rules fail closed for new entries.
function quoteBalanceFromLive(lastBalance, quoteAsset) {
  const quote = String(quoteAsset || '').toUpperCase();
  if (!quote || !lastBalance || typeof lastBalance !== 'object') return null;
  // BinanceAdapter.fetchBalance() and ReconciliationService expose balances
  // as an asset-keyed map: { USDT: { free, locked }, ... }.
  // Keep array support for adapters/legacy snapshots using [{ asset, free }].
  const row = Array.isArray(lastBalance)
    ? lastBalance.find((x) => String(x?.asset || x?.currency || '').toUpperCase() === quote)
    : lastBalance[quote];
  if (!row) return 0;
  const free = Number(row.free ?? row.available ?? row.availableBalance);
  return Number.isFinite(free) && free >= 0 ? free : null;
}

async function selectAffordableCandidates({ candidates = [], maxCount, mode = 'paper', quoteAsset = 'USDT', paperCash, liveLastBalance,
  reserveCashPct = 10, maxTradeQuote = 0, exchange, feePct = 0.1, slippagePct = 0.05 } = {}) {
  const limit = Math.max(0, Math.min(100, Math.floor(Number(maxCount) || 0)));
  let available = mode === 'paper' ? Number(paperCash) : quoteBalanceFromLive(liveLastBalance, quoteAsset);
  if (!Number.isFinite(available) || available < 0) {
    return { selected: [], availableQuote: null, spendableQuote: 0, cashBlockedCandidates: 0, reason: 'kullanılabilir kasa doğrulanamadı; yeni alım güvenli tarafta durduruldu' };
  }
  const reserve = Math.max(0, Math.min(90, Number(reserveCashPct) || 0));
  const spendable = Math.max(0, available * (1 - reserve / 100));
  const fee = Math.max(0, Number(feePct) || 0) / 100;
  const slip = Math.max(0, Number(slippagePct) || 0) / 100;
  if (!limit || !Array.isArray(candidates) || !candidates.length) {
    return { selected: [], availableQuote: available, spendableQuote: spendable, cashBlockedCandidates: 0, reason: 'uygun aday yok' };
  }
  const ranked = [...candidates].sort((a, b) => Number(b.score || 0) - Number(a.score || 0));
  const selected = [];
  let reserved = 0;
  let cashBlockedCandidates = 0;
  for (const candidate of ranked) {
    if (selected.length >= limit) break;
    if (!candidate?.symbol || !exchange || typeof exchange.fetchSymbolRules !== 'function') continue;
    let rules;
    try { rules = await exchange.fetchSymbolRules(candidate.symbol); } catch (_) { continue; }
    const minNotional = Number(rules?.minNotional ?? rules?.minNotionalValue ?? rules?.minOrderValue);
    if (!(Number.isFinite(minNotional) && minNotional > 0)) continue;
    const minRequired = minNotional * (1 + fee + slip) * 1.01;
    const perTradeCap = Number(maxTradeQuote) > 0 ? Number(maxTradeQuote) : Infinity;
    if (minRequired > perTradeCap) continue;
    if (reserved + minRequired > spendable + 1e-9) { cashBlockedCandidates += 1; continue; }
    selected.push({ ...candidate, minRequired });
    reserved += minRequired;
  }
  return {
    selected,
    availableQuote: available,
    spendableQuote: spendable,
    minimumsReserved: reserved,
    cashBlockedCandidates,
    reason: selected.length ? `${selected.length} aday minimum emir, ücret ve nakit rezervi koşullarını karşılıyor` : 'yeterli harcanabilir bakiye ile minimum emir koşullarını karşılayan aday yok'
  };
}

module.exports = { quoteBalanceFromLive, selectAffordableCandidates };
