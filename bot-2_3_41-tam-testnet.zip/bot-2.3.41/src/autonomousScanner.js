'use strict';

const { splitCandles, validateCandleSeries, timeframeMs } = require('./execution');
const strategies = require('./strategies');
const forager = require('./forager');
const { runBacktest } = require('./backtest/simulator');
const tfPolicy = require('./timeframePolicy');

const STABLE_BASES = new Set(['USDT','USDC','FDUSD','TUSD','USDP','DAI','USDE','BUSD','EUR','TRY']);
const ALLOWED_COUNTS = Object.freeze([1, 2, 4, 8, 16, 32]);
const DEFAULT_CANDIDATE_LIMIT = 24;
const DEFAULT_SCAN_BATCH_SIZE = 48; // auto modda operatörce seçilirse; varsayılan sunucu ayarı tüm evreni tarar
// Last completed market per quote asset, so automatic scans rotate through the full universe.
const scanCursorByQuote = new Map();
// 2.3.34: Çekirdek+kuyruk taramasında kuyruk diliminin sırası (kasa birimi başına).
const tailSliceByQuote = new Map();
const DEFAULT_CORE_LIMIT = 160;
const DEFAULT_TAIL_SLICES = 4;
const TIMEFRAMES = Object.freeze(['5m', '15m', '30m', '1h', '4h']);
const MIN_BACKTEST_TRADES = 2;
const MIN_BACKTEST_BARS = 60;
const MAX_BACKTEST_DRAWDOWN_PCT = 20;
const PAPER_CONFIDENCE_TRADES = 4;
const WALK_FORWARD_STARTS = Object.freeze([0.60, 0.70, 0.80]);

function normalizeRequest(input = {}) {
  const count = Number(input.count === undefined ? 1 : input.count);
  if (!ALLOWED_COUNTS.includes(count)) throw new Error(`Coin sayısı şu değerlerden biri olmalı: ${ALLOWED_COUNTS.join(', ')}.`);
  // Strategy/timeframe input is deliberately ignored: autonomous mode owns both decisions.
  return { count };
}
function quoteOf(symbol) {
  const parts = String(symbol || '').toUpperCase().split('/');
  return parts.length === 2 ? parts[1] : '';
}
function isCandidateSymbol(symbol) {
  const [base, quote] = String(symbol || '').toUpperCase().split('/');
  if (!base || !quote || base === quote || STABLE_BASES.has(base)) return false;
  if (/(UP|DOWN|BULL|BEAR|2L|2S|3L|3S)$/.test(base)) return false;
  return true;
}
async function mapLimit(items, concurrency, fn) {
  const results = new Array(items.length);
  let cursor = 0;
  async function worker() {
    while (true) {
      const i = cursor++;
      if (i >= items.length) return;
      try { results[i] = await fn(items[i], i); }
      catch (error) { results[i] = { error: String(error?.message || error).slice(0, 220) }; }
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, () => worker()));
  return results;
}

function strategyParams(strategy) {
  const params = { ...strategy.defaultParams };
  const invalid = strategies.validateParams(strategy.id, params);
  return invalid ? { params, invalid } : { params, invalid: null };
}

// Paper trade count changes confidence only; it never blocks an otherwise valid candidate.
function paperConfidence(strategyId, timeframe, paperTradeStats = {}) {
  const key = `${strategyId}/${timeframe}`;
  const row = paperTradeStats[key] || {};
  const trades = Math.max(0, Number(row.trades) || 0);
  const pnl = Number(row.netPnl);
  if (trades < PAPER_CONFIDENCE_TRADES) return { level: 'low', trades, requiredForReview: PAPER_CONFIDENCE_TRADES, reason: `Paper geçmişi başlangıç aşamasında (${trades}/${PAPER_CONFIDENCE_TRADES} kapanmış işlem); strateji kapatılmaz` };
  if (Number.isFinite(pnl) && pnl <= 0) return { level: 'low', trades, requiredForReview: PAPER_CONFIDENCE_TRADES, reason: 'Paper net sonucu şu ana kadar pozitif değil; adaylık sürer, güven düşüktür' };
  return { level: 'medium', trades, requiredForReview: PAPER_CONFIDENCE_TRADES, reason: 'Paper işlem geçmişi ilk değerlendirme eşiğine ulaştı; performans izlenmeye devam eder' };
}

// Use a chronological holdout, not the current signal alone, to rank strategies.
// The simulator executes signals on the next candle and includes fee/slippage assumptions.
function evaluateHistorical({ candles, strategy, params, backtestRunner = runBacktest, feePct = 0.1, slippagePct = 0.05 }) {
  const minimum = strategy.minCandles(params) + 1;
  const startIndex = Math.max(minimum, Math.floor(candles.length * 0.60));
  const holdoutBars = candles.length - startIndex;
  if (holdoutBars < MIN_BACKTEST_BARS) {
    return { eligible: false, score: -Infinity, reason: `Geçmiş doğrulama için yeterli mum yok (${holdoutBars}/${MIN_BACKTEST_BARS})` };
  }
  const costs = { feePct: Math.max(0.1, Number(feePct) || 0), slippagePct: Math.max(0.05, Number(slippagePct) || 0) };
  const runWindow = (idx) => backtestRunner({ candles, startIndex: idx, strategy, params, capital: 1000, ...costs });
  let metrics;
  try { metrics = runWindow(startIndex); }
  catch (error) { return { eligible: false, score: -Infinity, reason: `Geçmiş doğrulama hatası: ${String(error?.message || error).slice(0, 100)}` }; }
  const trades = Number(metrics?.trades);
  const ret = Number(metrics?.returnPct);
  const drawdown = Number(metrics?.maxDrawdownPct);
  const profitFactor = metrics?.profitFactor == null ? Infinity : Number(metrics.profitFactor);
  const secondHalf = Number(metrics?.secondHalfPct);
  if (![trades, ret, drawdown].every(Number.isFinite)) return { eligible: false, score: -Infinity, reason: 'Geçmiş doğrulama ölçümleri geçersiz' };
  if (trades < MIN_BACKTEST_TRADES) return { eligible: false, score: -Infinity, reason: `Geçmiş doğrulamada yeterli işlem yok (${trades}/${MIN_BACKTEST_TRADES})` };
  if (ret <= 0) return { eligible: false, score: -Infinity, reason: 'Maliyetler sonrası geçmiş getiri pozitif değil' };
  if (drawdown < -MAX_BACKTEST_DRAWDOWN_PCT) return { eligible: false, score: -Infinity, reason: 'Geçmiş düşüş sınırı aşıldı' };
  if (Number.isFinite(profitFactor) && profitFactor < 1.05) return { eligible: false, score: -Infinity, reason: 'Geçmiş kâr faktörü yetersiz' };
  if (Number.isFinite(secondHalf) && secondHalf < -3) return { eligible: false, score: -Infinity, reason: 'Son dönem performansı zayıf' };

  // Additional chronological windows measure robustness. They affect confidence/score,
  // but do NOT veto a candidate: sparse history must not create a cold-start deadlock.
  const windows = [];
  for (const fraction of WALK_FORWARD_STARTS) {
    const idx = Math.max(minimum, Math.floor(candles.length * fraction));
    if (candles.length - idx < MIN_BACKTEST_BARS || idx === startIndex) continue;
    try {
      const m = idx === startIndex ? metrics : runWindow(idx);
      const r = Number(m?.returnPct), dd = Number(m?.maxDrawdownPct), nTrades = Number(m?.trades);
      const pf = m?.profitFactor == null ? Infinity : Number(m.profitFactor);
      const ok = Number.isFinite(r) && Number.isFinite(dd) && Number.isFinite(nTrades) && nTrades >= MIN_BACKTEST_TRADES && r > 0 && dd >= -MAX_BACKTEST_DRAWDOWN_PCT && (!Number.isFinite(pf) || pf >= 1.05);
      windows.push({ startIndex: idx, trades: Number.isFinite(nTrades) ? nTrades : 0, returnPct: Number.isFinite(r) ? r : null, maxDrawdownPct: Number.isFinite(dd) ? dd : null, eligible: ok });
    } catch (_) { windows.push({ startIndex: idx, eligible: false, reason: 'Pencere doğrulama hatası' }); }
  }
  const tested = windows.filter((w) => Number.isFinite(w.returnPct));
  const robustCount = tested.filter((w) => w.eligible).length;
  const robustness = tested.length ? robustCount / tested.length : 0;
  const pf = Number.isFinite(profitFactor) ? Math.min(3, profitFactor) : 1;
  const winRate = Number.isFinite(Number(metrics.winRatePct)) ? Number(metrics.winRatePct) : 0;
  const baseScore = ret - Math.abs(Math.min(0, drawdown)) * 0.35 + pf * 0.75 + winRate * 0.015;
  // Additive bounded adjustment: multiplying a negative base score by a smaller
  // consistency factor would perversely reward less-consistent candidates.
  // This adjustment is capped and cannot replace the net-return/risk checks.
  const consistencyAdjustment = (robustness - 0.5) * Math.min(1, Math.max(0.25, Math.abs(baseScore) * 0.10));
  const score = baseScore + consistencyAdjustment;
  const historicalConfidence = tested.length >= 2 && robustness >= 0.75 ? 'medium' : 'low';
  return { eligible: Number.isFinite(score), score, metrics: {
    trades, returnPct: ret, maxDrawdownPct: drawdown,
    profitFactor: Number.isFinite(profitFactor) ? profitFactor : null,
    winRatePct: Number.isFinite(Number(metrics.winRatePct)) ? Number(metrics.winRatePct) : null,
    secondHalfPct: Number.isFinite(secondHalf) ? secondHalf : null,
    walkForward: { testedWindows: tested.length, robustWindows: robustCount, consistencyPct: Math.round(robustness * 100), confidence: historicalConfidence, windows }
  }, reason: 'Ana geçmiş doğrulama geçti; ek dönemler güven puanına yansıtıldı' };
}

// Sıkı doğrulamadan geçen profil yoksa, o coine ait mum verisiyle en iyi giden strateji/mum aralığı yine de seçilir
// (coin başına ayrı uyarlama). Skor, sıkı yöntemle aynı formüldür; yalnızca "pozitif getiri/en az işlem/kâr faktörü"
// kapıları uygulanmaz. Hiç işlem üretmeyen ya da hesaplanamayan kombinasyonlar elenir.
function evaluateRelaxed({ candles, strategy, params, backtestRunner = runBacktest, feePct = 0.1, slippagePct = 0.05 }) {
  const minimum = strategy.minCandles(params) + 1;
  const startIndex = Math.max(minimum, Math.floor(candles.length * 0.60));
  if (candles.length - startIndex < MIN_BACKTEST_BARS) return null;
  let metrics;
  try {
    metrics = backtestRunner({ candles, startIndex, strategy, params, capital: 1000,
      feePct: Math.max(0.1, Number(feePct) || 0), slippagePct: Math.max(0.05, Number(slippagePct) || 0) });
  } catch (_) { return null; }
  const trades = Number(metrics?.trades), ret = Number(metrics?.returnPct), dd = Number(metrics?.maxDrawdownPct);
  if (![trades, ret, dd].every(Number.isFinite) || trades < 1) return null;
  const pfRaw = metrics?.profitFactor == null ? Infinity : Number(metrics.profitFactor);
  const pf = Number.isFinite(pfRaw) ? Math.min(3, pfRaw) : 1;
  const winRate = Number.isFinite(Number(metrics.winRatePct)) ? Number(metrics.winRatePct) : 0;
  const score = ret - Math.abs(Math.min(0, dd)) * 0.35 + pf * 0.75 + winRate * 0.015;
  if (!Number.isFinite(score)) return null;
  return { score, metrics: { trades, returnPct: ret, maxDrawdownPct: dd, profitFactor: Number.isFinite(pfRaw) ? pfRaw : null,
    winRatePct: Number.isFinite(Number(metrics.winRatePct)) ? Number(metrics.winRatePct) : null } };
}

async function scanBuyCandidates({ exchange, quoteAsset = 'USDT', candidateLimit = 'auto', strategyIds = null, timeframes = null, scanBatchSize = Number(process.env.BOT_SCAN_BATCH_SIZE) || DEFAULT_SCAN_BATCH_SIZE,
  minQuoteVolume = 0, coreLimit = 0, tailSlices = DEFAULT_TAIL_SLICES, now = Date.now(), concurrency = 2, pollSeconds = 60, mode = 'paper',
  exchangeId = '', feePct = 0.1, slippagePct = 0.05, backtestRunner = runBacktest, paperTradeStats = {}, onProgress = null } = {}) {
  if (!exchange || typeof exchange.fetchAllTickers24h !== 'function' || typeof exchange.fetchCandles !== 'function') {
    throw new Error('Borsa tarayıcısı hazır değil.');
  }
  const quote = String(quoteAsset || '').toUpperCase();
  if (!quote) throw new Error('Kasa birimi belirlenemedi.');
  // Kullanıcının otonom için işaretlediği stratejiler/mumlar (null = kısıt yok; sunucu varsayılanı ayrıca süzer).
  const strategyList = strategies.list().filter((row) => !Array.isArray(strategyIds) || strategyIds.includes(row.id)).map((row) => strategies.get(row.id));
  const activeTimeframes = TIMEFRAMES.filter((timeframe) => !Array.isArray(timeframes) || timeframes.includes(timeframe));
  const validStrategies = strategyList.map((strategy) => ({ strategy, ...strategyParams(strategy) }));
  const progress = (done, total) => { if (typeof onProgress === 'function') { try { onProgress({ done, total }); } catch (_) { /* ilerleme bildirimi taramayı bozmaz */ } } };
  progress(0, 0);
  const tickers = await exchange.fetchAllTickers24h();
  const eligibleTickers = (Array.isArray(tickers) ? tickers : []).filter((ticker) => {
    const symbol = String(ticker?.symbol || '').toUpperCase();
    const volume = Number(ticker?.quoteVolume), price = Number(ticker?.lastPrice ?? ticker?.price);
    return /^[A-Z0-9]{2,20}\/[A-Z0-9]{2,10}$/.test(symbol) && isCandidateSymbol(symbol) && quoteOf(symbol) === quote &&
      Number.isFinite(volume) && volume >= minQuoteVolume && Number.isFinite(price) && price > 0 &&
      (!exchange.quoteAssets?.length || exchange.quoteAssets.includes(quote));
  }).sort((a, b) => Number(b.quoteVolume) - Number(a.quoteVolume));
  // `all` evaluates every eligible ticker in this cycle. The server defaults to `all`
  // so scan coverage is explicit; operators can opt into round-robin batches with
  // BOT_SCAN_CANDIDATE_LIMIT=auto and BOT_SCAN_BATCH_SIZE to reduce exchange API load.
  const rawLimit = String(candidateLimit ?? 'auto').trim().toLowerCase();
  const allCandidates = rawLimit === 'all' || rawLimit === '0';
  const autoBatch = rawLimit === 'auto' || rawLimit === '';
  const parsedLimit = Number(rawLimit);
  const requestedLimit = allCandidates
    ? eligibleTickers.length
    : Math.max(1, Math.min(1000, autoBatch
      ? (Number.isFinite(Number(scanBatchSize)) && Number(scanBatchSize) > 0 ? Math.min(1000, Math.floor(Number(scanBatchSize))) : DEFAULT_SCAN_BATCH_SIZE)
      : (Number.isFinite(parsedLimit) && parsedLimit > 0 ? parsedLimit : DEFAULT_CANDIDATE_LIMIT)));
  let candidates;
  // 2.3.34 çekirdek+kuyruk: `all` modunda coreLimit > 0 ise hacme göre ilk coreLimit coin HER turda, kalan kuyruk ise tailSlices
  // dilime bölünüp her turda bir dilim taranır (tüm kuyruk tailSlices turda bir kez görülür). Sinyaller likit coinlerde yoğunlaşır.
  const coreN = Math.max(0, Math.floor(Number(coreLimit) || 0));
  const sliceCount = Math.max(1, Math.min(16, Math.floor(Number(tailSlices) || DEFAULT_TAIL_SLICES)));
  let tiered = null;
  if (allCandidates && coreN > 0 && coreN < eligibleTickers.length) {
    const tail = eligibleTickers.slice(coreN);
    const slice = (tailSliceByQuote.get(quote) || 0) % sliceCount;
    tailSliceByQuote.set(quote, (slice + 1) % sliceCount);
    candidates = eligibleTickers.slice(0, coreN).concat(tail.filter((_, i) => i % sliceCount === slice));
    tiered = { core: coreN, tailTotal: tail.length, tailScanned: candidates.length - coreN, slice: slice + 1, slices: sliceCount };
  } else if (allCandidates || !autoBatch || eligibleTickers.length <= requestedLimit) {
    candidates = eligibleTickers.slice(0, requestedLimit);
  } else {
    const lastSymbol = scanCursorByQuote.get(quote);
    const lastIndex = lastSymbol ? eligibleTickers.findIndex((ticker) => String(ticker.symbol).toUpperCase() === lastSymbol) : -1;
    const start = lastIndex >= 0 ? (lastIndex + 1) % eligibleTickers.length : 0;
    candidates = Array.from({ length: requestedLimit }, (_, i) => eligibleTickers[(start + i) % eligibleTickers.length]);
    scanCursorByQuote.set(quote, String(candidates[candidates.length - 1]?.symbol || '').toUpperCase());
  }

  progress(0, candidates.length);
  let doneCount = 0;
  const evaluateOne = async (ticker) => {
    const symbol = String(ticker.symbol).toUpperCase();
    const choices = [];
    const errors = [];
    await mapLimit(activeTimeframes, 3, async (timeframe) => {
      // Fetch only intervals permitted for this account mode, strategy and exchange.
      const usableStrategies = validStrategies.filter(({ strategy, invalid }) => !invalid &&
        !tfPolicy.timeframeProblem({ timeframe, strategyId: strategy.id, pollSeconds, mode, exchangeId, autonomous: true }));
      if (!usableStrategies.length) return;
      let closed;
      try {
        const maxRequired = Math.max(...usableStrategies.map(({ strategy, params }) => strategy.minCandles(params)));
        const limit = Math.min(1000, Math.max(180, maxRequired + 100));
        const candles = await exchange.fetchCandles(symbol, timeframe, limit);
        validateCandleSeries(candles, timeframe);
        closed = splitCandles(candles, now, timeframe).closed;
        const last = closed[closed.length - 1];
        if (!last || !Number.isFinite(Number(last.c)) || Number(last.c) <= 0) throw new Error('Kapanmış mum fiyatı geçersiz.');
        const tfMs = timeframeMs(timeframe), ageMs = Number(now) - Number(last.t);
        const maxAgeMs = Math.max(2 * (tfMs || 0), 5 * Math.max(15, Number(pollSeconds) || 60) * 1000, 5 * 60 * 1000);
        if (ageMs > maxAgeMs) throw new Error(`eski piyasa verisi (${Math.round(ageMs / 60000)} dk)`);
        if (ageMs < -Math.max(5 * 60 * 1000, 2 * Math.max(15, Number(pollSeconds) || 60) * 1000)) throw new Error('piyasa verisi sistem saatinden ileride');
        for (const { strategy, params } of usableStrategies) {
          try {
            if (closed.length < strategy.minCandles(params) + 2) continue;
            const decision = strategy.evaluate({ candles: closed, position: null, params });
            if (decision?.action !== 'buy') continue;
            const historical = evaluateHistorical({ candles: closed, strategy, params, backtestRunner, feePct, slippagePct });
            if (!historical.eligible) {
              errors.push(`${strategy.id}/${timeframe}: ${historical.reason}`);
              continue;
            }
            const agePenalty = ageMs > tfMs ? Math.min(1, ageMs / (2 * tfMs)) : 0;
            const freshness = Math.max(0, 1 - agePenalty * 0.2);
            choices.push({ symbol, quoteVolume: Number(ticker.quoteVolume) || 0,
              lastPrice: Number(ticker.lastPrice ?? ticker.price ?? last.c),
              changePct: Number(ticker.changePct ?? ticker.priceChangePercent ?? 0) || 0,
              action: 'buy', reason: String(decision.reason || 'Kapanmış mumlarda alım sinyali; geçmiş doğrulama geçti').slice(0, 220),
              price: Number(decision.price ?? last.c), candleTime: Number(last.t), strategyId: strategy.id,
              strategyName: strategy.name, timeframe, score: historical.score * freshness,
              historicalValidation: historical.metrics, paperConfidence: paperConfidence(strategy.id, timeframe, paperTradeStats), rankingCandles: closed });
          } catch (error) { errors.push(`${strategy.id}: ${String(error?.message || error).slice(0, 70)}`); }
        }
      } catch (error) { errors.push(`${timeframe}: ${String(error?.message || error).slice(0, 100)}`); }
    });
    if (choices.length) return choices.sort((a, b) => b.score - a.score)[0];
    return { symbol, quoteVolume: Number(ticker.quoteVolume) || 0,
      lastPrice: Number(ticker.lastPrice ?? ticker.price) || 0,
      changePct: Number(ticker.changePct ?? ticker.priceChangePercent ?? 0) || 0,
      action: errors.length ? 'error' : 'hold', reason: errors.length ? [...new Set(errors)].slice(0, 3).join('; ') : 'Geçerli strateji/zaman dilimi için doğrulanmış alım sinyali yok' };
  };
  const evaluated = await mapLimit(candidates, Math.max(1, Math.min(3, Number(concurrency) || 2)), async (ticker) => {
    try { return await evaluateOne(ticker); }
    finally { doneCount += 1; progress(doneCount, candidates.length); }
  });

  const rankable = evaluated.filter((row) => row.action === 'buy' && Array.isArray(row.rankingCandles));
  const rank = forager.rankCandidates(rankable.map((row) => ({ symbol: row.symbol, candles: row.rankingCandles })), {
    enabled: true, spanBars: 20, weights: { volume: 1, volatility: 0.5, unilateralness: 0.5 }
  });
  const scoreBySymbol = rank.scores;
  // Historical holdout performance is the primary selector. Liquidity/market
  // structure is a tie-breaker, never a substitute for strategy evidence.
  const eligible = rankable.sort((a, b) => b.score - a.score ||
    (scoreBySymbol.get(b.symbol) ?? 0) - (scoreBySymbol.get(a.symbol) ?? 0) || b.quoteVolume - a.quoteVolume);
  const publicResults = evaluated.map((row) => {
    const { rankingCandles, ...result } = row;
    if (result.action === 'buy') result.score = Number((result.score ?? 0).toFixed(4));
    return result;
  });
  const timeframesTested = activeTimeframes.filter((timeframe) => validStrategies.some(({ strategy, invalid }) => !invalid &&
    !tfPolicy.timeframeProblem({ timeframe, strategyId: strategy.id, pollSeconds, mode, exchangeId, autonomous: true })));
  const actionCounts = publicResults.reduce((acc, row) => { const key = row.action || 'unknown'; acc[key] = (acc[key] || 0) + 1; return acc; }, {});
  const reasonCounts = publicResults.reduce((acc, row) => {
    const reason = String(row.reason || 'Belirtilmemiş');
    const category = row.action === 'error' ? 'veri_hatasi' : row.action === 'buy' ? 'alım_sinyali' : /yeterli mum|geçmiş doğrulama|strateji/i.test(reason) ? 'strateji_ve_gecmis_filtresi' : /eski piyasa verisi|sistem saatinden/i.test(reason) ? 'veri_guncelligi' : 'sinyal_yok';
    acc[category] = (acc[category] || 0) + 1; return acc;
  }, {});
  return { scanned: candidates.length, universeSize: eligibleTickers.length, universeSymbols: eligibleTickers.map((ticker) => String(ticker.symbol).toUpperCase()), actionCounts, reasonCounts, scanBatchSize: candidates.length, scanMode: tiered ? 'core+tail' : (autoBatch ? 'round_robin' : (allCandidates ? 'all' : 'limited')), tiered, autonomousSelection: true, quoteAsset: quote, timeframesTested,
    strategiesTested: strategyList.length, confidencePolicy: { paperTradesForReview: PAPER_CONFIDENCE_TRADES, paperTradesAreNotAnEligibilityGate: true },
    historicalValidation: { minTrades: MIN_BACKTEST_TRADES, minHoldoutBars: MIN_BACKTEST_BARS, walkForwardStarts: WALK_FORWARD_STARTS,
      maxDrawdownPct: MAX_BACKTEST_DRAWDOWN_PCT, feesPct: Math.max(0.1, Number(feePct) || 0), slippagePct: Math.max(0.05, Number(slippagePct) || 0) },
    results: publicResults, eligible: eligible.map((row) => {
      const { rankingCandles, ...result } = row;
      return { ...result, score: Number((row.score ?? 0).toFixed(4)), marketRankScore: Number((scoreBySymbol.get(row.symbol) ?? 0).toFixed(4)) };
    }) };
}
// Mevcut bakiyeden devralınan pozisyonlar için giriş sinyali aranmaz.
// Her coin/strateji/zaman dilimi kombinasyonu, maliyetler sonrası geçmiş performansla
// değerlendirilir; en iyi doğrulanmış yönetim profili seçilir. Böylece RSI+EMA+MACD
// varsayılanına mahkûm kalınmaz ve pozisyon sırf yeni BUY sinyali yok diye sahipsiz kalmaz.
async function scanManagementConfigs({ exchange, symbols = [], strategyIds = null, timeframes = null,
  now = Date.now(), pollSeconds = 60, mode = 'live', exchangeId = 'binance',
  feePct = 0.1, slippagePct = 0.05, backtestRunner = runBacktest, concurrency = 2,
  maxDurationMs = Number(process.env.BOT_MANAGEMENT_SCAN_TIMEOUT_MS) || 90000, nowFn = Date.now } = {}) {
  if (!exchange || typeof exchange.fetchCandles !== 'function') throw new Error('Pozisyon strateji tarayıcısı hazır değil.');
  const strategyList = strategies.list()
    .filter((row) => !Array.isArray(strategyIds) || strategyIds.includes(row.id))
    .map((row) => strategies.get(row.id));
  const activeTimeframes = TIMEFRAMES.filter((tf) => !Array.isArray(timeframes) || timeframes.includes(tf));
  const validStrategies = strategyList.map((strategy) => ({ strategy, ...strategyParams(strategy) }));
  const uniqueSymbols = [...new Set((Array.isArray(symbols) ? symbols : []).map((x) => String(x || '').toUpperCase()).filter((x) => /^[A-Z0-9]{2,20}\/[A-Z0-9]{2,10}$/.test(x)))];
  const startedAt = Number(nowFn());
  const durationBudget = Math.max(1000, Math.min(300000, Number(maxDurationMs) || 90000));
  const deadline = startedAt + durationBudget;
  const expired = () => Number(nowFn()) >= deadline;
  return mapLimit(uniqueSymbols, Math.max(1, Math.min(3, Number(concurrency) || 2)), async (symbol) => {
    const choices = [];
    const relaxedChoices = [];
    const errors = [];
    await mapLimit(activeTimeframes, 3, async (timeframe) => {
      if (expired()) { errors.push('tarama süre bütçesi doldu'); return; }
      const usable = validStrategies.filter(({ strategy, invalid }) => !invalid &&
        !tfPolicy.timeframeProblem({ timeframe, strategyId: strategy.id, pollSeconds, mode, exchangeId, autonomous: true }));
      if (!usable.length) return;
      try {
        const maxRequired = Math.max(...usable.map(({ strategy, params }) => strategy.minCandles(params)));
        const candles = await exchange.fetchCandles(symbol, timeframe, Math.min(1000, Math.max(180, maxRequired + 100)));
        if (expired()) { errors.push('tarama süre bütçesi doldu'); return; }
        validateCandleSeries(candles, timeframe);
        // Tarama boyunca ilk turda alınan now değerini kullanma: uzun taramada
        // kapanmış mum yaşını her sembol/zaman dilimi için gerçek saatle ölç.
        const decisionNow = Number(nowFn());
        const closed = splitCandles(candles, decisionNow, timeframe).closed;
        const last = closed[closed.length - 1];
        if (!last || !(Number(last.c) > 0)) throw new Error('kapanmış mum verisi geçersiz');
        const tfMs = timeframeMs(timeframe);
        const ageMs = decisionNow - Number(last.t);
        const maxAgeMs = Math.max(2 * tfMs, 5 * Math.max(15, Number(pollSeconds) || 60) * 1000, 5 * 60 * 1000);
        if (ageMs > maxAgeMs || ageMs < -Math.max(5 * 60 * 1000, 2 * Math.max(15, Number(pollSeconds) || 60) * 1000)) {
          throw new Error('mum verisi güncel değil');
        }
        for (const { strategy, params } of usable) {
          if (expired()) { errors.push('tarama süre bütçesi doldu'); break; }
          if (closed.length < strategy.minCandles(params) + 2) continue;
          const historical = evaluateHistorical({ candles: closed, strategy, params, backtestRunner, feePct, slippagePct });
          if (!historical.eligible) {
            // 2.3.19 davranışı: sıkı doğrulamada hiçbir profil geçemezse,
            // aynı mum verisinde en az bir işlem üreten gevşek adayları sırala.
            // Bu geçici atama değildir; normal otomatik profil seçiminin ikinci aşamasıdır.
            const relaxed = evaluateRelaxed({ candles: closed, strategy, params, backtestRunner, feePct, slippagePct });
            if (relaxed) relaxedChoices.push({ symbol, strategyId: strategy.id, strategyName: strategy.name, timeframe,
              params: { ...params }, score: relaxed.score, historicalValidation: relaxed.metrics, relaxed: true });
            continue;
          }
          choices.push({ symbol, strategyId: strategy.id, strategyName: strategy.name, timeframe,
            params: { ...params }, score: historical.score, historicalValidation: historical.metrics, relaxed: false });
        }
      } catch (error) { errors.push(`${timeframe}: ${String(error?.message || error).slice(0, 100)}`); }
    });
    // Süre bütçesi dolduysa eksik taramadan bulunan kısmi adayla seçim yapma.
    if (errors.includes('tarama süre bütçesi doldu')) {
      return { symbol, selected: null, reason: 'tarama süre bütçesi doldu; eksik tarama sonucu uygulanmadı' };
    }
    // Sıkı doğrulama her zaman önceliklidir. Yalnızca hiçbir sıkı profil
    // bulunamazsa 2.3.19'daki gevşek sıralama devreye girer.
    if (!choices.length && relaxedChoices.length) {
      relaxedChoices.sort((a, b) => b.score - a.score);
      return { symbol, selected: relaxedChoices[0], alternatives: relaxedChoices.length, relaxed: true };
    }
    if (!choices.length) return { symbol, selected: null, reason: errors.slice(0, 3).join('; ') || 'sıkı ve gevşek geçmiş değerlendirmesinde uygun yönetim profili bulunamadı' };
    choices.sort((a, b) => b.score - a.score);
    return { symbol, selected: choices[0], alternatives: choices.length, relaxed: false };
  });
}

module.exports = { ALLOWED_COUNTS, DEFAULT_CANDIDATE_LIMIT, DEFAULT_SCAN_BATCH_SIZE, TIMEFRAMES, MIN_BACKTEST_TRADES, MIN_BACKTEST_BARS, PAPER_CONFIDENCE_TRADES,
  normalizeRequest, paperConfidence, evaluateHistorical, evaluateRelaxed, scanBuyCandidates, scanManagementConfigs };
