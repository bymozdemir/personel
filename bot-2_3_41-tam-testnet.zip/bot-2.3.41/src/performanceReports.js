'use strict';
const { formatIstanbulTime } = require('./istanbulTime');
function localParts(ms) {
  const p = new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(ms));
  const o = {}; for (const x of p) o[x.type]=x.value;
  return { y:Number(o.year), m:Number(o.month), d:Number(o.day), key:`${o.year}-${o.month}-${o.day}` };
}
function periodBounds(period, now=Date.now()) {
  const p=localParts(now); let start;
  if (period==='daily') start=Date.parse(`${p.key}T00:00:00+03:00`);
  else if (period==='monthly') start=Date.parse(`${p.y}-${String(p.m).padStart(2,'0')}-01T00:00:00+03:00`);
  else {
    const day=Number(new Intl.DateTimeFormat('en-US',{timeZone:'Europe/Istanbul',weekday:'short'}).format(new Date(now))==='Sun'?0:({Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6}[new Intl.DateTimeFormat('en-US',{timeZone:'Europe/Istanbul',weekday:'short'}).format(new Date(now))]));
    const mondayOffset=day===0?6:day-1;
    start=Date.parse(`${p.key}T00:00:00+03:00`)-mondayOffset*86400000;
  }
  return { start, end: now, label: period==='daily'?'Günlük':period==='weekly'?'Haftalık':'Aylık' };
}
function buildPerformanceReport({ trades=[], holdings=[], quoteAsset='USDT', mode='paper', period='weekly', group=null, now=Date.now() }={}) {
  const rows=Array.isArray(trades)?trades:[];
  if (group==='strategy' || group==='coin') {
    const key=group==='strategy'?'strategyId':'symbol'; const map=new Map();
    for (const t of rows) { const k=String(t[key] || (group==='strategy'?'strateji kaydı yok':'?')); const x=map.get(k)||{n:0,w:0,pnl:0,fees:0,feesKnown:0}; x.n++; x.pnl+=Number(t.pnl)||0; if(Number(t.pnl)>0)x.w++; if(Number.isFinite(Number(t.commissionQuoteTotal))){x.fees+=Number(t.commissionQuoteTotal);x.feesKnown++;} map.set(k,x); }
    const sorted=[...map.entries()].sort((a,b)=>b[1].pnl-a[1].pnl).slice(0,15);
    return [`📊 ${group==='strategy'?'STRATEJİ':'COIN'} PERFORMANSI (${mode.toUpperCase()})`, `Kapanan işlem kaydı: ${rows.length}`, ...sorted.map(([k,v])=>`• ${k}: ${v.n} işlem | kazanma %${(v.w/v.n*100).toFixed(1)} | gerçekleşmiş K/Z ${v.pnl.toFixed(2)} ${quoteAsset} | quote komisyonu ${v.fees.toFixed(4)} ${quoteAsset} (${v.feesKnown}/${v.n} işlemde kayıtlı)`), 'Açık pozisyonların gerçekleşmemiş K/Z tutarı bu listeye dahil değildir.'].join('\n');
  }
  const b=periodBounds(period,now); const selected=rows.filter(t=>{const ms=Date.parse(t.closedAt||'');return Number.isFinite(ms)&&ms>=b.start&&ms<=b.end;});
  const pnl=selected.reduce((a,t)=>a+(Number(t.pnl)||0),0), wins=selected.filter(t=>Number(t.pnl)>0).length;
  const feeRows=selected.filter(t=>Number.isFinite(Number(t.commissionQuoteTotal))); const fees=feeRows.reduce((a,t)=>a+Number(t.commissionQuoteTotal),0);
  const unrealized=(Array.isArray(holdings)?holdings:[]).reduce((a,h)=>a+(Number(h.unrealizedPnl)||0),0);
  const lines=[`📈 ${b.label.toUpperCase()} PERFORMANSI (${mode.toUpperCase()})`, `Dönem: ${formatIstanbulTime(b.start)} — ${formatIstanbulTime(now)}`, `Kapanan işlem: ${selected.length}`, `Gerçekleşmiş K/Z: ${pnl>=0?'+':''}${pnl.toFixed(2)} ${quoteAsset}`, `Kazanma oranı: ${selected.length?(wins/selected.length*100).toFixed(1):'0.0'}% (${wins}/${selected.length})`, `Quote karşılığı kayıtlı komisyon: ${fees.toFixed(4)} ${quoteAsset} (${feeRows.length}/${selected.length} işlemde)`, `Açık pozisyon gerçekleşmemiş K/Z: ${unrealized>=0?'+':''}${unrealized.toFixed(2)} ${quoteAsset}`, 'Gerçekleşmiş ve gerçekleşmemiş K/Z ayrı gösterilir; açık pozisyon K/Z kapanmış işlem toplamına eklenmez.'];
  return lines.join('\n');
}
function createPerformanceScheduler({ getData, notifier, state, store, env=process.env, nowFn=()=>Date.now(), intervalMs=30000, logger=console }={}) {
  let timer=null; const inFlight=new Set(); const enabled=!['0','false','off'].includes(String(env.PERFORMANCE_SUMMARIES??'1').toLowerCase()); const timeMatch=/^([01]\d|2[0-3]):([0-5]\d)$/.exec(String(env.PERFORMANCE_SUMMARY_TIME||'23:55')); const minute=timeMatch?Number(timeMatch[1])*60+Number(timeMatch[2]):1435;
  function tick(){ if(!enabled||!notifier)return false; const now=nowFn(); const p=localParts(now); const min=Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Istanbul',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(now).slice(0,2))*60+Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Istanbul',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(now).slice(3,5)); if(min<minute)return false;
    const weekday=new Intl.DateTimeFormat('en-US',{timeZone:'Europe/Istanbul',weekday:'short'}).format(new Date(now)); const lastMonth=p.d===new Date(Date.UTC(p.y,p.m,0)).getUTCDate();
    const due=[]; const weekKey=localParts(periodBounds('weekly',now).start).key; if(weekday==='Mon'&&state.notifyMeta?.lastWeeklyPerformance!==weekKey) due.push('weekly'); if(lastMonth&&state.notifyMeta?.lastMonthlyPerformance!==`${p.y}-${String(p.m).padStart(2,'0')}`) due.push('monthly');
    for(const period of due){const marker=period==='weekly'?weekKey:`${p.y}-${String(p.m).padStart(2,'0')}`; const metaKey=period==='weekly'?'lastWeeklyPerformance':'lastMonthlyPerformance'; if(inFlight.has(period))continue; inFlight.add(period); const d=getData(now); const msg=buildPerformanceReport({trades:d.trades,holdings:d.holdings,quoteAsset:d.quoteAsset,mode:d.mode,period,now}); Promise.resolve(notifier.send(msg,{priority:'quiet',category:'daily',title:`AL-SAT ${period} performans`})).then(res=>{if(res.skipped||Object.values(res).some(v=>v===true)||!notifier.status().telegram&&!notifier.status().termux){state.notifyMeta=state.notifyMeta||{};state.notifyMeta[metaKey]=marker;store.save(state);}}).catch(e=>logger.warn(`[performans] ${e.message}`)).finally(()=>inFlight.delete(period));}
    return due.length>0;
  }
  function start(){if(!enabled||timer)return false;timer=setInterval(()=>{try{tick()}catch(e){logger.warn(`[performans] ${e.message}`)}},intervalMs);timer.unref?.();return true;} function stop(){if(timer)clearInterval(timer);timer=null;} return {start,stop,tick,isEnabled:()=>enabled};
}
module.exports={buildPerformanceReport,createPerformanceScheduler,periodBounds};
