'use strict';
const { formatIstanbulTime } = require('./istanbulTime');
const { splitMessage, stripTags } = require('./notify');
const fmt = require('./notifyFormat');
const { buildPerformanceReport } = require('./performanceReports');

// Read-only Telegram command responder. Only the configured TELEGRAM_CHAT_ID may use it.
// Polling is used for Termux installs; no public webhook/server endpoint is needed.
function createTelegramCommands({ env = process.env, fetchFn = globalThis.fetch, logger = console, getStatus = () => ({}), startBot = async () => { throw new Error('Başlatma işlemi yapılandırılmadı.'); }, stopBot = async () => { throw new Error('Durdurma işlemi yapılandırılmadı.'); }, listStrategies = () => [], timeframes = [], validateTimeframe = () => null, addPair = async () => { throw new Error('Coin ekleme işlemi yapılandırılmadı.'); }, removePair = async () => { throw new Error('Coin silme işlemi yapılandırılmadı.'); }, setPairEnabled = async () => { throw new Error('Coin durdurma/açma işlemi yapılandırılmadı.'); }, setUiMode = async () => { throw new Error('Mod seçimi yapılandırılmadı.'); }, setTradingMode = async () => { throw new Error('Paper/Canlı geçişi bu kurulumda yapılandırılmadı.'); }, setAutonomousSelection = async () => { throw new Error('Otonom seçim kaydetme yapılandırılmadı.'); }, startAutonomous = async () => { throw new Error('Otonom başlatma yapılandırılmadı.'); }, stopAutonomous = null, stopAutonomousImmediate = async () => { throw new Error('Güvenli manuel devralma yapılandırılmadı.'); }, emergencyStopBot = null, muteNotifications = null, unmuteNotifications = null, getNotifyInfo = () => ({}), setNotificationCategory = null, setQuietHours = null, setEntriesPaused = null, setEntryApprovalMode = null, listPendingEntries = null, approvePendingEntry = null, rejectPendingEntry = null, getOpenOrders = null, getDailySummaryText = null, auditCommand = null, pollTimeoutSeconds = 20 } = {}) {
  const token = String(env.TELEGRAM_BOT_TOKEN || '').trim();
  const chatId = String(env.TELEGRAM_CHAT_ID || '').trim();
  const base = 'https://api.telegram.org';
  let stopped = true;
  let offset = 0;
  let loopPromise = null;
  let warned = false;
  // Wizard state lives only in memory. A restart cancels an unconfirmed setup.
  let setup = null;
  const SETUP_TTL_MS = 15 * 60 * 1000;
  // Coin silme onayı da yalnızca bellekte tutulur; yeniden başlatma onaysız silmeyi iptal eder.
  let pendingRemove = null;
  const REMOVE_TTL_MS = 5 * 60 * 1000;
  // CANLI modda /coin_ac riski artirir (gercek parayla yeniden alim): onay gerektirir. Yalnizca bellekte tutulur.
  let pendingEnable = null;
  const ENABLE_TTL_MS = 5 * 60 * 1000;
  // /acil_durdur tek mesajla uygulanmaz (komut menusunde yanlislikla dokunulabilir): ayri onay kelimesi /acil_onayla.
  let pendingEmergency = null;
  // Canlı modda /basla gerçek parayla işlem başlatır: tek mesajla uygulanmaz, ayrı onay kelimesi /basla_onayla.
  let pendingStart = null;
  let pendingMode = null;
  let pendingHandoff = null;
  let pendingAutonomousStart = null;
  const MODE_TTL_MS = 2 * 60 * 1000;
  let autonomousWizard = null;
  const AUTONOMOUS_WIZARD_TTL_MS = 15 * 60 * 1000;
  const START_TTL_MS = 2 * 60 * 1000;
  const EMERGENCY_TTL_MS = 2 * 60 * 1000;

  async function api(method, body, timeoutMs = 30000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetchFn(`${base}/bot${token}/${method}`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body || {}), signal: controller.signal
      });
      let data;
      try { data = await response.json(); } catch { throw new Error(`Telegram ${method}: invalid JSON (HTTP ${response.status})`); }
      if (!response.ok || data.ok !== true) {
        const err = new Error(`Telegram ${method}: ${data.description || `HTTP ${response.status}`}`);
        err.status = Number(response.status) || 0;
        const retryAfter = Number(data?.parameters?.retry_after);
        if (Number.isFinite(retryAfter) && retryAfter > 0) err.retryAfterMs = Math.min(300, retryAfter) * 1000;
        throw err;
      }
      return data.result;
    } finally { clearTimeout(timer); }
  }

  // Dinamik icerik kacirilarak HTML'e cevrilir; yalnizca ilk satir (baslik) kalin yapilir.
  const htmlTitle = (plain) => {
    const lines = String(plain).split('\n');
    lines[0] = `<b>${fmt.esc(lines[0])}</b>`;
    for (let i = 1; i < lines.length; i++) lines[i] = fmt.esc(lines[i]);
    return { html: lines.join('\n') };
  };
  const isLiveStatus = (s) => String((s || {}).mode || 'paper').toLowerCase() === 'live';
  const modeWord = (s) => (isLiveStatus(s) ? 'CANLI' : 'PAPER');

  function formatAmount(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return 'bilinmiyor';
    if (n !== 0 && Math.abs(n) < 0.000001) return n.toLocaleString('en-US', { maximumFractionDigits: 20, useGrouping: false });
    return n.toLocaleString('en-US', { maximumFractionDigits: 8, useGrouping: false });
  }

  function formatBalance() {
    const s = getStatus() || {};
    const quote = String(s.quoteAsset || 'USDT').toUpperCase();
    const cash = Number(s.cash);
    const holdings = Array.isArray(s.holdings) ? s.holdings : [];
    const live = isLiveStatus(s);
    const lines = [`💰 ${modeWord(s)} BAKİYE / VARLIKLAR`, `Kontrol zamanı (İstanbul): ${formatIstanbulTime()}`];
    if (Number.isFinite(cash)) lines.push(`Kullanılabilir nakit: ${formatAmount(cash)} ${quote}`);
    else if (live) lines.push('Borsa bakiyesi henüz okunmadı (ilk hesap mutabakatı bekleniyor).');
    if (!holdings.length) {
      lines.push('', 'Açık varlık/pozisyon bulunmuyor.');
    } else {
      lines.push('', 'Açık pozisyonlar:');
      for (const h of holdings) {
        const symbol = String(h.symbol || 'Bilinmeyen varlık');
        const base = String(h.baseAsset || symbol.split('/')[0] || '').toUpperCase();
        const quantity = formatAmount(h.quantity);
        const value = Number(h.marketValue);
        const cost = Number(h.costQuote);
        const q = String(h.quoteAsset || quote).toUpperCase();
        let line = `• ${base}: ${quantity} ${base}`;
        if (Number.isFinite(value) && value >= 0) line += ` | güncel değer: ${formatAmount(value)} ${q}`;
        else if (Number.isFinite(cost)) line += ` | kayıtlı maliyet: ${formatAmount(cost)} ${q} (güncel fiyat yok)`;
        if (Number.isFinite(cost)) line += ` | maliyet: ${formatAmount(cost)} ${q}`;
        lines.push(line);
      }
    }
    if (Number.isFinite(Number(s.totalEquity))) lines.push('', `Tahmini toplam özkaynak: ${formatAmount(s.totalEquity)} ${quote}`);
    lines.push('', live
      ? `Not: Değerler borsa bakiyesi ve botun canlı pozisyon kayıtlarından gelir${s.lastReconcileAt ? ` (son mutabakat: ${formatIstanbulTime(s.lastReconcileAt)})` : ''}; güncel fiyat yoksa maliyet gösterilir.`
      : 'Not: Değerler Paper kayıtlarından hesaplanır; güncel fiyat yoksa maliyet gösterilir.');
    return lines.join('\n');
  }

  function formatStatus() {
    const s = getStatus() || {};
    const mode = String(s.mode || 'paper').toUpperCase();
    const running = s.running ? 'ÇALIŞIYOR' : 'DURDU';
    const kill = s.killSwitch ? 'AÇIK — işlemler engelli' : 'kapalı';
    const quote = String(s.quoteAsset || 'USDT').toUpperCase();
    const cash = Number(s.cash);
    const cashText = Number.isFinite(cash) ? `${cash.toFixed(2)} ${quote}` : 'bilinmiyor';
    const positions = Number.isFinite(Number(s.positions)) ? String(Number(s.positions)) : 'bilinmiyor';
    const live = isLiveStatus(s);
    const lines = [
      '🤖 AL-SAT BOT DURUMU',
      `Hesap modu: ${mode}`,
      `Seçili arayüz: ${String(s.uiMode || 'manual').toLowerCase() === 'autonomous' ? 'OTONOM' : 'MANUEL'}`,
      `Bot: ${running}`,
      `Yeni alışlar: ${s.settings?.entriesPaused === true ? 'DURAKLATILDI' : 'AÇIK'}`,
      `Otonom alım: ${s.autonomous?.entryApprovalMode === 'telegram' ? 'TELEGRAM ONAYLI' : 'OTOMATİK'}`,
      `Kill switch: ${kill}`,
      `Borsa: ${String(s.exchange || 'bilinmiyor')}`,
      `${live ? 'Canlı nakit (kullanılabilir)' : 'Paper nakit'}: ${cashText}`
    ];
    if (Number.isFinite(Number(s.totalEquity))) lines.push(`Tahmini özkaynak: ${formatAmount(s.totalEquity)} ${quote}`);
    lines.push(`Açık pozisyon: ${positions}`);
    if (live) lines.push(`Canlı işlem kapısı: ${s.safeToTrade === true ? 'AÇIK (güvenli)' : `KİLİTLİ${s.lockReason ? ` — ${String(s.lockReason).slice(0, 200)}` : ''}`}`);
    if (Number.isFinite(Number(s.lastTickAt)) && Number(s.lastTickAt) > 0) lines.push(`Son kontrol turu (İstanbul): ${formatIstanbulTime(Number(s.lastTickAt))}`);
    lines.push(`Kontrol zamanı (İstanbul): ${formatIstanbulTime()}`, '', 'Salt-okunur durum sorgusu. Telegram üzerinden alım/satım komutu çalıştırılmaz.');
    return lines.join('\n');
  }

  function isPaper() { return String((getStatus() || {}).mode || 'paper').toLowerCase() === 'paper'; }

  function formatHealth() {
    const s = getStatus() || {};
    const info = getNotifyInfo() || {};
    const ch = info.channels || {};
    const tg = ch.telegram || {};
    const age = Number(s.lastTickAt) > 0 ? Math.max(0, Date.now() - Number(s.lastTickAt)) : null;
    const lines = [`🩺 SİSTEM SAĞLIĞI — ${modeWord(s)}`, `Bot motoru: ${s.running ? 'çalışıyor' : 'durmuş'}`, `Borsa: ${String(s.exchange || 'bilinmiyor')}`, `Son kontrol turu: ${age === null ? 'henüz yok' : `${Math.floor(age / 60000)} dk önce`}`, `Fiyat kaydı bulunan sembol: ${Number.isFinite(Number(s.priceSymbols)) ? Number(s.priceSymbols) : 'bilinmiyor'}`, `Son hesap mutabakatı: ${s.lastReconcileAt ? formatIstanbulTime(s.lastReconcileAt) : 'bu oturumda doğrulanmadı'}`, `Bakiye güncellemesi: ${s.balanceUpdatedAt ? formatIstanbulTime(s.balanceUpdatedAt) : 'zaman damgası yok'}`, `Telegram yapılandırması: ${info.telegram ? 'var' : 'yok'}`, `Telegram son başarılı gönderim: ${tg.lastOkAt ? formatIstanbulTime(tg.lastOkAt) : 'bu oturumda doğrulanmadı'}`, `Telegram gönderim hatası: ${Number(tg.failures) || 0}`, `Bekleyen kritik bildirim: ${Number(info.pending) || 0}`, `Bildirim kuyruğu: ${Number(info.queued) || 0}`];
    if (tg.lastError) lines.push(`Son Telegram hatası: ${String(tg.lastError).slice(0, 220)}`);
    if (isLiveStatus(s)) lines.push(`Canlı işlem kapısı: ${s.safeToTrade === true ? 'açık' : `KİLİTLİ${s.lockReason ? ` — ${String(s.lockReason).slice(0, 180)}` : ''}`}`);
    lines.push('', 'Not: Bu kontrol erişilebilir durum alanlarını raporlar; tek başına borsa API’sinin şu anda sağlıklı olduğunu kanıtlamaz.');
    return lines.join('\n');
  }

  function formatScan(pageArg = '') {
    const s = getStatus() || {};
    const a = s.autonomous || {};
    const lines = [`🔎 OTONOM TARAMA DURUMU`, `Arayüz seçimi: ${String(s.uiMode || 'manual') === 'autonomous' ? 'OTONOM' : 'MANUEL'}`, `Otonom motor: ${a.active ? 'aktif' : a.stopping ? 'durduruluyor' : 'pasif'}`, `Son tarama: ${a.lastScanAt ? formatIstanbulTime(a.lastScanAt) : 'henüz yapılmadı'}`, `Analiz edilen parite: ${a.scanned !== null && Number.isFinite(Number(a.scanned)) ? a.scanned : 'bilinmiyor'} / ${Number.isFinite(Number(a.universeSize)) ? a.universeSize : 'bilinmiyor'}`, `Tarama yöntemi: ${a.scanMode || 'henüz bilinmiyor'}`, `Yönetilen coin: ${(a.managedSymbols || []).length}`];
    const counts = a.actionCounts || {};
    if (Object.keys(counts).length) lines.push(`Son tur sonuçları: sinyal ${Number(counts.buy)||0}, sinyal yok ${Number(counts.hold)||0}, veri/strateji hatası ${Number(counts.error)||0}`);
    const reasons = a.reasonCounts || {};
    if (Object.keys(reasons).length) lines.push(`Eleme/sonuç dağılımı: ${Object.entries(reasons).map(([k,v]) => `${k}=${Number(v)||0}`).join(', ')}`);
    if (Array.isArray(a.newListings) && a.newListings.length) lines.push('', `Önceki taramadan beri yeni keşfedilen pariteler (${a.newListings.length}): ${a.newListings.join(', ')}`);
    if (a.message) lines.push('', `Durum: ${String(a.message).slice(0, 350)}`);
    const candidates = Array.isArray(a.candidates) ? a.candidates : [];
    if (candidates.length) { lines.push('', `Son adaylar (${candidates.length}; kayıtlı önizleme):`); for (const c of candidates) lines.push(`• ${c.symbol || '?'} — ${c.status || (c.eligible ? 'uygun' : 'elenmiş')}${c.reason ? `: ${String(c.reason).slice(0, 100)}` : ''}`); }
    else lines.push('', 'Henüz tarama adayı kaydı yok.');
    const universe = Array.isArray(a.universeSymbols) ? a.universeSymbols : [];
    if (universe.length) {
      const pageSize = 50; const totalPages = Math.max(1, Math.ceil(universe.length / pageSize));
      const requestedPage = Math.max(1, Math.min(totalPages, Number.parseInt(pageArg, 10) || 1));
      const slice = universe.slice((requestedPage - 1) * pageSize, requestedPage * pageSize);
      lines.push('', `Güncel uygun USDT evreni (${universe.length} parite) — sayfa ${requestedPage}/${totalPages}:`, slice.join(', '), `Tüm liste için /tarama 1 … /tarama ${totalPages} komutlarını kullan (sayfada ${pageSize} coin).`);
    }
    lines.push('', 'Aday listesi tüm piyasa değil, son taramanın kayıtlı önizlemesidir. Evren listesi borsa ticker verisinden yenilenir; bu, uygun USDT pariteleridir, borsadaki her varlık/fiat çifti değildir. Yeni keşfedilen pariteler yalnızca tarama evrenine eklenir; otomatik olarak kullanıcıya ait pozisyon veya yönetilen coin yapılmaz.');
    return lines.join('\n');
  }

  function formatRisk() {
    const s = getStatus() || {};
    const st = s.settings || {};
    const q = String(s.quoteAsset || 'USDT').toUpperCase();
    const lines = [`🛡 RİSK DURUMU — ${modeWord(s)}`, `Kill switch: ${s.killSwitch ? 'AÇIK — yeni işlemler engelli' : 'kapalı'}`, `Günlük zarar limiti: ${Number.isFinite(Number(st.dailyLossLimitPct)) ? `${st.dailyLossLimitPct}%` : 'bilinmiyor'}`, `Toplam zarar kilidi: ${Number.isFinite(Number(st.killSwitchLossPct)) ? `${st.killSwitchLossPct}%` : 'bilinmiyor'}`, `Azami açık pozisyon: ${Number.isFinite(Number(st.maxConcurrentPositions)) ? st.maxConcurrentPositions : 'bilinmiyor'}`, `İşlem başına üst sınır: ${Number(st.maxTradeQuote) > 0 ? `${st.maxTradeQuote} ${q}` : 'tanımlı değil'}`, `Açık pozisyon: ${Number.isFinite(Number(s.positions)) ? s.positions : 'bilinmiyor'}`];
    if (isLiveStatus(s)) lines.push(`Canlı güvenlik kapısı: ${s.safeToTrade === true ? 'AÇIK' : `KİLİTLİ${s.lockReason ? ` — ${String(s.lockReason).slice(0, 200)}` : ''}`}`);
    lines.push('', 'Bu komut salt-okunurdur; risk ayarlarını değiştirmez ve emir göndermez.');
    return lines.join('\n');
  }


  function formatNotifications() {
    const info = getNotifyInfo() || {};
    const tg = info.channels?.telegram || {};
    const lines = [
      `🔔 BİLDİRİM DURUMU — ${modeWord(getStatus() || {})}`,
      `Telegram yapılandırması: ${info.telegram ? 'var' : 'yok'}`,
      `Sessiz mod: ${info.muted ? `açık${info.mutedUntil ? `, ${formatIstanbulTime(info.mutedUntil)} tarihine kadar` : ''}` : 'kapalı'}`,
      `Gönderim kuyruğu: ${Number(info.queued) || 0}`,
      `Bekleyen kritik/kalıcı mesaj: ${Number(info.pending) || 0}`,
      `Toplam Telegram gönderim hatası (bu oturum): ${Number(tg.failures) || 0}`,
      `Son başarılı gönderim: ${tg.lastOkAt ? formatIstanbulTime(tg.lastOkAt) : 'bu oturumda doğrulanmadı'}`
    ];
    const qh = info.quietHours || {};
    lines.push(`Günlük sessiz saatler: ${qh.enabled ? `${qh.start}-${qh.end} (İstanbul)` : 'kapalı'}`);
    const categories = info.categories || {};
    lines.push('', 'Kategori tercihleri (kritik güvenlik bildirimleri her zaman önceliklidir):');
    for (const [key, label] of [['trading','İşlem'],['risk','Risk/koruma'],['system','Sistem/veri'],['scan','Tarama'],['daily','Günlük özet'],['security','Güvenlik'],['general','Genel']]) lines.push(`• ${label}: ${categories[key] === false ? 'kapalı' : 'açık'}`);
    if (tg.lastError) lines.push(`Son hata: ${String(tg.lastError).slice(0, 300)}`);
    if (info.dailySummary) lines.push(`Günlük özet: ${info.dailySummary.enabled ? 'açık' : 'kapalı'}${info.dailySummary.time ? ` (${info.dailySummary.time})` : ''}`);
    lines.push('', 'Salt-okunur rapor. Kuyrukta bekleyen mesajların teslim edildiği anlamına gelmez; gönderim durumu değişebilir.');
    return lines.join('\n');
  }

  async function formatOrders() {
    const s = getStatus() || {};
    const lines = [`📋 AÇIK EMİRLER — ${modeWord(s)}`, `Kontrol zamanı (İstanbul): ${formatIstanbulTime()}`];
    if (!isLiveStatus(s)) {
      lines.push('', 'Paper modda borsaya gönderilmiş açık emir yok. Paper pozisyonlarını görmek için /pozisyonlar komutunu kullan.');
      return lines.join('\n');
    }
    if (typeof getOpenOrders !== 'function') {
      lines.push('', '⛔ Açık emir sorgusu yapılandırılmamış; emir durumu doğrulanamadı.');
      return lines.join('\n');
    }
    try {
      const result = await getOpenOrders();
      if (!Array.isArray(result)) throw new Error('Borsadan geçerli emir listesi alınamadı.');
      lines.push(`Borsa açık emir sayısı: ${result.length}`);
      if (!result.length) lines.push('', 'Borsada açık emir bulunmuyor.');
      const holdings = Array.isArray(s.holdings) ? s.holdings : [];
      if (holdings.length) {
        const stopLike = (o) => /STOP|TAKE_PROFIT|TRAILING/i.test(String(o.type || o.info?.type || o.info?.origType || ''));
        const stopCheck = holdings.map((h) => {
          const sameSymbolStops = result.filter((o) => String(o.symbol || '').toUpperCase() === String(h.symbol || '').toUpperCase() && String(o.side || '').toLowerCase() === 'sell' && stopLike(o));
          const qty = Number(h.quantity);
          const matching = sameSymbolStops.filter((o) => {
            const orderQty = Number(o.amount);
            const qtyOk = Number.isFinite(qty) && qty > 0 && Number.isFinite(orderQty) && orderQty + Math.max(1e-10, qty * 1e-6) >= qty;
            const stopPrice = Number(o.stopPrice ?? o.triggerPrice ?? o.info?.stopPrice ?? o.info?.triggerPrice);
            const localStop = Number(h.stopPrice);
            const priceOk = !(Number.isFinite(localStop) && localStop > 0) || (Number.isFinite(stopPrice) && stopPrice > 0 && Math.abs(stopPrice-localStop) / localStop <= 0.01);
            return qtyOk && priceOk;
          });
          return { holding: h, ok: matching.length > 0, stopCount: sameSymbolStops.length };
        });
        const unverified = stopCheck.filter((x) => !x.ok).map((x) => x.holding);
        lines.push(`Yerel açık pozisyon: ${holdings.length}; miktar/fiyat ön kontrolünden geçmeyen: ${unverified.length}`);
        for (const h of unverified.slice(0, 20)) lines.push(`⚠️ ${h.symbol}: borsada pozisyon miktarı ve yerel stop fiyatıyla eşleşen satış stopu doğrulanamadı.`);
        if (unverified.length) lines.push('Kritik: Bu muhafazakâr ön kontroldür; borsanın tetikleme davranışını veya stopun kesin çalışacağını garanti etmez. Emir tipini ve tetik fiyatını panelden doğrulayın.');
      }
      for (const o of result.slice(0, 40)) {
        const symbol = String(o.symbol || 'sembol bilinmiyor');
        const side = String(o.side || '?').toUpperCase();
        const type = String(o.type || '?').toUpperCase();
        const status = String(o.status || 'open').toUpperCase();
        const amount = Number(o.amount); const filled = Number(o.filled); const remaining = Number(o.remaining);
        const price = Number(o.price);
        lines.push(`• ${symbol} | ${side} ${type} | durum: ${status} | miktar: ${Number.isFinite(amount) ? formatAmount(amount) : '?'} | dolan: ${Number.isFinite(filled) ? formatAmount(filled) : '?'} | kalan: ${Number.isFinite(remaining) ? formatAmount(remaining) : '?'}${Number.isFinite(price) && price > 0 ? ` | fiyat: ${formatAmount(price)}` : ' | fiyat: piyasa/ bilinmiyor'} | ID: ${String(o.id || '?').slice(0, 60)}`);
      }
      if (result.length > 40) lines.push(`… ve ${result.length - 40} emir daha. Ayrıntı için paneli kullan.`);
      lines.push('', 'Kaynak: borsa API açık emir listesi. Bu rapor emir oluşturmaz, iptal etmez ve koruyucu stopların çalıştığını tek başına garanti etmez.');
    } catch (err) {
      lines.push('', `⛔ Borsadaki açık emirler okunamadı: ${String(err?.message || err).slice(0, 350)}`, 'Emir durumu bilinmiyor; boş liste olarak yorumlanmamalıdır.');
    }
    return lines.join('\n');
  }

  function setupExpired() {
    if (setup && Date.now() - setup.createdAt > SETUP_TTL_MS) setup = null;
    return !setup;
  }

  function askCurrentSetupQuestion() {
    if (!setup) return '';
    if (setup.step === 'timeframe') return `\nMum aralığını seç: ${(timeframes || []).join(', ')}. Örnek: 15m`;
    if (setup.step === 'budget') {
      const max = Number((getStatus() || {}).settings?.defaultBudgetPct);
      return `\nBu coin için portföy bütçe payını yüzde olarak yaz (1-${Number.isFinite(max) && max > 0 ? max : 100}). Bu değer varsayılan bütçe payını aşamaz; global risk limitleri değişmez.`;
    }
    if (setup.step === 'trailingStop') return `\nTrailing stop bu coin için açık mı olsun? evet/hayır yaz. Stratejinin kodda tanımlı diğer indikatör ve parametre değerleri değişmeyecek. Varsayılan: ${setup.params.trailingStop ? 'açık' : 'kapalı'}.`;
    if (setup.step === 'confirm') {
      const lines = [
        '🧾 COIN AYAR ÖZETİ — henüz eklenmedi',
        `Parite: ${setup.symbol}`,
        `Strateji: ${setup.strategy.name} (${setup.strategy.id})`,
        `Mum aralığı: ${setup.timeframe}`,
        `Bütçe payı: %${setup.budgetPct}`,
        'İndikatör ayarları: kodda tanımlı hazır varsayılanlar (değiştirilmedi).',
        `Trailing stop: ${setup.params.trailingStop ? 'AÇIK' : 'KAPALI'}`,
        '',
        'Eklemek için /onayla yaz. İptal etmek için /iptal yaz.',
        'Global günlük zarar limiti, kill switch, azami pozisyon ve işlem üst sınırı değiştirilmeyecek.'
      ];
      if (!isPaper()) lines.splice(1, 0, '⚠ CANLI MOD: bu coin için bot GERÇEK parayla otomatik işlem yapabilir.');
      if (/^(1m|3m|5m)$/.test(String(setup.timeframe))) lines.splice(lines.length - 3, 0, `⚡ Kısa mum (${setup.timeframe}) agresif stratejisi: komisyon+kayma gidiş-dönüş ~%0.3, işlem sayısı ve emir trafiği yüksek. Küçük bütçeyle ve gözetimli kullan.`);
      return lines.join('\n');
    }
    return '';
  }

  function beginCoinSetup(symbol) {
    const status = getStatus() || {};
    const norm = String(symbol || '').toUpperCase().trim();
    if (!/^[A-Z0-9]{2,20}\/[A-Z0-9]{2,10}$/.test(norm)) return 'Parite biçimi hatalı. Örnek: /coin_ekle PEPE/USDT';
    if (status.pairs && Object.prototype.hasOwnProperty.call(status.pairs, norm)) return `${norm} zaten listede.`;
    const quoteAssets = Array.isArray(status.quoteAssets) ? status.quoteAssets : [];
    if (quoteAssets.length && !quoteAssets.includes(norm.split('/')[1])) return `Bu borsada desteklenen kasa birimleri: ${quoteAssets.join(', ')}.`;
    const choices = (listStrategies() || []);
    if (!choices.length) return 'Strateji listesi alınamadı; coin ekleme başlatılmadı.';
    setup = { symbol: norm, choices, step: 'strategy', createdAt: Date.now() };
    return `🛠 ${norm} coin ekleme sihirbazı\nKodda bulunan hazır stratejilerden birini seç. İndikatör hesap ayarları kodun varsayılanlarında kalır; senden yalnızca strateji, mum süresi, bütçe ve trailing stop seçimi istenir.\n\n${choices.map((x, i) => `${i + 1}. ${x.name} (${x.id})\n   ${x.description || ''}`).join('\n')}\n\nSeçmek için listedeki numarayı yaz. İptal: /iptal`;
  }

  function handleSetupReply(input) {
    if (setupExpired()) return null;
    const value = String(input || '').trim();
    if (value.toLowerCase() === '/iptal') { setup = null; return 'Coin ekleme iptal edildi. Herhangi bir ayar kaydedilmedi.'; }
    if (value.toLowerCase() === '/coin_ekle') return 'Kullanım: /coin_ekle PEPE/USDT';
    if (setup.step === 'strategy') {
      const idx = Number(value);
      if (!Number.isInteger(idx) || idx < 1 || idx > setup.choices.length) return `Geçersiz seçim. 1-${setup.choices.length} arasında bir numara yaz.`;
      setup.strategy = setup.choices[idx - 1];
      setup.params = { ...(setup.strategy.defaultParams || {}) };
      setup.paramIndex = 0;
      setup.step = 'timeframe';
      return `Seçilen strateji: ${setup.strategy.name}.\nİndikatör ayarları kodda tanımlı varsayılanlarla kullanılacak.\n${askCurrentSetupQuestion()}`;
    }
    if (setup.step === 'timeframe') {
      if (!(timeframes || []).includes(value)) return `Geçersiz mum aralığı. Seçenekler: ${(timeframes || []).join(', ')}`;
      const tfError = validateTimeframe({ timeframe: value, strategyId: setup.strategy.id });
      if (tfError) return tfError;
      setup.timeframe = value;
      setup.step = 'budget';
      return askCurrentSetupQuestion();
    }
    if (setup.step === 'budget') {
      const n = Number(value.replace(',', '.'));
      const max = Number((getStatus() || {}).settings?.defaultBudgetPct);
      const ceiling = Number.isFinite(max) && max > 0 ? Math.min(100, max) : 100;
      if (!Number.isFinite(n) || n < 1 || n > ceiling) return `Bütçe payı 1 ile ${ceiling} arasında olmalı. Global ayarlar değiştirilmez; bu coin için daha düşük pay seçebilirsin.`;
      setup.budgetPct = n;
      setup.step = 'trailingStop';
      return askCurrentSetupQuestion();
    }
    if (setup.step === 'trailingStop') {
      const v = value.toLocaleLowerCase('tr-TR');
      if (['evet', 'e', 'true', '1', 'açık', 'acik'].includes(v)) setup.params.trailingStop = true;
      else if (['hayır', 'hayir', 'h', 'false', '0', 'kapalı', 'kapali'].includes(v)) setup.params.trailingStop = false;
      else return 'Trailing stop için evet veya hayır yaz.';
      if (!Object.prototype.hasOwnProperty.call(setup.strategy.defaultParams || {}, 'trailingStop')) {
        if (setup.params.trailingStop) return 'Bu strateji trailing stop ayarını desteklemiyor. Hayır yazarak kapalı devam edebilirsin.';
        setup.params.trailingStop = false;
      }
      setup.step = 'confirm';
      return askCurrentSetupQuestion();
    }
    return 'Bekleyen bir ayar adımı yok. /coin_ekle PEPE/USDT ile başla.';
  }

  function normSymbolArg(arg) {
    const sym = String(arg || '').trim().toUpperCase();
    return /^[A-Z0-9]{2,20}\/[A-Z0-9]{2,10}$/.test(sym) ? sym : null;
  }

  function enableExpired() {
    if (pendingEnable && Date.now() - pendingEnable.createdAt > ENABLE_TTL_MS) pendingEnable = null;
    return !pendingEnable;
  }

  function removeExpired() {
    if (pendingRemove && Date.now() - pendingRemove.createdAt > REMOVE_TTL_MS) pendingRemove = null;
    return !pendingRemove;
  }

  function hasPair(status, sym) {
    return Boolean(status.pairs && typeof status.pairs === 'object' && Object.prototype.hasOwnProperty.call(status.pairs, sym));
  }

  function formatPairs() {
    const s = getStatus() || {};
    const pairs = s.pairs && typeof s.pairs === 'object' ? s.pairs : {};
    const keys = Object.keys(pairs).sort();
    if (!keys.length) return 'Listede takip edilen coin yok. /coin_ekle PEPE/USDT ile ekleyebilirsin.';
    const held = new Set((Array.isArray(s.holdings) ? s.holdings : []).map((h) => String(h.symbol)));
    const lines = [`📋 TAKİP EDİLEN COİNLER (${keys.length})`];
    for (const k of keys) {
      const p = pairs[k] || {};
      const state = p.enabled === false ? '⏸ durduruldu' : '▶ aktif';
      const pos = held.has(k) ? ' | açık pozisyon var' : '';
      lines.push(`• ${k} — ${p.strategyId || '?'}, ${p.timeframe || '?'}, bütçe %${p.budgetPct ?? '?'} — ${state}${pos}`);
    }
    lines.push('', 'Komutlar: /coin_sil, /coin_durdur, /coin_ac (örnek: /coin_durdur PEPE/USDT)');
    return lines.join('\n');
  }

  function beginCoinRemove(arg) {
    const sym = normSymbolArg(arg);
    if (!sym) return 'Parite biçimi hatalı. Örnek: /coin_sil PEPE/USDT';
    const status = getStatus() || {};
    if (!hasPair(status, sym)) return `${sym} listede değil. Mevcut liste için /coinler yaz.`;
    const holding = (Array.isArray(status.holdings) ? status.holdings : []).find((h) => String(h.symbol) === sym);
    if (!isPaper() && holding) {
      // Panel DELETE kuralıyla aynı: gerçek pozisyonlu coin silinirse pozisyon ve borsadaki stop emri sahipsiz kalır.
      return `⛔ ${sym} için açık GERÇEK pozisyon var (${formatAmount(holding.quantity)} ${String(holding.baseAsset || sym.split('/')[0]).toUpperCase()}): coin silinemez. Önce pozisyon kapanmalı (strateji satışı/stop) ya da borsadan elle kapat. Yeni alımı kesmek için /coin_durdur ${sym} kullanabilirsin.`;
    }
    setup = null; pendingEnable = null;
    pendingRemove = { symbol: sym, createdAt: Date.now() };
    const lines = [`🗑 ${sym} listeden SİLİNECEK — henüz silinmedi.`];
    if (holding) {
      const base = String(holding.baseAsset || sym.split('/')[0]).toUpperCase();
      lines.push(`Açık paper pozisyon var: ${formatAmount(holding.quantity)} ${base}. Silinirse son bilinen fiyattan kapatılır, tutar nakde döner ve kâr/zarar gerçekleşir.`);
    } else {
      lines.push('Açık pozisyon yok.');
    }
    lines.push('', 'Onaylamak için /onayla, vazgeçmek için /iptal yaz (5 dakika içinde).');
    return lines.join('\n');
  }

  function formatTrades(arg) {
    const s = getStatus() || {};
    const quote = String(s.quoteAsset || 'USDT').toUpperCase();
    const trades = Array.isArray(s.trades) ? s.trades : [];
    let n = Number.parseInt(String(arg || '').trim(), 10);
    if (!Number.isInteger(n) || n < 1) n = 5;
    n = Math.min(n, 15);
    if (!trades.length) return 'Henüz kapanmış işlem yok.';
    const lines = [`🧾 SON ${Math.min(n, trades.length)} KAPANAN İŞLEM`];
    for (const t of trades.slice(0, n)) {
      const pnl = Number(t.pnl);
      const pct = Number(t.pnlPct);
      const sign = pnl >= 0 ? '+' : '';
      const icon = pnl >= 0 ? '🟢' : '🔴';
      const when = t.closedAt ? formatIstanbulTime(t.closedAt) : '';
      const reason = String(t.reason || '').slice(0, 70);
      lines.push(`${icon} ${t.symbol}: ${Number.isFinite(pct) ? `${sign}${pct.toFixed(2)}%` : '?'} (${Number.isFinite(pnl) ? `${sign}${pnl.toFixed(2)}` : '?'} ${quote})${when ? ` — ${when}` : ''}${reason ? `\n   ${reason}` : ''}`);
    }
    return lines.join('\n');
  }

  function formatReport(arg = '') {
    const s = getStatus() || {};
    const key = String(arg || '').trim().toLocaleLowerCase('tr-TR');
    const period = ['haftalik','weekly'].includes(key) ? 'weekly' : ['aylik','monthly'].includes(key) ? 'monthly' : ['gunluk','günlük','daily'].includes(key) ? 'daily' : null;
    const group = ['strateji','strategy'].includes(key) ? 'strategy' : ['coin','parite'].includes(key) ? 'coin' : null;
    if (period || group) return buildPerformanceReport({ trades: s.trades, holdings: s.holdings, quoteAsset: s.quoteAsset, mode: s.mode, period: period || 'weekly', group });
    const quote = String(s.quoteAsset || 'USDT').toUpperCase();
    const st = s.stats && typeof s.stats === 'object' ? s.stats : {};
    const count = Number(st.trades) || 0;
    const wins = Number(st.wins) || 0;
    const grossWin = Number(st.grossWin) || 0;
    const grossLoss = Number(st.grossLoss) || 0;
    const start = Number(s.startingBalance);
    const equity = Number(s.totalEquity);
    const lines = [`📊 ${modeWord(s)} RAPOR`, `Kontrol zamanı (İstanbul): ${formatIstanbulTime()}`];
    if (Number.isFinite(start) && start > 0) lines.push(`Başlangıç bakiyesi: ${formatAmount(start)} ${quote}`);
    if (Number.isFinite(equity)) {
      lines.push(`Tahmini özkaynak: ${formatAmount(equity)} ${quote}`);
      if (Number.isFinite(start) && start > 0) {
        const ret = (equity / start - 1) * 100;
        lines.push(`Toplam getiri: ${ret >= 0 ? '+' : ''}${ret.toFixed(2)}%`);
      }
    }
    lines.push(`Açık pozisyon: ${Number.isFinite(Number(s.positions)) ? Number(s.positions) : 'bilinmiyor'}`);
    const unrealizedRows = (Array.isArray(s.holdings) ? s.holdings : []).filter((h) => Number.isFinite(Number(h.unrealizedPnl)));
    if (unrealizedRows.length) lines.push(`Açık pozisyon K/Z (fiyatı bilinen ${unrealizedRows.length}/${(s.holdings || []).length}): ${formatAmount(unrealizedRows.reduce((sum, h) => sum + Number(h.unrealizedPnl), 0))} ${quote}`);
    else if ((s.holdings || []).length) lines.push('Açık pozisyon K/Z: güncel fiyat verisi yetersiz; hesaplanamadı.');
    if (Number.isFinite(Number(st.realizedPnl))) lines.push(`Kayıtlı gerçekleşmiş K/Z: ${formatAmount(st.realizedPnl)} ${quote}`);
    lines.push(`Kapanan işlem: ${count}`);
    if (count > 0) {
      lines.push(`Kazanma oranı: %${(wins / count * 100).toFixed(1)} (${wins}/${count})`);
      if (grossLoss > 0) lines.push(`Kâr faktörü: ${(grossWin / grossLoss).toFixed(2)}`);
      if (Number.isFinite(Number(st.pctSum))) lines.push(`Ortalama işlem: ${(Number(st.pctSum) / count).toFixed(2)}%`);
    }
    lines.push('', isLiveStatus(s)
      ? 'Not: Canlı hesabın gerçekleşen işlemleridir; küçük işlem sayısı güvenilir bir sonuç vermez.'
      : 'Not: Paper simülasyonudur; küçük işlem sayısı güvenilir bir sonuç vermez.');
    return lines.join('\n');
  }

  // ---- Yeni salt-okunur komutlar: /pozisyonlar, /loglar, /ayarlar, /sessiz, /ozet ----

  function formatPositions() {
    const s = getStatus() || {};
    const quote = String(s.quoteAsset || 'USDT').toUpperCase();
    const holdings = Array.isArray(s.holdings) ? s.holdings : [];
    const nowMs = Date.now();
    const title = `📌 ${fmt.b(`AÇIK POZİSYONLAR (${holdings.length}) — ${modeWord(s)}`)}`;
    if (!holdings.length) return { html: `${title}\nAçık pozisyon yok.\n${fmt.stamp(nowMs)}` };
    const lines = [title];
    let totalPnl = 0; let pnlCount = 0;
    for (const h of holdings) {
      const base = String(h.baseAsset || String(h.symbol).split('/')[0] || '').toUpperCase();
      const q = String(h.quoteAsset || quote).toUpperCase();
      lines.push(`• ${fmt.b(h.symbol)}: ${fmt.code(fmt.qty(h.quantity))} ${fmt.esc(base)}`);
      const flow = [];
      if (Number.isFinite(Number(h.entryPrice))) flow.push(`Giriş ${fmt.code(fmt.price(h.entryPrice))}`);
      if (Number.isFinite(Number(h.lastPrice))) flow.push(`Şimdi ${fmt.code(fmt.price(h.lastPrice))}`);
      const up = Number(h.unrealizedPct); const upn = Number(h.unrealizedPnl);
      let line2 = flow.join(' → ');
      if (Number.isFinite(up) && Number.isFinite(upn)) {
        line2 += `${line2 ? ' ' : ''}(${fmt.esc(fmt.pct(up))}, ${fmt.esc(fmt.signed(upn))} ${fmt.esc(q)}) ${upn >= 0 ? '🟢' : '🔴'}`;
        if (q === quote) { totalPnl += upn; pnlCount += 1; }
      } else if (!line2) line2 = 'güncel fiyat yok';
      lines.push(`  ${line2}`);
      const extra = [];
      if (Number.isFinite(Number(h.stopPrice)) && Number(h.stopPrice) > 0) {
        const dist = Number.isFinite(Number(h.lastPrice)) && Number(h.lastPrice) > 0 ? ` (${fmt.pct((Number(h.stopPrice) / Number(h.lastPrice) - 1) * 100, 1)})` : '';
        extra.push(`Stop ${fmt.code(fmt.price(h.stopPrice))}${fmt.esc(dist)}`);
      }
      const dur = fmt.duration(h.openedAt, nowMs);
      if (dur) extra.push(`Süre ${fmt.esc(dur)}`);
      if (isLiveStatus(s)) extra.push(h.protected ? '🛡 borsada stop emri var' : '⚠ stop emri kaydı yok');
      if (extra.length) lines.push(`  ${extra.join(' | ')}`);
    }
    if (pnlCount) lines.push('', `Toplam açık K/Z: ${fmt.b(`${fmt.signed(totalPnl)} ${quote}`)} (gerçekleşmemiş)`);
    lines.push(fmt.stamp(nowMs));
    return { html: lines.join('\n') };
  }

  function formatLogs(arg) {
    const s = getStatus() || {};
    const tokens = String(arg || '').toLowerCase().split(/\s+/).filter(Boolean);
    const onlyProblems = tokens.some((t) => ['hata', 'uyari', 'uyarı', 'error', 'sorun'].includes(t));
    let n = tokens.map((t) => Number.parseInt(t, 10)).find((x) => Number.isInteger(x) && x > 0);
    n = Math.min(n || 10, 25);
    const all = Array.isArray(s.recentLog) ? s.recentLog : [];
    const logs = (onlyProblems ? all.filter((e) => e && (e.level === 'error' || e.level === 'warn')) : all).slice(0, n);
    const title = `🧾 ${fmt.b(`SON ${logs.length} LOG${onlyProblems ? ' (yalnızca hata/uyarı)' : ''}`)}`;
    if (!logs.length) return { html: `${title}\n${onlyProblems ? 'Kayıtlı hata/uyarı yok. 👍' : 'Kayıtlı log yok.'}` };
    const icon = { error: '🔴', warn: '🟡' };
    const lines = [title];
    for (const e of logs) {
      const ms = Date.parse(e.t);
      const when = Number.isFinite(ms) ? formatIstanbulTime(ms) : '';
      const short = when ? `${when.slice(0, 5)} ${when.slice(9)}` : '';
      lines.push(`${icon[e.level] || '⚪'} ${fmt.esc(short)} ${fmt.esc(String(e.msg || '').replace(/\s+/g, ' ').slice(0, 180))}`);
    }
    lines.push('', 'İpucu: /loglar hata — yalnızca hata/uyarılar; /loglar 20 — son 20 kayıt (en fazla 25).');
    return { html: lines.join('\n') };
  }

  function formatSettings() {
    const s = getStatus() || {};
    const st = s.settings && typeof s.settings === 'object' ? s.settings : {};
    const info = getNotifyInfo() || {};
    const quote = String(s.quoteAsset || 'USDT').toUpperCase();
    const val = (v, suffix = '') => (Number.isFinite(Number(v)) ? `${Number(v)}${suffix}` : 'bilinmiyor');
    const pairs = s.pairs && typeof s.pairs === 'object' ? Object.values(s.pairs) : [];
    const active = pairs.filter((p) => p && p.enabled !== false).length;
    const ok = (v) => (v ? '✅' : '❌');
    const lines = [`⚙️ AYARLAR (salt-okunur) — ${modeWord(s)}`,
      `Borsa: ${String(s.exchange || 'bilinmiyor')} | Kasa birimi: ${quote}`,
      `Kontrol aralığı: ${val(st.pollSeconds, ' sn')}${st.timeframe ? ` | Varsayılan mum: ${st.timeframe}` : ''}`,
      `Günlük zarar limiti: ${val(st.dailyLossLimitPct, '%')} | Kill switch (toplam zarar): ${val(st.killSwitchLossPct, '%')}`,
      `Azami eşzamanlı pozisyon: ${val(st.maxConcurrentPositions)} | Nakit rezervi: ${val(st.reserveCashPct, '%')}`,
      `İşlem üst sınırı: ${Number(st.maxTradeQuote) > 0 ? `${st.maxTradeQuote} ${quote}` : 'sınırsız'}${Number.isFinite(Number(st.maxOpenOrders)) ? ` | Açık emir üst sınırı: ${st.maxOpenOrders}` : ''}`,
      `Takip edilen coin: ${pairs.length} (aktif ${active})`,
      `Yeni alışlar: ${st.entriesPaused === true ? 'duraklatıldı' : 'açık'}`];
    if (!isLiveStatus(s) && Number.isFinite(Number(st.paperFeePct))) lines.push(`Paper komisyon: %${Number(st.paperFeePct)} | kayma: %${Number.isFinite(Number(st.paperSlippagePct)) ? Number(st.paperSlippagePct) : '?'}`);
    lines.push('', `Bildirim kanalları: Telegram ${ok(info.telegram !== false)} | Termux ${ok(info.termux)} | Nabız (healthcheck) ${ok(info.healthcheck)}`);
    const qh = info.quietHours || {};
    lines.push(qh.enabled ? `Günlük sessiz saatler: ${qh.start}-${qh.end} (İstanbul); kritik uyarılar yine sesli` : (info.muted && info.mutedUntil ? `Sessiz mod: AÇIK (bitiş ${formatIstanbulTime(info.mutedUntil)}); kritik uyarılar yine sesli` : 'Sessiz mod: kapalı'));
    if (info.dailySummary) lines.push(`Günlük özet: ${info.dailySummary.enabled ? `açık, her gün ${info.dailySummary.time} (İstanbul)` : 'kapalı'}`);
    if (Number(info.pending) > 0) lines.push(`⏱ Gönderilemeyen ${Number(info.pending)} kritik bildirim bekliyor; bağlantı gelince otomatik iletilir.`);
    if (info.channels && info.channels.telegram && info.channels.telegram.failures > 0) lines.push(`⚠ Telegram bildirim gönderimi son zamanlarda ${info.channels.telegram.failures} kez başarısız oldu.`);
    lines.push('', 'Risk ve borsa ayarları panelden; bildirim kategorileri ve sessiz saatler Telegram komutlarından yönetilir.');
    return lines.join('\n');
  }

  function handleMute(arg) {
    if (typeof muteNotifications !== 'function') return 'Sessiz mod bu kurulumda kullanılamıyor.';
    const raw = String(arg || '').trim().toLowerCase();
    const info = getNotifyInfo() || {};
    if (['kapat', 'bitir', 'iptal', 'sesli', 'normal'].includes(raw)) {
      if (typeof unmuteNotifications === 'function') unmuteNotifications();
      if (typeof setQuietHours === 'function') setQuietHours('22:00', '08:00', false);
      return '🔔 Sessiz mod kapatıldı; süreli sessiz mod ve günlük sessiz saatler devre dışı. Kritik uyarılar her zaman açıktı.';
    }
    if (raw === 'durum') {
      const q = info.quietHours || {};
      if (info.mutedUntil) return `🔕 Sessiz mod AÇIK, bitiş: ${formatIstanbulTime(info.mutedUntil)}. Kritik uyarılar yine sesli gelir. Günlük saat planı: ${q.enabled ? `${q.start}-${q.end}` : 'kapalı'}.`;
      return q.enabled ? `🔕 Günlük sessiz saatler AÇIK (${q.start}-${q.end}, İstanbul). Kritik uyarılar yine sesli gelir.` : '🔔 Sessiz mod kapalı. Açmak için: /sessiz 2 (saat) veya /sessiz 22:00-08:00.';
    }
    const schedule = /^(\d{2}:\d{2})-(\d{2}:\d{2})$/.exec(raw);
    if (schedule) {
      if (typeof setQuietHours !== 'function') return 'Sessiz saat ayarı bu kurulumda desteklenmiyor.';
      try { const q = setQuietHours(schedule[1], schedule[2], true); return `🔕 Her gün ${q.start}-${q.end} (İstanbul) arası rutin bildirimler sessiz iletilecek. Kritik güvenlik uyarıları sessiz saatleri ve kategori filtrelerini aşar.`; }
      catch (e) { return `⛔ ${e.message}`; }
    }
    const hours = raw === '' ? 2 : Number(raw.replace(',', '.'));
    if (!Number.isFinite(hours) || hours < 0.25 || hours > 24) return 'Kullanım: /sessiz [saat] veya /sessiz 22:00-08:00 (her gün İstanbul saati). Kapatmak için: /sessiz kapat';
    const until = muteNotifications({ hours });
    return `🔕 Sessiz mod ${hours} saat açık (bitiş: ${formatIstanbulTime(until)}).\nAlım/satım ve bilgi mesajları ses/titreşim olmadan gelir. KRİTİK uyarılar (stop-loss, kill switch, kilitlenme, çökme) yine sesli gelir. Yeniden başlatma sessiz modu sıfırlar.`;
  }

  async function setCoinEnabled(arg, enabled) {
    const paper = isPaper();
    const sym = normSymbolArg(arg);
    const cmd = enabled ? '/coin_ac' : '/coin_durdur';
    if (!sym) return `Parite biçimi hatalı. Örnek: ${cmd} PEPE/USDT`;
    const status = getStatus() || {};
    if (!hasPair(status, sym)) return `${sym} listede değil. Mevcut liste için /coinler yaz.`;
    // CANLI modda yeniden açma riski ARTIRIR (gerçek parayla yeni alım): açık onay gerekir. Durdurma ise riski azaltır
    // (yalnızca yeni alımı keser, açık pozisyonun stopunu/çıkışını etkilemez) ve onaysız çalışır.
    if (!paper && enabled) {
      setup = null; pendingRemove = null;
      pendingEnable = { symbol: sym, createdAt: Date.now() };
      return `⚠ CANLI MOD: ${sym} yeniden açılacak — henüz açılmadı.\nAçılırsa bot bu coin için GERÇEK parayla yeni alım yapabilir.\nOnaylamak için /onayla, vazgeçmek için /iptal yaz (${Math.round(ENABLE_TTL_MS / 60000)} dk içinde).`;
    }
    try {
      const result = await setPairEnabled({ symbol: sym, enabled });
      const live = paper ? '' : ' Pozisyon KAPATILMAZ; bot onun stop-loss/çıkış kurallarını işletmeye devam eder.';
      return `${enabled ? '▶' : '⏸'} ${sym} ${enabled ? 'yeniden aktif: yeni alım sinyalleri işlenir.' : `durduruldu: yeni alım yapılmaz. Açık pozisyon varsa çıkış sinyali/stop ile yönetilmeye devam eder.${live}`}${result && result.message ? `\n${result.message}` : ''}`;
    } catch (err) {
      return `⛔ İşlem yapılamadı: ${String(err && err.message || err).slice(0, 700)}`;
    }
  }

  // Yanit: duz metin (string) ya da { html }. 4096 sinirini asan yanitlar satir sinirindan bolunur;
  // Telegram HTML etiketini reddederse etiketsiz duz metne dusulur.
  async function sendReply(reply) {
    const isHtml = Boolean(reply) && typeof reply === 'object' && typeof reply.html === 'string';
    const text = isHtml ? reply.html : String(reply);
    const parts = splitMessage(text);
    for (let i = 0; i < parts.length; i++) {
      const prefix = parts.length > 1 ? `(${i + 1}/${parts.length}) ` : '';
      const body = { chat_id: chatId, text: prefix + parts[i], disable_web_page_preview: true };
      if (isHtml) body.parse_mode = 'HTML';
      try {
        await api('sendMessage', body, 10000);
      } catch (err) {
        if (!isHtml || !/parse|entit|tag/i.test(String(err && err.message))) throw err;
        await api('sendMessage', { chat_id: chatId, text: prefix + stripTags(parts[i]), disable_web_page_preview: true }, 10000);
      }
    }
  }

  function modeLabel(s) {
    const live = isLiveStatus(s);
    const auto = String(s.uiMode || 'manual').toLowerCase() === 'autonomous';
    return `${auto ? 'Otonom' : 'Manuel'} ${live ? 'Canlı' : 'Kağıt'}`;
  }
  function formatMode() {
    const s = getStatus() || {};
    const auto = s.autonomous || {};
    const state = auto.stopping ? 'Güvenli kapanışta (pozisyon yönetimi sürüyor)' : s.running ? 'Çalışıyor' : 'Durdu';
    return `⚙️ MOD DURUMU\nSeçili mod: ${modeLabel(s)}\nMotor: ${state}\nOtonom tarayıcı: ${auto.active ? 'aktif' : auto.stopping ? 'kapanışta' : 'pasif'}\nCanlı işlem kapısı: ${isLiveStatus(s) ? (s.safeToTrade === true ? 'açık' : `KİLİTLİ${s.lockReason ? ` — ${s.lockReason}` : ''}`) : 'uygulanmaz (Paper)'}\n\nMod seçimi motoru başlatmaz. Başlatma için manuelde /basla, otonomda /oto_basla kullanılır.`;
  }
  function startAutonomousWizard() {
    const s = getStatus() || {};
    if (s.autonomous?.active) return 'Otonom sistem zaten çalışıyor.';
    const strategies = (listStrategies() || []);
    if (!strategies.length) return 'Strateji kayıtları okunamadı; sihirbaz açılmadı.';
    const current = s.autonomousSelection || {};
    const selected = new Set((current.strategies || []).filter(x => x.selected).map(x => x.id));
    const frames = new Set((current.timeframes || []).filter(x => x.selected && !x.locked).map(x => x.id));
    autonomousWizard = { step: 'strategies', createdAt: Date.now(), strategies, selected: selected.size ? [...selected] : strategies.filter(x => x.id !== 'aggressive_breakout').map(x => x.id), frames: frames.size ? [...frames] : ['15m','30m','1h','4h'], count: Number(s.settings?.maxConcurrentPositions) || 1 };
    return `🧭 OTONOM HAZIRLIK — strateji seçimi\nHer strateji ayrı satırda; numaraları virgülle yaz. Örn: 1,2,4\n\n${strategies.map((x,i)=>`${i+1}. ${x.name} (${x.id})${autonomousWizard.selected.includes(x.id) ? ' ✓' : ''}`).join('\n')}\n\nHepsini seçmek için: hepsi\nİptal: /iptal`;
  }
  function handleAutonomousWizardReply(value) {
    if (!autonomousWizard) return null;
    if (Date.now() - autonomousWizard.createdAt > AUTONOMOUS_WIZARD_TTL_MS) { autonomousWizard = null; return 'Otonom hazırlık süresi doldu; hiçbir ayar kaydedilmedi.'; }
    const v = String(value || '').trim();
    if (autonomousWizard.step === 'strategies') {
      let ids;
      if (/^(hepsi|tümü|tum|all)$/i.test(v)) ids = autonomousWizard.strategies.map(x=>x.id);
      else {
        const nums = v.split(/[ ,;]+/).filter(Boolean).map(Number);
        if (!nums.length || nums.some(n=>!Number.isInteger(n)||n<1||n>autonomousWizard.strategies.length)) return `Geçersiz seçim. 1-${autonomousWizard.strategies.length} arasında numaraları virgülle yaz veya hepsi.`;
        ids = [...new Set(nums)].map(n=>autonomousWizard.strategies[n-1].id);
      }
      if (!ids.length) return 'En az bir strateji seçmelisin.';
      autonomousWizard.selected = ids; autonomousWizard.step = 'timeframes';
      return `Seçilen strateji sayısı: ${ids.length}.\n\nOtonom mum aralıklarını seç (15m ve üzeri). Virgülle yaz: 15m,30m,1h,4h\n1m/3m/5m otonomda kabul edilmez.`;
    }
    if (autonomousWizard.step === 'timeframes') {
      const frames = [...new Set(v.split(/[ ,;]+/).filter(Boolean))];
      const allowed = ['15m','30m','1h','4h'];
      const bad = frames.filter(x=>!allowed.includes(x));
      if (bad.length) return `${bad.join(', ')} otonomda kullanılamaz. Yalnızca: ${allowed.join(', ')}`;
      if (!frames.length) return 'En az bir mum aralığı seçmelisin.';
      autonomousWizard.frames = allowed.filter(x=>frames.includes(x)); autonomousWizard.step = 'count';
      return `Seçilen mumlar: ${autonomousWizard.frames.join(', ')}.\n\nOtonom azami coin/pozisyon kapasitesi: ${[1,2,4,8,16,32].join(', ')}. Bir sayı yaz.`;
    }
    if (autonomousWizard.step === 'count') {
      const n = Number(v);
      if (![1,2,4,8,16,32].includes(n)) return 'Kapasite 1, 2, 4, 8, 16 veya 32 olmalı.';
      autonomousWizard.count = n; autonomousWizard.step = 'confirm';
      return `🧾 OTONOM AYAR ÖZETİ — henüz kaydedilmedi\nStrateji (${autonomousWizard.selected.length}):\n${autonomousWizard.strategies.filter(x=>autonomousWizard.selected.includes(x.id)).map(x=>`• ${x.name} (${x.id})`).join('\n')}\nMumlar: ${autonomousWizard.frames.join(', ')}\nKapasite: ${n}\n\nKaydetmek ve Otonom modu seçmek için /mod_onay yaz. Motor BAŞLAMAZ. İptal: /iptal`;
    }
    return 'Ayar özeti hazır. Kaydetmek için /mod_onay, vazgeçmek için /iptal.';
  }

  async function processUpdate(update) {
    const message = update && (update.message || update.edited_message);
    if (!message || !message.chat || message.chat.id === undefined || !message.text) return false;
    // Fail closed: never respond to an unconfigured or different chat.
    if (!chatId || String(message.chat.id) !== chatId) return false;
    // Grup/kanal sohbetlerinde uyelerden biri komut verebilir; yalnizca ozel (birebir) sohbet kabul edilir.
    // Telegram sohbet turunu bildirirse 'private' olmayan her sey reddedilir (eski/sahte guncellemelerde tur yoksa chat.id eslesmesi yeterlidir).
    if (message.chat.type !== undefined && message.chat.type !== 'private') return false;
    // Ozel sohbette gonderen her zaman sohbet sahibidir; farkliysa (iletilmis/sahte guncelleme) reddet.
    if (message.from && message.from.id !== undefined && String(message.from.id) !== chatId) return false;
    const text = String(message.text).trim();
    const command = text.split(/\s+/, 1)[0].split('@')[0].toLowerCase();
    let reply;
    const autonomousBusy = () => { const a = (getStatus() || {}).autonomous || {}; return Boolean(a.active || a.stopping); };
    const AUTONOMOUS_COIN_BLOCK = '⛔ Otonom mod çalışırken coin ekleme/silme/açma kapalı: otonom bitince manuel ayarlar geri yüklenir ve bu değişiklik kaybolur. Önce /bitir ile otonomu güvenli durdur. (Riski azaltan /coin_durdur kullanılabilir.)';
    if ((command === '/coin_ekle' || command === '/coin-ekle' || command === '/coin_sil' || command === '/coin-sil' || command === '/coin_ac' || command === '/coin-ac' || command === '/coin_aç') && autonomousBusy()) {
      setup = null; pendingRemove = null; pendingEnable = null;
      reply = AUTONOMOUS_COIN_BLOCK;
    } else if (command === '/onayla' && autonomousBusy() && (setup || pendingRemove || pendingEnable)) {
      setup = null; pendingRemove = null; pendingEnable = null;
      reply = '⛔ Otonom mod başladığı için bekleyen coin işlemi iptal edildi. Hiçbir ayar değiştirilmedi.';
    } else if (command === '/coin_ekle' || command === '/coin-ekle') {
      pendingRemove = null; pendingEnable = null;
      reply = beginCoinSetup(text.split(/\s+/).slice(1).join(' '));
    } else if (command === '/coin_sil' || command === '/coin-sil') {
      reply = beginCoinRemove(text.split(/\s+/).slice(1).join(' '));
    } else if (command === '/onayla' && pendingEnable) {
      if (enableExpired()) reply = 'Onayın süresi doldu. Coin açılmadı. /coin_ac SEMBOL ile yeniden başla.';
      else {
        const pending = pendingEnable;
        pendingEnable = null;
        try {
          const result = await setPairEnabled({ symbol: pending.symbol, enabled: true });
          reply = `▶ ${pending.symbol} yeniden aktif: yeni alım sinyalleri işlenir.${result && result.message ? `\n${result.message}` : ''}`;
        } catch (err) { reply = `⛔ İşlem yapılamadı: ${String(err && err.message || err).slice(0, 700)}\nHiçbir değişiklik yapılmadı.`; }
      }
    } else if (command === '/onayla' && pendingRemove) {
      if (removeExpired()) reply = 'Silme onayının süresi doldu. Hiçbir coin silinmedi. /coin_sil PEPE/USDT ile yeniden başla.';
      else {
        const pending = pendingRemove;
        try {
          const result = await removePair({ symbol: pending.symbol });
          pendingRemove = null;
          reply = `✅ ${pending.symbol} ${isPaper() ? 'Paper' : 'Canlı'} listesinden silindi.${result && result.message ? `\n${result.message}` : ''}`;
        } catch (err) {
          pendingRemove = null;
          reply = `⛔ Coin silinemedi: ${String(err && err.message || err).slice(0, 700)}\nHiçbir değişiklik yapılmadı; düzeltip yeniden deneyebilirsin.`;
        }
      }
    } else if (command === '/onayla') {
      if (!setup || setupExpired() || setup.step !== 'confirm') reply = 'Onaylanacak tamamlanmış ayar bulunmuyor. /coin_ekle PEPE/USDT ile başla.';
      else {
        const pending = setup;
        try {
          const result = await addPair({ symbol: pending.symbol, strategyId: pending.strategy.id, timeframe: pending.timeframe, budgetPct: pending.budgetPct, params: pending.params });
          setup = null;
          reply = `✅ ${pending.symbol} ${isPaper() ? 'Paper' : 'CANLI'} listesine eklendi.
Strateji: ${pending.strategy.name}
Mum aralığı: ${pending.timeframe}
Bütçe payı: %${pending.budgetPct}
Trailing stop: ${pending.params.trailingStop ? 'AÇIK' : 'KAPALI'}
İndikatörler: kodda tanımlı varsayılan değerler
${result && result.message ? result.message : 'Global güvenlik limitleri korunuyor.'}`;
        } catch (err) { reply = `⛔ Coin eklenemedi: ${String(err && err.message || err).slice(0, 700)}
Ayarlar kaydedilmedi; düzeltip yeniden deneyebilirsin veya /iptal yaz.`; }
      }
    } else if (command === '/iptal') { setup = null; pendingRemove = null; pendingEnable = null; pendingEmergency = null; pendingStart = null; pendingMode = null; pendingHandoff = null; pendingAutonomousStart = null; autonomousWizard = null; reply = 'Bekleyen işlem ve sihirbaz iptal edildi. Hiçbir ayar değiştirilmedi.';
    } else if (setup && !command.startsWith('/')) {
      reply = handleSetupReply(text);
      if (reply === null) reply = 'Ayar sihirbazının süresi doldu. Hiçbir ayar kaydedilmedi. /coin_ekle PEPE/USDT ile yeniden başla.';
    } else if (command === '/start' || command === '/help' || command === '/yardim' || command === '/yardım') {
      reply = 'AL-SAT botu hazır. Komutlar:\n/mod — dört modun ve motor durumunun özeti\n/mod_paper, /mod_live, /mod_man, /mod_oto — güvenli geçiş sihirbazları; /mod_onay ile onay\n/oto_basla [1|2|4|8|16|32] — otonom sistemi başlat (Canlıda /oto_basla_onay gerekir)\n/oto_basla_onay — canlı otonom başlatmayı onayla\n/oto_bitir — yeni alımları kesip açık pozisyonlar kapanana kadar yönetimi sürdür\n/oto_durdur — stop koruması doğrulanırsa manuel moda güvenli devret\n/basla — manuel motoru başlat (Paper hemen; CANLIDA onay için /basla_onayla)\n/bitir — güvenli durdurma; açık pozisyonları yönetmeye devam eder\n/alim_durdur — yeni alışları durdur; açık pozisyon yönetimi sürer\n/alim_baslat — yeni alışları yeniden aç\n/alim_mod otomatik|onaylı — otonom yeni alım davranışı\n/alim_bekleyen — bekleyen alım onayları\n/alim_onay ID / /alim_reddet ID — sinyali onayla/reddet\n/acil_durdur — acil durdurma isteği (onay için /acil_onayla); borsadaki emirleri değiştirmez\n/durum — mevcut durumu göster\n/bakiye — nakit ve açık varlıkları göster\n/rapor [haftalik|aylik|gunluk|strateji|coin] — dönem ve kırılım performansı\n/islemler [adet] — son kapanan işlemler (varsayılan 5, en fazla 15)\n/coinler — takip edilen coinleri listele\n/coin_ekle PEPE/USDT — coin ekleme sihirbazı (hazır indikatör ayarları; canlıda gerçek parayla işlem yapar)\n/coin_sil PEPE/USDT — coini listeden sil (onay ister; Paper modda açık pozisyon son fiyattan kapatılır, canlıda açık pozisyon varsa silinmez)\n/coin_durdur PEPE/USDT — yeni alımı durdur (silmeden)\n/coin_ac PEPE/USDT — durdurulan coini yeniden aç\n/onayla — bekleyen ekleme/silme işlemini onayla\n/iptal — bekleyen işlemi iptal et\n/pozisyonlar — açık pozisyonlar (giriş, güncel fiyat, K/Z, stop, süre)\n/loglar [adet|hata] — son log kayıtları\n/ayarlar — risk limitleri ve bildirim ayarları (salt-okunur)\n/ozet — günlük özeti şimdi gönder\n/saglik — motor ve Telegram bildirim sağlığı\n/tarama [sayfa] — son otonom tarama ve 50 paritelik evren sayfaları\n/risk — risk limitleri ve işlem kilitleri\n/emirler — borsadaki açık emirleri salt-okunur göster\n/bildirimler — kuyruk ve kategori durumu; /bildirimler risk kapat ile tercih yönetimi\n/sessiz [saat|HH:MM-HH:MM|kapat|durum] — günlük sessiz saat veya süreli sessiz mod\n/oto_durdur_onay — güvenli manuel devri onayla\n/yardim — bu yardım\n\nCoin ekleme/silme/açma açık onay gerektirir. Canlı motor ve canlı otonom başlatma ayrıca açık Telegram onayı ister; Telegram üzerinden manuel piyasa alım/satım emri verilemez.';
    } else if (command === '/alim_mod') {
      const modeArg = String(text.split(/\s+/).slice(1).join(' ') || '').trim().toLowerCase();
      if (!['otomatik','auto','onay','onayli','onaylı','telegram'].includes(modeArg)) reply = 'Kullanım: /alim_mod otomatik veya /alim_mod onaylı. Yalnızca OTONOM moddaki yeni alımları etkiler.';
      else if (typeof setEntryApprovalMode !== 'function') reply = '⛔ Otonom alım onay modu bu kurulumda yapılandırılmadı.';
      else { try { const mode = ['otomatik','auto'].includes(modeArg) ? 'auto' : 'telegram'; const result = await setEntryApprovalMode(mode); reply = `✅ Otonom yeni alım modu: ${mode === 'auto' ? 'OTOMATİK' : 'TELEGRAM ONAYLI'}.\n${result?.message || ''}`; } catch (e) { reply = `⛔ Mod değiştirilemedi: ${String(e?.message || e).slice(0,220)}`; } }
    } else if (command === '/alim_bekleyen') {
      const rows = typeof listPendingEntries === 'function' ? await listPendingEntries() : [];
      reply = rows.length ? `🟡 BEKLEYEN OTONOM ALIM ONAYLARI\n${rows.map(x => `• ${x.id} — ${x.symbol} ${x.timeframe || ''} — fiyat ${x.price} — son: ${formatIstanbulTime(x.expiresAt)}`).join('\n')}\nOnay: /alim_onay ID | Ret: /alim_reddet ID` : 'Bekleyen otonom alım onayı yok.';
    } else if (command === '/alim_onay') {
      const id = text.split(/\s+/).slice(1).join(' ').trim();
      if (!id || typeof approvePendingEntry !== 'function') reply = 'Kullanım: /alim_onay BEKLEYEN_ID';
      else { try { const result = await approvePendingEntry(id); reply = result?.ok ? `✅ ${result.item.symbol} onaylandı. Emir hemen gönderilmez; motor sinyali, mumun güncelliğini, bakiye ve tüm risk/güvenlik kontrollerini yeniden doğrular. Sinyal değişmiş veya süresi dolmuşsa alım yapılmaz.` : `⛔ ${result?.message || 'Onay verilemedi.'}`; } catch (e) { reply = `⛔ Onay verilemedi: ${String(e?.message || e).slice(0,220)}`; } }
    } else if (command === '/alim_reddet') {
      const id = text.split(/\s+/).slice(1).join(' ').trim();
      if (!id || typeof rejectPendingEntry !== 'function') reply = 'Kullanım: /alim_reddet BEKLEYEN_ID';
      else { const result = await rejectPendingEntry(id); reply = result?.ok ? `🚫 ${result.item.symbol} alım sinyali reddedildi. Emir gönderilmedi.` : `⛔ ${result?.message || 'Ret işlenemedi.'}`; }
    } else if (command === '/alim_durdur' || command === '/alim_baslat') {
      if (typeof setEntriesPaused !== 'function') reply = 'Yeni alış kontrolü bu kurulumda yapılandırılmadı; hiçbir ayar değiştirilmedi.';
      else {
        const paused = command === '/alim_durdur';
        try {
          const result = await setEntriesPaused(paused);
          reply = paused
            ? `⏸️ Yeni alışlar durduruldu. Açık pozisyonların satış, stop ve risk yönetimi devam ediyor.${result?.message ? `\n${result.message}` : ''}`
            : `▶️ Yeni alışlar yeniden açıldı. Risk kilidi ve tüm normal alım kontrolleri geçerlidir.${result?.message ? `\n${result.message}` : ''}`;
        } catch (err) { reply = `⛔ Yeni alış ayarı değiştirilemedi: ${String(err?.message || err).slice(0, 500)}`; }
      }
    } else if (command === '/mod_paper' || command === '/mod_live' || command === '/mod_man' || command === '/mod_oto') {
      const target = command === '/mod_paper' ? { kind: 'trading', value: 'paper', label: 'Paper' }
        : command === '/mod_live' ? { kind: 'trading', value: 'live', label: 'Canlı' }
        : command === '/mod_man' ? { kind: 'ui', value: 'manual', label: 'Manuel' }
        : { kind: 'ui', value: 'autonomous', label: 'Otonom' };
      if (target.value === 'autonomous') {
        reply = startAutonomousWizard();
      } else {
        const s = getStatus() || {};
        const current = target.kind === 'trading' ? (isLiveStatus(s) ? 'live' : 'paper') : (String(s.uiMode || 'manual') === 'autonomous' ? 'autonomous' : 'manual');
        if (current === target.value) reply = `${target.label} modu zaten seçili.\n\n${formatMode()}`;
        else if (s.running || s.autonomous?.active || s.autonomous?.stopping) reply = '⛔ Mod geçişi için motorun tamamen durmuş olması gerekir. Önce güvenli durdurmayı tamamla; açık pozisyonların yönetimi kesilmez.';
        else { pendingMode = { ...target, createdAt: Date.now() }; reply = `⚠ ${target.label.toUpperCase()} MOD GEÇİŞİ HENÜZ UYGULANMADI.\nOnaydan önce mevcut durum: ${modeLabel(s)}.\n\nUygulamak için 2 dakika içinde /mod_onay yaz. İptal: /iptal. Mod değişimi motoru başlatmaz.`; }
      }
    } else if (command === '/mod_onay') {
      if (autonomousWizard && autonomousWizard.step === 'confirm') {
        if (Date.now() - autonomousWizard.createdAt > AUTONOMOUS_WIZARD_TTL_MS) { autonomousWizard = null; reply = 'Otonom ayar onayının süresi doldu. Hiçbir ayar kaydedilmedi.'; }
        else {
          try {
            const selection = await setAutonomousSelection({ strategyIds: autonomousWizard.selected, timeframes: autonomousWizard.frames });
            await setUiMode('autonomous');
            const count = autonomousWizard.count;
            autonomousWizard = null;
            reply = `✅ Otonom mod ve seçimler kaydedildi.\n${selection?.message || ''}\nKapasite: ${count} (başlatırken /oto_basla ${count} kullan).\nMotor BAŞLATILMADI. Başlatmak için ayrıca /oto_basla ${count} yaz.`;
          } catch (err) { reply = `⛔ Otonom ayarlar kaydedilemedi: ${String(err?.message || err).slice(0,500)}. Mevcut mod korunmuştur.`; }
        }
      } else if (!pendingMode || Date.now() - pendingMode.createdAt > MODE_TTL_MS) {
        pendingMode = null; reply = 'Onaylanacak mod geçişi yok veya süresi doldu. Hiçbir mod değiştirilmedi.';
      } else {
        const p = pendingMode; pendingMode = null;
        try {
          if (p.kind === 'trading') await setTradingMode(p.value);
          else await setUiMode(p.value);
          reply = `✅ ${p.label} modu seçildi. Motor otomatik başlatılmadı.\n\n${formatMode()}`;
        } catch (err) { reply = `⛔ Mod geçişi reddedildi; mevcut mod korundu: ${String(err?.message || err).slice(0,650)}`; }
      }
    } else if (autonomousWizard && !command.startsWith('/')) {
      reply = handleAutonomousWizardReply(text);
    } else if (command === '/mod' || command === '/mode') {
      const arg = text.split(/\s+/).slice(1).join(' ').trim().toLowerCase();
      const mode = ['manuel', 'manual', 'man'].includes(arg) ? 'manual' : ['otonom', 'otonomik', 'autonomous', 'auto', 'oto'].includes(arg) ? 'autonomous' : null;
      if (!mode) {
        const current = String((getStatus() || {}).uiMode || 'manual').toLowerCase();
        reply = `${formatMode()}\n\nGeçiş komutları: /mod_paper, /mod_live, /mod_man, /mod_oto. Onay: /mod_onay.`;
      } else {
        try {
          const result = await setUiMode(mode);
          const label = mode === 'autonomous' ? 'OTONOM' : 'MANUEL';
          reply = `✅ ${label} arayüz modu seçildi.\n${result && result.message ? result.message + '\n' : ''}Bu seçim Paper/Canlı hesap modunu değiştirmez ve botu başlatmaz.`;
        } catch (err) { reply = `⛔ Mod değiştirilemedi: ${String(err && err.message || err).slice(0, 500)}`; }
      }
    } else if (command === '/status' || command === '/durum') {
      reply = htmlTitle(formatStatus());
    } else if (command === '/saglik' || command === '/health') {
      reply = htmlTitle(formatHealth());
    } else if (command === '/tarama' || command === '/scan') {
      reply = htmlTitle(formatScan(text.split(/\s+/).slice(1).join(' ').trim()));
    } else if (command === '/risk') {
      reply = htmlTitle(formatRisk());
    } else if (command === '/bildirimler' || command === '/notifications') {
      const args = text.split(/\s+/).slice(1).filter(Boolean).map((x) => x.toLowerCase());
      const categoryMap = { islem: 'trading', işlem: 'trading', trading: 'trading', risk: 'risk', koruma: 'risk', sistem: 'system', veri: 'system', system: 'system', tarama: 'scan', scan: 'scan', ozet: 'daily', özet: 'daily', daily: 'daily', guvenlik: 'security', güvenlik: 'security', security: 'security', genel: 'general', general: 'general' };
      if (args.length) {
        const category = categoryMap[args[0]]; const action = args[1];
        if (!category || !['ac','aç','kapat','on','off'].includes(action || '')) reply = 'Kullanım: /bildirimler [islem|risk|sistem|tarama|ozet|guvenlik|genel] [ac|kapat]\nÖrnek: /bildirimler tarama kapat';
        else if (typeof setNotificationCategory !== 'function') reply = '⛔ Bu kurulumda kategori ayarı desteklenmiyor.';
        else { try { setNotificationCategory(category, ['ac','aç','on'].includes(action)); reply = `✅ ${category} kategorisi ${['ac','aç','on'].includes(action) ? 'açıldı' : 'kapatıldı'}. Kritik güvenlik bildirimleri bu tercihten etkilenmez.\n\n${formatNotifications()}`; } catch (err) { reply = `⛔ Ayar kaydedilemedi: ${String(err?.message || err).slice(0, 200)}`; } }
      } else reply = htmlTitle(formatNotifications());
    } else if (command === '/emirler' || command === '/orders') {
      reply = htmlTitle(await formatOrders());
    } else if (command === '/bakiye' || command === '/balance') {
      reply = htmlTitle(formatBalance());
    } else if (command === '/oto_basla') {
      const s = getStatus() || {};
      if (String(s.uiMode || 'manual') !== 'autonomous') reply = 'Otonom mod seçili değil. Önce /mod_oto ile hazırlık ve seçim sihirbazını tamamla.';
      else if (s.autonomous?.active) reply = 'Otonom sistem zaten aktif.';
      else {
        const arg = Number(text.split(/\s+/)[1] || s.settings?.maxConcurrentPositions || 1);
        if (![1,2,4,8,16,32].includes(arg)) reply = 'Kapasite 1, 2, 4, 8, 16 veya 32 olmalı. Örnek: /oto_basla 4';
        else if (isLiveStatus(s)) {
          pendingAutonomousStart = { count: arg, createdAt: Date.now() };
          const sel = s.autonomousSelection || {};
          const picked = (sel.strategies || []).filter(x=>x.selected).map(x=>x.name);
          const frames = (sel.timeframes || []).filter(x=>x.selected && !x.locked).map(x=>x.id);
          reply = `⚠ CANLI OTONOM BAŞLATMA — HENÜZ BAŞLATILMADI\nKapasite: ${arg}\nStratejiler (${picked.length}): ${picked.join(', ') || 'kayıtlı varsayılanlar'}\nMumlar: ${frames.join(', ') || 'kayıtlı varsayılanlar'}\n\nCanlı hesapta gerçek emir oluşturulabilir. Başlatmak için 2 dakika içinde /oto_basla_onay yaz. İptal: /iptal. Canlı işlem kapısı ve hesap denetimi motor tarafından tekrar doğrulanır.`;
        } else {
          try { const result = await startAutonomous({ count: arg }); reply = `▶ Otonom başlatma isteği uygulandı. İlk tarama arka planda sürüyor.\n${result?.message || ''}\nMotor durumu için /mod veya /durum.`; }
          catch (err) { reply = `⛔ Otonom sistem başlatılamadı: ${String(err?.message || err).slice(0,650)}`; }
        }
      }
    } else if (command === '/oto_basla_onay') {
      const s = getStatus() || {};
      if (!pendingAutonomousStart || Date.now() - pendingAutonomousStart.createdAt > START_TTL_MS) { pendingAutonomousStart = null; reply = 'Canlı otonom başlatma onayı yok veya süresi doldu. Hiçbir şey başlatılmadı.'; }
      else if (!isLiveStatus(s) || String(s.uiMode || 'manual') !== 'autonomous') { pendingAutonomousStart = null; reply = 'Mod değişti; canlı otonom başlatma onayı geçersiz. Hiçbir şey başlatılmadı.'; }
      else {
        const count = pendingAutonomousStart.count; pendingAutonomousStart = null;
        try { const result = await startAutonomous({ count }); reply = `▶ Canlı otonom sistem başlatıldı; ilk tarama arka planda sürüyor.\n${result?.message || ''}`; }
        catch (err) { reply = `⛔ Canlı otonom başlatılamadı: ${String(err?.message || err).slice(0,650)}`; }
      }
    } else if (command === '/oto_durdur') {
      const s = getStatus() || {};
      if (!s.autonomous?.active && !s.autonomous?.stopping) reply = 'Otonom sistem aktif değil; devredilecek otonom çalışma bulunmuyor.';
      else {
        pendingHandoff = { createdAt: Date.now() };
        reply = '⚠ MANUEL DEVRALMA HENÜZ UYGULANMADI. Otonom yeni alımları durdurulacak, motor kapatılacak ve mod Manuel yapılacak. Canlı pozisyonların her biri için borsada miktarı karşılayan satış stopu doğrulanamazsa işlem reddedilir. Paper açık pozisyon varsa güvenli harici stop bulunmadığından devir reddedilir.\nOnay için 2 dakika içinde /oto_durdur_onay yaz. İptal: /iptal.';
      }
    } else if (command === '/oto_durdur_onay') {
      if (!pendingHandoff || Date.now() - pendingHandoff.createdAt > MODE_TTL_MS) { pendingHandoff = null; reply = 'Manuel devralma onayı yok veya süresi doldu. Hiçbir şey değiştirilmedi.'; }
      else {
        pendingHandoff = null;
        try { const result = await stopAutonomousImmediate(); reply = `✅ Otonomdan Manuel moda devredildi. Motor durumu: durdu. Yeni otonom alım yapılmayacak. Mevcut borsa stop emirlerine dokunulmadı.\n${result?.message || ''}`; }
        catch (err) { reply = `⛔ Manuel devralma reddedildi; otonom çalışma mevcut hâlinde bırakıldı: ${String(err?.message || err).slice(0,650)}`; }
      }
    } else if (command === '/oto_bitir') {
      const s = getStatus() || {};
      if (!s.autonomous?.active && !s.autonomous?.stopping) reply = 'Otonom sistem aktif değil.';
      else {
        try { const result = await stopAutonomous(); reply = `⏳ Otonom güvenli kapanışı başlatıldı. Yeni alımlar durur; açık pozisyonlar çıkış/stop kurallarıyla yönetilmeye devam eder.\n${result?.message || ''}`; }
        catch (err) { reply = `⛔ Otonom güvenli kapanış başlatılamadı: ${String(err?.message || err).slice(0,500)}`; }
      }
    } else if (command === '/basla') {
      const status = getStatus() || {};
      const live = isLiveStatus(status);
      if (status.running) {
        reply = 'Bot zaten çalışıyor.\n\n' + formatStatus();
      } else if (String(status.uiMode || '').toLowerCase() === 'autonomous' && !(status.autonomous && status.autonomous.active)) {
        reply = 'Otonom arayüz modu seçili: manuel motor Telegram üzerinden başlatılmaz (panelde de aynı kural geçerli). Manuel çalışmak için önce /mod manuel yaz; otonomu /oto_basla ile başlat. Hiçbir şey başlatılmadı.';
      } else if (live) {
        pendingStart = { createdAt: Date.now() };
        const pairs = status.pairs && typeof status.pairs === 'object' ? status.pairs : {};
        const active = Object.keys(pairs).filter((k) => (pairs[k] || {}).enabled !== false).sort();
        const lines = ['⚠ CANLI MOD: bot GERÇEK parayla işlem yapabilir — henüz BAŞLATILMADI.', `Aktif coin: ${active.length}`];
        for (const k of active.slice(0, 10)) lines.push(`• ${k} — ${(pairs[k] || {}).strategyId || '?'}, ${(pairs[k] || {}).timeframe || '?'}${/^(1m|3m|5m)$/.test(String((pairs[k] || {}).timeframe)) ? ' ⚡ kısa mum' : ''}`);
        if (active.length > 10) lines.push(`… ve ${active.length - 10} coin daha`);
        if (!active.length) lines.push('Aktif coin yok: bot başlasa da alım yapmaz (açık pozisyonları yönetir).');
        lines.push('', 'Başlatmak için 2 dakika içinde /basla_onayla yaz. Vazgeçmek için /iptal.', 'Canlı güvenlik kapıları (kasa, mutabakat, risk limitleri) motorda ayrıca zorunludur.');
        reply = lines.join('\n');
      } else {
        try {
          await startBot();
          reply = '▶ Paper bot başlatma isteği başarıyla uygulandı.\n\n' + formatStatus();
        } catch (err) {
          reply = `⛔ Bot başlatılamadı: ${String(err && err.message || err).slice(0, 700)}`;
        }
      }
    } else if (command === '/basla_onayla') {
      const status = getStatus() || {};
      if (!pendingStart || Date.now() - pendingStart.createdAt > START_TTL_MS) {
        pendingStart = null;
        reply = 'Bekleyen canlı başlatma yok ya da süresi doldu. Hiçbir şey başlatılmadı. Gerekirse önce /basla yaz.';
      } else if (!isLiveStatus(status)) {
        pendingStart = null;
        reply = 'Mod artık canlı değil; onay geçersiz. Hiçbir şey başlatılmadı. Paper için /basla yaz.';
      } else if (status.running) {
        pendingStart = null;
        reply = 'Bot zaten çalışıyor.\n\n' + formatStatus();
      } else {
        pendingStart = null;
        try {
          await startBot();
          reply = '▶ CANLI bot başlatma isteği uygulandı. Gerçek emirler motorun güvenlik kapılarına bağlıdır.\n\n' + formatStatus();
        } catch (err) {
          reply = `⛔ Bot başlatılamadı: ${String(err && err.message || err).slice(0, 700)}`;
        }
      }
    } else if (command === '/acil_durdur' || command === '/acil-durdur' || command === '/emergency_stop') {
      pendingEmergency = { createdAt: Date.now() };
      reply = '⚠ ACİL DURDURMA henüz UYGULANMADI.\nUygulanırsa bot motoru ve otonom tarama durur; botun pozisyon/stop takibi kesilir. Borsadaki emirler iptal edilmez, coinler satılmaz.\nUygulamak için 2 dakika içinde /acil_onayla yaz. Vazgeçmek için /iptal. Normal durdurma için /bitir.';
    } else if (command === '/acil_onayla') {
      if (!pendingEmergency || Date.now() - pendingEmergency.createdAt > EMERGENCY_TTL_MS) {
        pendingEmergency = null;
        reply = 'Bekleyen acil durdurma yok ya da süresi doldu. Hiçbir şey durdurulmadı. Gerekirse önce /acil_durdur yaz.';
      } else {
        pendingEmergency = null;
        try {
          if (typeof emergencyStopBot !== 'function') throw new Error('Acil durdurma bu kurulumda yapılandırılmamış. Motorun durumu değiştirilmedi.');
          const result = await emergencyStopBot('Telegram /acil_durdur komutu');
          reply = `🛑 ACİL DURDURMA UYGULANDI. Bot motoru ve otonom tarama durduruldu. Yeni işlemler ve botun pozisyon/stop takibi yapılmayacak. Borsaya daha önce gönderilmiş emirler iptal edilmedi; coinler satılmadı ve emirler değiştirilmedi. Canlı hesapta hemen Binance uygulamasından açık emirleri ve pozisyonları kontrol et.\n${result?.message || ''}\n\nBu komut güvenli durdurma değildir; botun izleme ve otomatik çıkış yönetimi durur.`;
        } catch (err) {
          reply = `⛔ Acil durdurma uygulanamadı: ${String(err && err.message || err).slice(0, 500)}`;
        }
      }
    } else if (command === '/bitir') {
      const status = getStatus() || {};
      const auto = status.autonomous || {};
      if (!status.running) {
        reply = 'Bot zaten durmuş. Telegram komut dinleyicisi açık kalıyor.\n\n' + formatStatus();
      } else if (auto.active || auto.stopping) {
        try {
          if (typeof stopAutonomous !== 'function') throw new Error('Güvenli otonom durdurma bu kurulumda yapılandırılmamış; motor durdurulmadı.');
          const result = await stopAutonomous();
          const after = getStatus() || status;
          reply = `⏳ Güvenli durdurma başlatıldı. Yeni otonom alımlar durduruluyor. ${result?.message || after.autonomous?.message || ''}\nAçık pozisyonlar çıkış/stop kurallarıyla yönetilmeye devam eder. Motor, tüm açık pozisyonlar kapanana kadar çalışır; bu sırada /durum ve /pozisyonlar ile kontrol edebilirsin.\n\n${formatStatus()}`;
        } catch (err) {
          reply = `⛔ Güvenli durdurma başlatılamadı; motorun mevcut durumu değiştirilmedi: ${String(err && err.message || err).slice(0, 500)}`;
        }
      } else if (Number(status.positions) > 0) {
        reply = `⚠ Motor durdurulmadı: ${Number(status.positions)} açık pozisyon var. /bitir bu pozisyonların stop/çıkış yönetimini kesmemek için reddedildi. Önce pozisyonların kapanmasını bekle; canlı hesapta borsadaki stop emirlerinin gerçekten mevcut olduğunu /emirler ile ayrıca doğrula.\n\n${formatStatus()}`;
      } else {
        try {
          await stopBot('Telegram /bitir komutu');
          reply = '⏹ Açık pozisyon olmadığı doğrulandı; bot motoru durduruldu. Telegram komut dinleyicisi açık kalıyor; yeniden başlatmak için /basla yazabilirsin.\n\n' + formatStatus();
        } catch (err) {
          reply = `⛔ Bot durdurulamadı: ${String(err && err.message || err).slice(0, 700)}`;
        }
      }
    } else if (command === '/coinler' || command === '/pariteler') {
      reply = formatPairs();
    } else if (command === '/coin_durdur' || command === '/coin-durdur') {
      reply = await setCoinEnabled(text.split(/\s+/).slice(1).join(' '), false);
    } else if (command === '/coin_ac' || command === '/coin-ac' || command === '/coin_aç') {
      reply = await setCoinEnabled(text.split(/\s+/).slice(1).join(' '), true);
    } else if (command === '/islemler' || command === '/işlemler') {
      reply = htmlTitle(formatTrades(text.split(/\s+/).slice(1).join(' ')));
    } else if (command === '/rapor') {
      reply = htmlTitle(formatReport(text.split(/\s+/).slice(1).join(' '))); 
    } else if (command === '/pozisyonlar' || command === '/pozisyon' || command === '/positions') {
      reply = formatPositions();
    } else if (command === '/loglar' || command === '/log' || command === '/logs') {
      reply = formatLogs(text.split(/\s+/).slice(1).join(' '));
    } else if (command === '/ayarlar' || command === '/ayar') {
      reply = htmlTitle(formatSettings());
    } else if (command === '/sessiz') {
      reply = handleMute(text.split(/\s+/).slice(1).join(' '));
    } else if (command === '/ozet' || command === '/özet') {
      if (typeof getDailySummaryText !== 'function') reply = 'Günlük özet bu kurulumda kullanılamıyor.';
      else {
        try { reply = { html: String(await getDailySummaryText()) }; }
        catch (err) { reply = `⛔ Özet oluşturulamadı: ${String(err && err.message || err).slice(0, 300)}`; }
      }
    } else {
      return false;
    }
    if (typeof auditCommand === 'function') {
      try { await auditCommand({ command, at: new Date().toISOString(), outcome: String(reply).startsWith('⛔') ? 'error' : 'handled' }); }
      catch (err) { logger.warn(`[telegram-denetim] kayıt yazılamadı: ${String(err?.message || err).slice(0, 160)}`); }
    }
    await sendReply(reply);
    return true;
  }

  async function pollOnce() {
    const updates = await api('getUpdates', { offset, timeout: pollTimeoutSeconds, allowed_updates: ['message', 'edited_message'] }, (pollTimeoutSeconds + 10) * 1000);
    for (const update of updates || []) {
      if (Number.isSafeInteger(update.update_id)) offset = Math.max(offset, update.update_id + 1);
      try { await processUpdate(update); }
      catch (err) { logger.warn(`[telegram-komut] yanıt gönderilemedi: ${String(err && err.message || err).replace(token, '***')}`); }
    }
  }

  async function run() {
    let consecutiveFailures = 0;
    while (!stopped) {
      try { await pollOnce(); warned = false; consecutiveFailures = 0; }
      catch (err) {
        consecutiveFailures += 1;
        if (!warned) {
          warned = true;
          logger.warn(`[telegram-komut] Telegram sorgusu başarısız: ${String(err && err.message || err).replace(token, '***')}`);
        }
        // Telegram 429 yanıtındaki retry_after'a uy; ağ hatalarında üstel geri
        // çekilme uygula. Sabit 3 sn döngüsü rate-limit süresince tekrar 429 üretirdi.
        const backoff = Math.min(60000, 3000 * (2 ** Math.min(4, consecutiveFailures - 1)));
        const delay = Math.max(backoff, Number(err?.retryAfterMs) || 0);
        await new Promise((resolve) => { const timer = setTimeout(resolve, delay); if (timer.unref) timer.unref(); });
      }
    }
  }

  function start() {
    if (!token || !chatId || !stopped) return false;
    stopped = false;
    // getUpdates ve webhook ayni anda kullanilamaz. Termux'taki bu uygulama polling
    // kullandigi icin eski webhook'u (bekleyen guncellemeleri silmeden) kaldir.
    loopPromise = (async () => {
      try { await api('deleteWebhook', { drop_pending_updates: false }, 10000); }
      catch (err) { logger.warn(`[telegram-komut] webhook temizlenemedi: ${String(err && err.message || err).replace(token, '***')}`); }
      if (!stopped) await run();
    })();
    if (loopPromise && typeof loopPromise.catch === 'function') loopPromise.catch(() => {});
    logger.log('[telegram-komut] etkin: /basla, /basla_onayla, /bitir, /acil_durdur, /acil_onayla, /durum, /bakiye, /rapor, /islemler, /coinler, /coin_ekle, /coin_sil, /coin_durdur, /coin_ac, /onayla, /iptal, /pozisyonlar, /loglar, /ayarlar, /ozet, /saglik, /tarama, /risk, /emirler, /bildirimler, /sessiz, /mod_paper, /mod_live, /mod_man, /mod_oto, /mod_onay, /oto_basla, /oto_basla_onay, /oto_bitir, /oto_durdur, /oto_durdur_onay, /yardim');
    return true;
  }
  async function stop() { stopped = true; if (loopPromise) await Promise.race([loopPromise, new Promise((r) => setTimeout(r, 1000))]); loopPromise = null; }

  return { start, stop, processUpdate, formatStatus, formatBalance, configured: () => Boolean(token && chatId), getPendingSetup: () => setup, getPendingRemove: () => pendingRemove, getPendingEnable: () => pendingEnable };
}

module.exports = { createTelegramCommands };
