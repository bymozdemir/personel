'use strict';

// Otonom modun kullanacağı stratejiler ve mum aralıkları. Kullanıcı panelden işaretler; null = varsayılan.
// Varsayılan: Agresif Kırılım KAPALI, diğer bütün stratejiler açık; mum aralıkları 15m ve üstü (1m/3m/5m yalnız manuel).

const strategies = require('./strategies');
const tfPolicy = require('./timeframePolicy');

const allStrategyIds = () => strategies.list().map((row) => row.id);
const defaultStrategyIds = () => allStrategyIds().filter((id) => !tfPolicy.isAggressive(id));
const autonomousTimeframes = () => tfPolicy.ALL_TIMEFRAMES.filter((tf) => !tfPolicy.isFast(tf));

// Doğrulanmış (geçmiş testten geçen) profil bulunamayan coinler için geçici varsayılan: trend stratejileri.
// rsi_ema_macd uzun süre sinyal vermediği için varsayılan DEĞİLDİR; yalnızca kullanıcı seçtiği stratejiler arasından seçilir.
const TREND_PREFERENCE = ['trend_regime', 'trend_filter_v2', 'trend_filter', 'regime_adx', 'trend_vote', 'supertrend', 'donchian_regime', 'adx_chandelier', 'tsmom', 'regime_pullback', 'regime_chandelier', 'regime_strict'];
function trendFallback(strategyIds) {
  const ids = Array.isArray(strategyIds) ? strategyIds : [];
  const hit = TREND_PREFERENCE.find((id) => ids.includes(id));
  if (hit) return hit;
  const other = ids.find((id) => id !== 'rsi_ema_macd' && !tfPolicy.isAggressive(id));
  return other || ids[0] || 'trend_regime';
}
const isTrendStrategy = (id) => TREND_PREFERENCE.includes(String(id || ''));

const isStringArray = (v) => Array.isArray(v) && v.every((x) => typeof x === 'string');

// Kayıtlı seçimden etkin seçimi çıkarır. Geçersiz/bozuk/boş kayıt varsayılana düşer (bot asla "hiç strateji yok" durumuna düşmez).
function resolve(autonomous) {
  const a = autonomous || {};
  const known = new Set(allStrategyIds());
  const tfs = new Set(autonomousTimeframes());
  const ids = isStringArray(a.strategyIds) ? [...new Set(a.strategyIds)].filter((id) => known.has(id)) : [];
  const frames = isStringArray(a.timeframes) ? [...new Set(a.timeframes)].filter((tf) => tfs.has(tf)) : [];
  return {
    strategyIds: ids.length ? allStrategyIds().filter((id) => ids.includes(id)) : defaultStrategyIds(),
    timeframes: frames.length ? autonomousTimeframes().filter((tf) => frames.includes(tf)) : autonomousTimeframes(),
    customStrategies: ids.length > 0,
    customTimeframes: frames.length > 0
  };
}

// Panelden gelen seçimi doğrular. { ok, error } ya da { ok:true, strategyIds, timeframes }.
function validate(input) {
  const body = input || {};
  if (!isStringArray(body.strategyIds) || !isStringArray(body.timeframes)) return { ok: false, error: 'Strateji ve mum aralığı listeleri gerekli.' };
  const known = new Set(allStrategyIds());
  const unknown = body.strategyIds.filter((id) => !known.has(id));
  if (unknown.length) return { ok: false, error: `Bilinmeyen strateji: ${unknown.join(', ')}` };
  const allowed = new Set(autonomousTimeframes());
  const bad = body.timeframes.filter((tf) => !allowed.has(tf));
  if (bad.length) {
    const fast = bad.filter((tf) => tfPolicy.isFast(tf));
    if (fast.length) return { ok: false, error: `${fast.join(', ')} otonom modda kullanılamaz; kısa mumlar yalnızca manuel çalışır.` };
    return { ok: false, error: `Geçersiz mum aralığı: ${bad.join(', ')}` };
  }
  const ids = allStrategyIds().filter((id) => body.strategyIds.includes(id));
  const frames = autonomousTimeframes().filter((tf) => body.timeframes.includes(tf));
  if (!ids.length) return { ok: false, error: 'En az bir strateji seçili olmalı.' };
  if (!frames.length) return { ok: false, error: 'En az bir mum aralığı seçili olmalı.' };
  return { ok: true, strategyIds: ids, timeframes: frames };
}

// Panelin çizeceği görünüm: bütün stratejiler (işaretli/işaretsiz) ve bütün mum aralıkları (kısa olanlar kilitli).
function view(autonomous) {
  const sel = resolve(autonomous);
  const picked = new Set(sel.strategyIds);
  const pickedTf = new Set(sel.timeframes);
  return {
    strategies: strategies.list().map((row) => ({ id: row.id, name: row.name, description: row.description || '', selected: picked.has(row.id), isDefault: !tfPolicy.isAggressive(row.id) })),
    timeframes: tfPolicy.ALL_TIMEFRAMES.map((tf) => ({ id: tf, selected: pickedTf.has(tf), locked: tfPolicy.isFast(tf) })),
    customStrategies: sel.customStrategies, customTimeframes: sel.customTimeframes
  };
}

module.exports = { trendFallback, isTrendStrategy, TREND_PREFERENCE, allStrategyIds, defaultStrategyIds, autonomousTimeframes, resolve, validate, view };
