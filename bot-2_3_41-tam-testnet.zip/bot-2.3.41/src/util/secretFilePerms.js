'use strict';
const fs = require('fs');

// Gizli bilgi iceren dosyalar (.env: Telegram token, API anahtari) yalniz sahibi tarafindan okunabilmeli.
// POSIX (Termux/Linux/VPS) disinda (Windows) izin bitleri anlamsizdir; sessizce gecilir.
// Donus: { checked, tightened, mode, error }
function tightenSecretFile(file, { log = () => {} } = {}) {
  const out = { checked: false, tightened: false, mode: null, error: null };
  if (process.platform === 'win32') return out;
  try {
    const st = fs.statSync(file);
    if (!st.isFile()) return out;
    out.checked = true;
    out.mode = st.mode & 0o777;
    if ((out.mode & 0o077) !== 0) {
      fs.chmodSync(file, 0o600);
      out.tightened = true;
      log(`[guvenlik] ${file} izinleri ${out.mode.toString(8)} idi (grup/diger okuyabilir); 600 yapildi.`);
    }
  } catch (e) {
    if (e && e.code === 'ENOENT') return out;
    out.error = String(e && e.message || e);
    log(`[guvenlik] ${file} izinleri kontrol edilemedi: ${out.error}`);
  }
  return out;
}
module.exports = { tightenSecretFile };
