// src/strategies/bollingerReversion.js
//
// Bollinger Bantlari ile ortalamaya donus (mean reversion):
// ALIM : fiyat ALT banda deger ya da altina iner (asiri satilmis gorunur)
// SATIM: fiyat ORTA banda (hareketli ortalamaya) doner  VEYA  take-profit  VEYA  stop-loss  VEYA  trailing stop
//
// RSI/EMA/MACD'den TAMAMEN farkli bir indikator (oynaklik bantlari) kullanir.

const { bollinger } = require('../indicators');
const { riskExitFirst } = require('./riskExit');

const defaultParams = {
  period: 20,
  stdDevMult: 2,
  stopLossPct: 3,
  takeProfitPct: 5,
  trailingStop: false
};

const paramsSchema = [
  { key: 'period', label: 'Bant periyodu', type: 'number', min: 5, max: 100, step: 1 },
  { key: 'stdDevMult', label: 'Standart sapma çarpanı', type: 'number', min: 0.5, max: 4, step: 0.1 },
  { key: 'stopLossPct', label: 'Stop-Loss (%)', type: 'number', min: 0.1, max: 50, step: 0.1 },
  { key: 'takeProfitPct', label: 'Kâr koruma eşiği (%) · bu kârdan sonra stop yukarı taşınır', type: 'number', min: 0.1, max: 200, step: 0.1 },
  { key: 'trailingStop', label: 'Trailing stop', type: 'boolean' }
];

function minCandles(params) {
  return params.period + 5;
}

function evaluate({ candles, position, params }) {
  // Pozisyon aciksa risk kurallari (stop-loss/take-profit) HER ZAMAN once bakilir,
  // indikatorler hesaplanamasa bile.
  const early = riskExitFirst(candles, position, params);
  if (early) return early;

  if (!candles || candles.length < minCandles(params)) {
    return { action: 'hold', reason: 'yetersiz veri (indikatörler için daha fazla mum lazım)' };
  }

  const closes = candles.map((c) => c.c);
  const i = closes.length - 1;
  const bands = bollinger(closes, params.period, params.stdDevMult);
  const price = closes[i];

  if (bands.lower[i] === null || bands.middle[i] === null) {
    return { action: 'hold', reason: 'indikatörler henüz hesaplanamadı', price };
  }

  if (!position) {
    // Tek başına banda dokunmak düşüş trendinde tekrar tekrar zarar üretebilir.
    // Önceki kapanış alt bantta/altındayken bu mumun tekrar bandın içine
    // kapanmasını ve yeşil dönüşü bekle.
    const prevLower = bands.lower[i - 1];
    const prevClose = closes[i - 1];
    const bullishReentry = Number.isFinite(prevLower) && prevClose <= prevLower &&
      price > bands.lower[i] && candles[i].c > candles[i].o && price > prevClose;
    if (bullishReentry) {
      return { action: 'buy', reason: `Alt Bollinger bandına dönüş onaylandı: kapanış yeniden bandın üstünde`, price };
    }
    return { action: 'hold', reason: `Bant teması tek başına yeterli değil; kapanışla dönüş onayı bekleniyor`, price };
  }

  // Orta banda ilk değme yerine kapanışla geçişi kullan; bandın orta çizgisi
  // hedef değil, dönüşün teyididir. Risk/kar koruma çıkışları riskExitFirst'te.
  if (price >= bands.middle[i] && closes[i - 1] < bands.middle[i - 1]) {
    return { action: 'sell', reason: 'Fiyat orta Bollinger bandına kapanışla döndü', price };
  }

  return { action: 'hold', reason: 'pozisyon açık, ortalamaya dönüş bekleniyor', price };
}

module.exports = {
  id: 'bollinger_reversion',
  name: 'Bollinger Bantları (ortalamaya dönüş)',
  description: 'Alım: önceki kapanış alt bantta, ardından yeşil mumla bandın içine dönüş teyidi. Satım: orta banda kapanışla dönüş; risk/kar koruma ayrıca çalışır.',
  defaultParams,
  paramsSchema,
  minCandles,
  evaluate
};
