# Otonom portföy devralma — 2.3.14

- İlk Testnet senkronizasyonunda uygun, fiat/stablecoin olmayan hesap bakiyeleri mevcut piyasa fiyatı referans maliyetiyle yönetilen pozisyona alınır; benimseme tek başına BUY emri göndermez.
- Her devralınan coin için yeni BUY sinyali beklemeden yönetim stratejisi ve zaman dilimi seçilir; geçici veri hatasında korumalı varsayılan profil ile yönetim sürer ve seçim yeniden denenir.
- Sonradan hesaba gelen/çevrilen ek coin bakiyeleri sonraki senkronizasyonda mevcut yönetilen miktara eklenir.
- Ayarlar'daki parite listesine tüm piyasa evreni kopyalanmaz. Tarayıcı her turda borsanın uygun USDT parite evrenini doğrudan tarar.
- Satılan otonom coin Ayarlar listesinden çıkarılır; sonraki taramada tüm piyasa evreninden yeniden keşfedilebilir ve yeni sinyal oluşursa tekrar alım adayı olabilir.
- Manuel parite ayarları korunur. Mevcut bakiye benimseme üst sınırı, minimum emir/toz kontrolleri, günlük rotasyon limiti, nakit rezervi, pozisyon sınırı, koruyucu stop, kill switch ve Testnet/Production ayrımı korunur.

## Testnet varsayılanı

`.env.example` yalnızca güvenli başlangıç değerleri içerir: Paper varsayılandır; Testnet emir kapısı ve tüm Production kapıları kapalıdır. Gerçek `.env` dağıtım ZIP'ine konulmaz.

## Doğrulama

- `node --check` kaynak kontrolleri
- Otonom tarayıcı, mevcut bakiye benimseme, sermaye tahsisi ve izleme listesi hedefli testleri
- `npm run preflight`
- Binance Spot Testnet'e emir gönderimi paket doğrulamasına dahil değildir.
