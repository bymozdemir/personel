// Sekme gezinmesi (sadece arayuz). app.js ve sunucu ile hicbir bagi yoktur:
// tum bolumler DOM'da kalir, sadece gorunurluk degisir; bu yuzden app.js'in
// render/polling/WebSocket akisi sekme degisse de aynen calismaya devam eder.
(() => {
  'use strict';
  const STORE_KEY = 'panelTab';
  // İlk HTML'de otonom sekmesi varsayılan olarak hidden gelir.
  // Sayfa #autonomous ile yenilenirse, uygulama durumu yüklenene kadar bu
  // isteği sakla; sekme görünür olduğunda ilk istenen bölüme geç.
  let pendingInitialTab = location.hash.replace('#', '') === 'autonomous' ? 'autonomous' : null;
  const btns = Array.from(document.querySelectorAll('.tabBar .tabBtn'));
  const panels = Array.from(document.querySelectorAll('.tabPanel'));
  const picker = document.getElementById('panelTabSelect');
  if (!btns.length || !panels.length) return;
  const names = btns.map((b) => b.dataset.tab);
  const visibleNames = () => btns.filter((b) => !b.hidden).map((b) => b.dataset.tab);

  function saved() {
    try { return localStorage.getItem(STORE_KEY); } catch (_) { return null; }
  }
  function save(name) {
    try { localStorage.setItem(STORE_KEY, name); } catch (_) { /* depolama kapali olabilir */ }
  }

  function show(name, { scroll = true, focus = false } = {}) {
    if (!visibleNames().includes(name)) name = visibleNames()[0] || names[0];
    btns.forEach((b) => {
      const on = b.dataset.tab === name;
      b.setAttribute('aria-selected', on ? 'true' : 'false');
      b.tabIndex = on ? 0 : -1;
      if (on && focus) b.focus();
    });
    panels.forEach((p) => { p.hidden = p.dataset.tab !== name; });
    if (picker) {
      picker.value = name;
      const autoButton = btns.find((b) => b.dataset.tab === 'autonomous');
      const autoOption = picker.querySelector('option[value="autonomous"]');
      if (autoButton && autoOption) autoOption.hidden = autoButton.hidden;
    }
    save(name);
    try { history.replaceState(null, '', '#' + name); } catch (_) { /* yoksay */ }
    if (scroll) window.scrollTo(0, 0);
    // Grafik gizliyken olculemez (app.js drawChart genisligi 0 ise cizmez);
    // sekme gorununce app.js'in mevcut resize dinleyicisi yeniden cizsin.
    requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
  }

  if (picker) picker.addEventListener('change', () => show(picker.value));
  const autoButtonForMenu = btns.find((b) => b.dataset.tab === 'autonomous');
  const syncAutoOption = () => {
    const option = picker?.querySelector('option[value="autonomous"]');
    if (option && autoButtonForMenu) option.hidden = autoButtonForMenu.hidden;
    if (picker && picker.value === 'autonomous' && autoButtonForMenu?.hidden) picker.value = 'live';

    // app.js state'i yükleyip otonom modu görünür yaptığında, yenilemeden
    // önce istenen #autonomous sekmesini geri aç. Manuel modda gizli kalır.
    if (pendingInitialTab === 'autonomous' && autoButtonForMenu && !autoButtonForMenu.hidden) {
      pendingInitialTab = null;
      show('autonomous', { scroll: false });
    }
  };
  if (autoButtonForMenu && typeof MutationObserver !== 'undefined') {
    new MutationObserver(syncAutoOption).observe(autoButtonForMenu, { attributes: true, attributeFilter: ['hidden'] });
  }
  syncAutoOption();

  btns.forEach((b, i) => {
    b.addEventListener('click', () => show(b.dataset.tab));
    b.addEventListener('keydown', (e) => {
      const visible = btns.filter((x) => !x.hidden);
      const at = visible.indexOf(b);
      let j = -1;
      if (e.key === 'ArrowRight') j = (at + 1) % visible.length;
      else if (e.key === 'ArrowLeft') j = (at - 1 + visible.length) % visible.length;
      else if (e.key === 'Home') j = 0;
      else if (e.key === 'End') j = visible.length - 1;
      if (j < 0 || !visible.length) return;
      e.preventDefault();
      show(visible[j].dataset.tab, { scroll: false, focus: true });
    });
  });

  window.addEventListener('hashchange', () => {
    const h = location.hash.replace('#', '');
    if (visibleNames().includes(h)) show(h, { scroll: false });
  });

  const fromHash = location.hash.replace('#', '');
  show(visibleNames().includes(fromHash) ? fromHash : (visibleNames().includes(saved()) ? saved() : visibleNames()[0]), { scroll: false });
})();

// Katlanir bolumler (sadece arayuz): acik/kapali durum tarayicida hatirlanir.
(() => {
  'use strict';
  document.querySelectorAll('details.fold[id]').forEach((d) => {
    const key = 'fold:' + d.id;
    try {
      const v = localStorage.getItem(key);
      if (v === 'open') d.open = true;
      else if (v === 'closed') d.open = false;
    } catch (_) { /* depolama kapali olabilir */ }
    d.addEventListener('toggle', () => {
      try { localStorage.setItem(key, d.open ? 'open' : 'closed'); } catch (_) { /* yoksay */ }
      // Grafik gibi olculen ogeler gorununce yeniden cizilsin.
      requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
    });
  });
})();
