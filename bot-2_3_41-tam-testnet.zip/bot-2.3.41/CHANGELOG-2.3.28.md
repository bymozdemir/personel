# 2.3.28 — Telegram operation safety additions

## Included
- Added persistent `settings.entriesPaused` default. It blocks new BUY entries in Paper and Live while leaving existing-position exits, risk checks and protective-stop management active.
- Added Telegram `/alim_durdur` and `/alim_baslat`; both report the persisted result and do not stop the engine.
- `/durum` and `/ayarlar` expose the new-entry pause state.
- Added real exchange order lifecycle Telegram notices for non-protective orders: NEW, PARTIALLY_FILLED, FILLED, CANCELED, REJECTED, EXPIRED and UNKNOWN. UNKNOWN/REJECTED are critical; protective STOP/TP fills continue using their dedicated accounting notices to avoid duplicate fill messages.
- Added tests for Paper/Live entry pause and order lifecycle notification behavior.

## Safety boundaries
- Binance Spot Testnet remains the only enabled live target in `.env.example`; production remains disabled.
- No automatic engine start was added to mode changes or pause toggles.
- The autonomous position capacity was not changed.

## Validation
- Offline preflight passed: 6 critical files, 19 strategy defaults, Paper default, live safety lock off, no obvious embedded secrets.
- Focused tests passed: 71 tests before the final Paper pause and order lifecycle tests; the added Paper pause test passed (7/7 in its file), and order lifecycle notifications passed (13/13 in its file).
- A full batched test run was started but exceeded the available execution window. It is not claimed as a complete pass.
- Server integration tests could not run in this environment because `express`, `dotenv`, and `ws` could not be installed (npm registry access timed out).

## Historical follow-up status
The previously deferred features were implemented in 2.3.29; see `CHANGELOG-2.3.29.md`.
