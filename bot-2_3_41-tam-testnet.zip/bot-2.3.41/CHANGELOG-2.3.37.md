# 2.3.37 — Otonom durdurmayı iptal ederek devam etme

- Güvenli durdurma (`stopping`) sürerken Otonom Başlat komutu artık mevcut oturumu devam ettirir.
- Açık pozisyonlar, miktarlar, maliyet kayıtları ve mevcut borsa koruma emirleri sıfırlanmaz veya yeniden oluşturulmaz.
- Önceki otonom oturumun yönetilen coin listesi ve manuel ayar anlık görüntüsü korunur.
- Durdurma sırasında çalışan eski tarama nesli geçersiz kılınır; yeniden başlatmada yeni bir tarama başlatılır.
- Güvenli durdurma tamamlandığında durum açıkça `idle` olur; sonraki başlatma yeni oturum açabilir.
- Panelde durdurma beklerken başlat düğmesi etkin kalır ve “Durdurmayı iptal et ve devam et” yazar.
- Canlı modun yeniden başlatma öncesi mevcut güvenlik/hesap denetimleri korunur.

Bu sürüm kaynak kod değişikliğidir; Binance Testnet üzerinde uçtan uca emir/pozisyon senaryosu ayrıca doğrulanmalıdır.
