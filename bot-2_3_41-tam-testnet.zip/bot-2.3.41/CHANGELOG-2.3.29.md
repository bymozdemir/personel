# 2.3.29 — Telegram otonom kontrol ve performans raporları

- Otonom yeni alımlar için otomatik veya Telegram onaylı mod eklendi. Onay, doğrudan emir üretmez; aynı kapanmış mumdaki sinyal motor tarafından yeniden doğrulanır ve tüm güncellik, bakiye, risk, borsa ve koruyucu stop kapılarından geçer.
- `/alim_bekleyen`, `/alim_onay ID`, `/alim_reddet ID`, `/alim_mod otomatik|onaylı` komutları eklendi.
- `/alim_durdur` ve `/alim_baslat` ile yeni girişleri duraklatma; açık pozisyonların satış/koruma yönetimini sürdürme desteği eklendi.
- Günlük, haftalık ve aylık performans raporları; coin ve strateji kırılımları eklendi. Gerçekleşmiş ve gerçekleşmemiş K/Z ayrı raporlanır; kayıtlı komisyonlar gösterilir.
- Haftalık ve aylık raporların İstanbul saatine göre otomatik gönderimi eklendi.
- Kalıcı günlük sessiz saat aralığı (`/sessiz HH:MM-HH:MM`) eklendi; kritik güvenlik bildirimleri sessiz saat ve kategori filtrelerinden etkilenmez.
- Canlı işlem geçmişine strateji, mum aralığı ve giriş+çıkış komisyon toplamı kaydı eklendi.
- Binance Spot Testnet dışı canlı işlem izni kapalı kalır.

## Validation
- Offline preflight passed: critical files, 19 strategy defaults, Paper default, live safety lock off, and no obvious embedded secrets.
- Curated groups 0–4 and 6 passed (1,169 tests); group 5 passed 222 tests. Total passed: 1,391.
- The single real HTTP/WebSocket server integration test remains unverified because `express`, `dotenv`, and `ws` were unavailable; `npm ci` failed in the build environment. Run `npm ci` and then `npm run test:server-integration` on the device before testnet operation.
