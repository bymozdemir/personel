# Recovery safety fix — 2.3.12

- Recovery stop POST yanıtı `UNKNOWN`/`PENDING` ise yeni emir gönderilmez; aynı `clientOrderId` ile borsadan sorgulanır. Sonuç doğrulanamazsa canlı başlangıç fail-closed kalır.
- Recovery, miktarı pozisyonla eşleşse bile `LIMIT`/bağımsız `TAKE_PROFIT` SELL emirlerini koruyucu stop olarak sahiplenmez.
- OCO kurtarması yalnızca aynı `orderListId` altında miktarı eşleşen bir STOP_LOSS/STOP_LOSS_LIMIT ve bir TAKE_PROFIT/TAKE_PROFIT_LIMIT/LIMIT_MAKER bacağı varsa yapılır.
- Regresyon testleri: tam miktarlı normal LIMIT SELL'in stop sayılmaması ve UNKNOWN stopun aynı emir kimliğiyle sorgulanması.

Bu sürüm Binance Testnet/Production üzerinde gerçek emir göndererek doğrulanmamıştır. Canlı mod öncesi açık emirler ve pozisyonlar read-only olarak incelenmelidir.
