# Al-Sat Bot 2.3.29 — Source Package

Paper-first spot trading bot. This archive is a source package for review and user-side testing; it is **not a declaration of live-trading readiness**.

## Safe defaults

- Default mode: `paper`.
- Live trading is disabled unless explicitly enabled.
- Binance testnet and production trading each require their own explicit environment gates.
- Never put API keys in source control or share `.env` files.
- Do not enable production trading based only on automated test results.

## Earlier hardening carried forward

- Exit accounting now requires an exchange-reported quote amount. It never substitutes the current ticker/decision price for missing execution proceeds.
- If net quote is absent/zero but gross quote is present, quote-asset commission is deducted exactly once; third-asset commission valuation remains separately enforced.
- Missing/invalid proceeds or commission valuation preserves the position record and closes the live-trading gate for reconciliation.
- Autonomous position management no longer selects a relaxed/negative historical profile when no profile passes strict validation. Existing strategy and protective stop remain in place and selection can be retried later.
- Management scans have a configurable total time budget (`BOT_MANAGEMENT_SCAN_TIMEOUT_MS`, default 90000 ms, bounded 1000–300000 ms).
- Candle freshness is checked against the current exchange-adjusted clock for each timeframe, not a timestamp captured before a long scan.
- Selected strategy parameters are carried into the position/pair management configuration.
- Pending-order refresh and startup reconciliation use bounded parallelism (default 3, hard cap 4) instead of serial per-order REST waits; the open-orders batch shortcut remains in place.

## Local checks

```bash
npm ci
npm run preflight
npm run test:batched
```

Node.js 18 or newer is required. The source test suite includes simulated exchange, accounting model-checker, chaos, recovery, stop, and strategy-selection tests. The real HTTP/WebSocket server integration test requires installed runtime dependencies (`express`, `dotenv`, `ws`).

## Important test note for this package build

Offline preflight passed. Curated groups 0–4 and 6 passed (1,169 tests); group 5 passed all tests except the real server integration test, which could not start because `express`, `dotenv`, and `ws` could not be installed in the build environment. The server integration test must be rerun after `npm ci` on the target device. Across the curated groups, 1,391 tests passed; one HTTP/WebSocket integration test remains unverified due to missing runtime dependencies. Do not treat source-level tests as proof of live-trading readiness.

## Configuration

Copy `.env.example` to `.env` and configure credentials locally. The runtime still starts in Paper mode. The sample environment explicitly opts into Binance Spot Testnet only (`BINANCE_ENV=testnet`, `ALLOW_BINANCE_TESTNET_TRADING=true`, `ALLOW_PRODUCTION_TRADING=false`); production trading remains disabled. Enter API credentials locally through the panel and complete the read-only account audit before starting a live Testnet engine.

## Version 2.3.29 Telegram additions

- `/alim_durdur` and `/alim_baslat` pause/resume new BUY entries without stopping management of existing positions.
- `/alim_mod otomatik|onaylı`, `/alim_bekleyen`, `/alim_onay ID`, and `/alim_reddet ID` control autonomous buy approval. Approval is a one-shot authorization for the exact closed candle; it does not directly submit an order. The engine re-evaluates the signal and rechecks freshness, balance, risk and live safety gates.
- `/rapor haftalik`, `/rapor aylik`, `/rapor gunluk`, `/rapor strateji`, and `/rapor coin` provide period and breakdown performance. Realized and unrealized P/L are kept separate.
- Weekly and monthly reports are scheduled in Istanbul time (`PERFORMANCE_SUMMARIES`, `PERFORMANCE_SUMMARY_TIME`).
- `/sessiz HH:MM-HH:MM` configures persistent daily quiet hours in Istanbul time. Critical risk/security alerts remain audible and bypass category mutes.
- Normal order lifecycle notices cover submitted, partial/full fill, cancel, reject, expiry and unknown status; unknown/rejected outcomes are critical.

See `CHANGELOG-2.3.29.md` for details. The current source package is not a declaration of live-trading readiness.
