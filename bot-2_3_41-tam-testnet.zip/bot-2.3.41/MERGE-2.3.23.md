# 2.3.23 — 2.3.22 (temel) + 2.3.20-log-analizi düzeltmeleri birleşimi

## 2.3.22'den korunanlar
- Otonom aşama modeli (`autonomousPhase.js`): hediye bakiye önce sinyalle yönetilir, açık pozisyon sayısı seçilen sınırın altına inince yeni alım açılır; tarama sürekli çalışır.
- Tarama sırasında `rotateAdopted` çağrısı yok (hediye coinler erken satılmaz).
- Daha doğru zaman aşımı mesajı (IPv6 varsayımı yok), genel public istek bütçesi 30 sn / ilk deneme 12 sn.
- Mutabakat başarısız olunca kilit nedeni genel metinde kalmaz.

## Eklenenler
1. `orderManager.refreshPending`: tek `fetchOpenOrders` ile açık ve değişmemiş NEW stop emirleri tek tek sorgulanmaz (60 seri sorgu → uzun kilit).
2. `binance.js`: ağır `ticker/24hr` için ayrı süre (varsayılan 25 sn, `BINANCE_HEAVY_TIMEOUT_MS`), 30 sn önbellek, geçici hatada 15 dk'ya kadar eski veri.
3. Kilit nedeni: ilk 3 engel gösterilir, aynı metin tekrar loglanmaz.
4. "Yönetim profili bulunamadı" uyarısı coin başına 60 dk'da bir.
5. Testler: `refreshPendingBatch`, `tickerCacheStale`.

## Açık konu (bilinçli olarak değiştirilmedi)
Sahiplenme 60'a kadar sürekli doldurulur. Hesapta 60'tan fazla varlık varsa açık pozisyon sayısı seçilen sınırın (1–32) altına inmez ve yeni otonom alım açılmaz. İstersen `adoptMaxPositions` ayarını seçilen sınırın altına çek.
