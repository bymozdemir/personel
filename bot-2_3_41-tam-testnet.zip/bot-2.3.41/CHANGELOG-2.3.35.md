# 2.3.35 — Stop kilidi kök neden düzeltmesi + isteğe bağlı sinyal tazelik ayarı (2.3.33 ve 2.3.34 dahil)

**Gece kaydından bulgu (13 saat, 2.3.32 dönemi):** 6 alımın 6'sında koruyucu stop sonrası "koruyucu stop kurulamadı (UNKNOWN); canlı işlem kilitlendi" hatası çıktı; stop aslında borsada kuruluydu, mutabakat 2-3 dakikada bağladı. `liveOrders` kaydında 65 stop için "Borsa stop emri durumunu doğrulamadı" yazıyor.

**Kök neden:** Binance Spot'ta STOP_LOSS / TAKE_PROFIT emirlerinin varsayılan yanıt tipi ACK'tir (yanıtta `status` yok). `normalizeStatus` boş durumu UNKNOWN sayıyor; bot da her alımdan sonra canlı işlemi kısa süre kilitliyordu (ve kritik bildirim gönderiyordu).

**Değişiklik:**
- `src/exchanges/binance.js`: `createStopOrder` ve `createTakeProfitOrder` artık `newOrderRespType=RESULT` gönderir (yanıt `status` içerir). Yeni test: `test/stopRespType.test.js`.
- `src/liveEngine.js`: İsteğe bağlı `BOT_SIGNAL_MAX_AGE_MIN` (dakika): tanımlıysa taze alım sinyali penceresinin tabanı olur; üst sınır yine mumun yarısı. Tanımsızsa DAVRANIŞ DEĞİŞMEZ (≈3 dk). Gece kaydında 16 "alım sinyali eski" kaydının yaşları 11-12 ve 22 dk civarında kümeleniyordu: taramanın bitişi, aday mumun kapanışından ≈11 dk sonra olduğu için sinyal motora yaşlı ulaşıyordu. Denenecek değer: 12.
- Önceki sürümler dahil: 2.3.33 (saat başı rapor, `scripts/bekci.js`), 2.3.34 (çekirdek+kuyruk tarama).

**Değişmeyenler:** Alım/satış mantığı, rotasyon, sahiplenme sınırı, portföy kapıları.

**Testler:** Bu ortamda tüm `test/*.test.js` çalıştırıldı; 1405 testten 1404 geçti. `serverIntegration.test.js` bu ortamda `node_modules` olmadığı için önceki sürümlerde de başarısız (telefonda `npm test` çalıştırılmalı).
