# 2.3.20 — Termux/Testnet log follow-up

## Changes
- Binance public market-data request budget default increased from 22s to 30s. The first endpoint attempt now receives up to 12s (previously 8s); the retry is only used when the remaining total budget permits it. This targets the repeated 8-second public market-data timeouts seen in the supplied Termux logs without changing signed/private order request timeouts.
- Network timeout diagnostics no longer imply that IPv6 is the likely cause when `DNS_ORDER=ipv4first` is already active. The message now reports the configured DNS order and notes that a timeout alone does not prove an IPv6 fault.
- Autonomous rotation no longer liquidates adopted holdings when zero new candidates passed the live cash/minimum-order allocator. Rotation remains available when all slots are occupied or at least one genuinely affordable candidate exists.
- Failed account reconciliation now records the first concrete reconciliation blocker in `live.lockReason` (balance mismatch, missing/unknown order, stop mismatch, or API query error) instead of leaving only the generic “balance reconciliation pending” message. A clean reconciliation still clears the lock reason.

## Validation
- Offline preflight: passed.
- Focused tests: network fallback 15/15; live recovery 7/7; live engine 33/33; reconciliation 17/17; holdings adoption 32/32; order manager 27/27; autonomous scanner 16/16.
- Full suite and real Binance Spot Testnet execution were not completed in this environment. `npm ci` did not complete, so server integration tests requiring Express/Dotenv/WebSocket dependencies are not claimed.
- No API credentials, `.env`, `data/`, runtime state, or `node_modules` are included in the source archive.

## Important findings from supplied logs
- The process printed `mode=paper` before the later live-engine startup and live SELL events. The excerpt does not prove whether the user switched the mode after boot; confirm the authenticated panel/health status says `live` and the exchange environment says `testnet` before continuing.
- The logs show up to 60 non-stablecoin assets being adopted with first-observed prices as reference cost basis. That is not the original purchase cost; P/L on those adopted holdings is therefore approximate, not historical realized performance.
- `Stop UNKNOWN` events were later followed by logs showing existing exchange protective stops attached. This is evidence of eventual recovery for those examples, not proof that every position was protected during the interval.
- The two balance-reconciliation lock periods lasted about 99 and 49 minutes. The supplied excerpts did not include the actual reconciliation error details, so the exact historical blocker cannot be proven retrospectively. Version 2.3.20 exposes the concrete blocker in future lock diagnostics.
- Autonomous discovery scanned 483 USDT pairs and reported no affordable candidates. The supplied log also showed rotations while this filter was empty; that was a code-path flaw. Version 2.3.20 prevents this empty-affordability rotation, while retaining slot/cash rotation when a genuinely affordable candidate exists.
- The log's repeated Telegram `fetch failed` indicates a separate Telegram/network connectivity issue; it does not itself prove exchange order failure.
