'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { resolveAutonomousPhase, canEnableAutonomousEntry } = require('../src/autonomousPhase');

test('hediye Testnet pozisyonları seçilen sınırın üstünde veya eşitken yeni alım slotu açılmaz', () => {
  for (const limit of [1, 2, 4, 8, 16, 32]) {
    for (const managed of [limit, limit + 1, 32, 60]) {
      if (managed < limit) continue;
      const phase = resolveAutonomousPhase({ managedPositionCount: managed, selectedCount: limit });
      assert.equal(phase.phase, 'gift-management');
      assert.equal(phase.entrySlots, 0);
      assert.equal(phase.canOpenAutonomousEntries, false);
    }
  }
});

test('otonom yeni alım yalnızca yönetilen pozisyon sayısı seçilen sınırın altına inince açılır', () => {
  for (const limit of [1, 2, 4, 8, 16, 32]) {
    const phase = resolveAutonomousPhase({ managedPositionCount: limit - 1, selectedCount: limit });
    assert.equal(phase.phase, 'autonomous-entry');
    assert.equal(phase.entrySlots, 1);
    assert.equal(phase.canOpenAutonomousEntries, true);
  }
});

test('piyasa tarama aşaması ile alım yetkisi birbirinden bağımsızdır', () => {
  const phase = resolveAutonomousPhase({ managedPositionCount: 60, selectedCount: 32 });
  assert.equal(phase.phase, 'gift-management');
  assert.equal(phase.canOpenAutonomousEntries, false);
  // Tarama server.js içinde her durumda çalışır; bu yardımcı yalnızca giriş slotunu hesaplar.
});

test('açık hediye pozisyonu yeni girişe yeniden açılmaz; yalnızca tarayıcının seçtiği boş aday açılır', () => {
  assert.equal(canEnableAutonomousEntry({ selectedAsEntryCandidate: false, hasOpenPosition: false }), false);
  assert.equal(canEnableAutonomousEntry({ selectedAsEntryCandidate: true, hasOpenPosition: true }), false);
  assert.equal(canEnableAutonomousEntry({ selectedAsEntryCandidate: true, hasOpenPosition: false }), true);
});
