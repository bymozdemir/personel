'use strict';
const test=require('node:test'); const assert=require('node:assert/strict'); const fs=require('node:fs'); const os=require('node:os'); const path=require('node:path'); const {createNotifier}=require('../src/notify');
test('İstanbul sessiz saatleri kalıcıdır ve kritik uyarıları sessize almaz',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'quiet-hours-')); const sent=[]; let now=Date.parse('2026-10-31T23:00:00+03:00');
  const notifier=createNotifier({env:{TELEGRAM_BOT_TOKEN:'x',TELEGRAM_CHAT_ID:'1',BOT_DATA_DIR:dir,NOTIFY_MIN_GAP_MS:'0'},now:()=>now,fetchFn:async(u,o)=>{sent.push(JSON.parse(o.body));return {ok:true,status:200,json:async()=>({ok:true,result:{message_id:sent.length}})}},logger:{log(){},warn(){}},sleep:async()=>{}});
  notifier.setQuietHours('22:00','08:00',true); assert.equal(notifier.isMuted(),true);
  await notifier.send('rutin işlem bildirimi',{category:'trading'}); await notifier.send('kritik stop kayboldu',{priority:'critical',category:'risk'});
  assert.equal(sent.length,2); assert.equal(sent[0].disable_notification,true); assert.notEqual(sent[1].disable_notification,true);
  const next=createNotifier({env:{TELEGRAM_BOT_TOKEN:'x',TELEGRAM_CHAT_ID:'1',BOT_DATA_DIR:dir},now:()=>now,fetchFn:async()=>({ok:true,status:200,json:async()=>({ok:true})}),logger:{log(){},warn(){}}});
  assert.equal(next.detail().quietHours.enabled,true); now=Date.parse('2026-11-01T09:00:00+03:00'); assert.equal(next.isMuted(),false); fs.rmSync(dir,{recursive:true,force:true});
});
