const test = require('node:test');
const assert = require('node:assert/strict');
const { runPortfolioBacktest } = require('../src/backtest/portfolioSimulator');
const { parseExtras, PRESETS } = require('../src/backtest/extrasPresets');

const H = 3600000;
function series(n, fn, vol = 10) {
  return Array.from({ length: n }, (_, i) => {
    const o = fn(i), c = fn(i + 1);
    return { t: 1_700_000_000_000 + i * H, o, h: Math.max(o, c) * 1.001, l: Math.min(o, c) * 0.999, c, v: typeof vol === 'function' ? vol(i) : vol };
  });
}
// Her mum: pozisyon yoksa AL, varsa SAT (maksimum islem sikligi).
const churn = { id: 'churn', defaultParams: { stopLossPct: 50 }, minCandles: () => 5, evaluate: ({ position }) => (position ? { action: 'sell', reason: 'don' } : { action: 'buy', reason: 'gir' }) };
// Hep AL, asla satma.
const holder = { id: 'holder', defaultParams: { stopLossPct: 50 }, minCandles: () => 5, evaluate: ({ position }) => (position ? { action: 'hold', reason: 'tut' } : { action: 'buy', reason: 'gir' }) };
const base = { startIndex: 10, capital: 1000, feePct: 0.1, slippagePct: 0.05, reserveCashPct: 10, maxConcurrentPositions: 1, budgetPct: 50 };
const run = (datasets, symbols, strategy, extra = {}) => runPortfolioBacktest({ datasets, symbols, endIndex: datasets[symbols[0]].candles.length - 1, strategy, params: strategy.defaultParams, ...base, ...extra });

test('ek katman yokken ve hepsi kapaliyken sonuc birebir ayni (geriye donuk uyum)', () => {
  const ds = { 'AAA/USDT': { candles: series(80, (i) => 100 + Math.sin(i / 3) * 3) } };
  const a = run(ds, ['AAA/USDT'], churn);
  const b = run(ds, ['AAA/USDT'], churn, { extras: {} });
  assert.equal(b.returnPct, a.returnPct);
  assert.equal(b.trades, a.trades);
  assert.equal(a.extrasStats, null);
  assert.deepEqual(b.extrasStats.blocked, {});
});

test('cooldown: ayni pariteye kisa surede tekrar giris engellenir, islem sayisi duser', () => {
  const ds = { 'AAA/USDT': { candles: series(120, (i) => 100 + Math.sin(i / 4) * 2) } };
  const none = run(ds, ['AAA/USDT'], churn);
  const cd = run(ds, ['AAA/USDT'], churn, { extras: { protections: { enabled: true, cooldown: { enabled: true, minutes: 600 }, stoplossGuard: { enabled: false }, maxDrawdown: { enabled: false } } } });
  assert.ok(none.trades > 30, `churn cok islem yapmali: ${none.trades}`);
  assert.ok(cd.trades < none.trades / 3, `cooldown islemleri azaltmali: ${cd.trades} vs ${none.trades}`);
  assert.ok(cd.extrasStats.blocked.cooldown > 0);
});

test('stoploss guard: ardisik stoplardan sonra yeni giris kilitlenir', () => {
  // Surekli dusen fiyat: her giris hemen stop-loss ile kapanir.
  const saw = (i) => 100 * Math.pow(0.985, i);
  const ds = { 'AAA/USDT': { candles: series(160, saw) } };
  const stopper = { ...holder, defaultParams: { stopLossPct: 1 } };
  const none = run(ds, ['AAA/USDT'], stopper, { params: { stopLossPct: 1 } });
  const guard = run(ds, ['AAA/USDT'], stopper, { params: { stopLossPct: 1 }, extras: { protections: { enabled: true, cooldown: { enabled: false }, stoplossGuard: { enabled: true, tradeLimit: 2, lookbackMinutes: 60 * 24, lockMinutes: 60 * 24 }, maxDrawdown: { enabled: false } } } });
  const stopsNone = none.tradeList.filter((t) => /stop/i.test(t.reason)).length;
  assert.ok(stopsNone >= 4, `testere stop uretmeli: ${stopsNone}`);
  assert.ok(guard.tradeList.filter((t) => /stop/i.test(t.reason)).length < stopsNone);
  assert.ok(guard.extrasStats.blocked.stoplossGuard > 0);
});

test('zaman bariyeri: tutan strateji, hedefe ulasmayan pozisyondan N mum sonra cikar', () => {
  const ds = { 'AAA/USDT': { candles: series(100, () => 100) } };
  const none = run(ds, ['AAA/USDT'], holder);
  const tb = run(ds, ['AAA/USDT'], holder, { extras: { timeBarrier: { enabled: true, maxHoldBars: 10, minProfitPct: 1 } } });
  assert.equal(none.tradeList.filter((t) => !t.forced).length, 0);
  assert.ok(tb.tradeList.filter((t) => /zaman bariyeri/.test(t.reason)).length >= 3);
  assert.ok(tb.extrasStats.timeBarrierExits >= 3);
});

test('forager: tek slotta yuksek hacimli parite alim hakkini alir', () => {
  const flatS = series(60, () => 100);
  const ds = {
    'AAA/USDT': { candles: flatS.map((c) => ({ ...c, v: 1 })) },
    'BBB/USDT': { candles: flatS.map((c) => ({ ...c, v: 1000 })) }
  };
  const syms = ['AAA/USDT', 'BBB/USDT'];
  const off = run(ds, syms, holder);
  const on = run(ds, syms, holder, { extras: { forager: { enabled: true, weights: { volume: 1, volatility: 0, unilateralness: 0 } } } });
  assert.equal(off.tradeList[0].symbol, 'AAA/USDT'); // varsayilan: alfabetik/girdi sirasi
  assert.equal(on.tradeList[0].symbol, 'BBB/USDT');
});

test('forager budama: dusuk hacimli aday yeni alimdan elenir', () => {
  const flatS = series(60, () => 100);
  const ds = { 'AAA/USDT': { candles: flatS.map((c) => ({ ...c, v: 1 })) }, 'BBB/USDT': { candles: flatS.map((c) => ({ ...c, v: 1000 })) } };
  const r = run(ds, ['AAA/USDT', 'BBB/USDT'], holder, { maxConcurrentPositions: 2, extras: { forager: { enabled: true, volumeDropPct: 50 } } });
  assert.ok(r.tradeList.every((t) => t.symbol === 'BBB/USDT'));
  assert.ok(r.extrasStats.blocked.forager > 0);
});

test('parseExtras: hazir ayar, JSON, hatali girdi', () => {
  assert.equal(parseExtras('koruma').protections.enabled, true);
  assert.equal(parseExtras('{"timeBarrier":{"enabled":true}}').timeBarrier.enabled, true);
  assert.equal(parseExtras(undefined), null);
  assert.throws(() => parseExtras('{bozuk'), /JSON/);
  assert.throws(() => parseExtras('{"yok":1}'), /bilinmeyen anahtar/);
  assert.throws(() => parseExtras('[1]'), /nesne/);
  assert.throws(() => parseExtras('@/yok/yok.json'), /okunamad/);
  parseExtras('tam'); // sozdizimi
  assert.ok(PRESETS.tam.forager.enabled);
});
