'use strict';
// 2.3.41: Binance iptal raporunda `c` iptal isteğinin yeni kimliği, `C` özgün emir kimliğidir. Kendi stop iptalimiz
// "tanınmayan emir" sayılıp canlı işlem kapısını kapatmamalı.
const test = require('node:test');
const assert = require('node:assert/strict');
const { OrderManager } = require('../src/orderManager');

function setup() {
  const state = { liveOrders: { 'stop-abc': { clientOrderId: 'stop-abc', symbol: 'HOT/USDT', side: 'sell', type: 'STOP_LOSS', status: 'NEW', exchangeOrderId: 49020, executedQty: 0, quoteQty: 0, amount: 100 } } };
  const exchange = { id: 't', name: 'T', capabilities: { clientOrderId: true, orderQuery: true, liveTradingVerified: true }, async getOrder() { return {}; } };
  return { om: new OrderManager({ exchange, state, store: { save() {} } }), state };
}
const cancelEvent = (extra = {}) => ({ e: 'executionReport', c: 'mgSEh5EZ4IoS43ITRM7gLf', C: 'stop-abc', i: 49020, s: 'HOTUSDT', S: 'SELL', X: 'CANCELED', x: 'CANCELED', z: '0', Z: '0', q: '100', I: 'e9', ...extra });

test('iptal raporu: özgün kimlik (C) yerelde varsa emir tanınır, tanınmayan emir uyarısı ve kilit oluşmaz', () => {
  const { om, state } = setup();
  const r = om.applyExecutionReport(cancelEvent());
  assert.notEqual(r.reason, 'unknown_local_order');
  assert.equal(state.liveStreamWarning, undefined);
  assert.equal(state.liveReconciliation?.safeToTrade, undefined);
  assert.equal(state.liveOrders['stop-abc'].status, 'CANCELED');
});

test('iptal raporu: ne c ne C yerelde yoksa hâlâ tanınmayan emir olarak işaretlenir ve kapı kapanır', () => {
  const { om, state } = setup();
  const r = om.applyExecutionReport(cancelEvent({ C: 'baska-bir-emir' }));
  assert.equal(r.handled, false); assert.equal(r.reason, 'unknown_local_order');
  assert.equal(state.liveStreamWarning.type, 'UNKNOWN_ORDER_EVENT');
  assert.equal(state.liveReconciliation.safeToTrade, false);
});

test('dolum raporu: C boşken davranış değişmez (c ile aranır)', () => {
  const { om } = setup();
  const r = om.applyExecutionReport({ e: 'executionReport', c: 'stop-abc', C: '', i: 49020, s: 'HOTUSDT', S: 'SELL', X: 'FILLED', x: 'TRADE', z: '100', Z: '50', q: '100', I: 'e10', t: 7, l: '100' });
  assert.notEqual(r.reason, 'unknown_local_order');
});
