'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { redact } = require('../src/util/runtimeLogger');
const { tightenSecretFile } = require('../src/util/secretFilePerms');
const { createTelegramCommands } = require('../src/telegramCommands');

function makeBot() {
  const requests = [];
  const fetchFn = async (url, opts) => { requests.push({ url, body: JSON.parse(opts.body) }); return { ok: true, json: async () => ({ ok: true, result: [] }) }; };
  const status = { mode: 'paper', running: false, killSwitch: false, exchange: 'binance', quoteAsset: 'USDT', cash: 100, positions: 0 };
  let started = 0;
  const bot = createTelegramCommands({
    env: { TELEGRAM_BOT_TOKEN: '123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ0123', TELEGRAM_CHAT_ID: '42' },
    fetchFn, logger: { log() {}, warn() {} }, getStatus: () => status,
    startBot: async () => { started++; status.running = true; }, stopBot: async () => { status.running = false; }
  });
  return { bot, requests, started: () => started };
}

test('Telegram: grup/supergrup/kanal sohbetinden gelen komut chat.id eslesse bile reddedilir', async () => {
  for (const type of ['group', 'supergroup', 'channel']) {
    const { bot, requests, started } = makeBot();
    assert.equal(await bot.processUpdate({ message: { chat: { id: 42, type }, from: { id: 999 }, text: '/basla' } }), false, type);
    assert.equal(requests.length, 0);
    assert.equal(started(), 0);
  }
});

test('Telegram: ozel sohbette gonderen sahip degilse reddedilir, sahipse calisir', async () => {
  const a = makeBot();
  assert.equal(await a.bot.processUpdate({ message: { chat: { id: 42, type: 'private' }, from: { id: 7 }, text: '/status' } }), false);
  assert.equal(a.requests.length, 0);
  const b = makeBot();
  assert.equal(await b.bot.processUpdate({ message: { chat: { id: 42, type: 'private' }, from: { id: 42 }, text: '/status' } }), true);
  assert.equal(b.requests.length, 1);
});

test('Telegram: tur/gonderen alani olmayan eski bicimli guncelleme chat.id eslesmesiyle calismaya devam eder', async () => {
  const { bot } = makeBot();
  assert.equal(await bot.processUpdate({ message: { chat: { id: 42 }, text: '/status' } }), true);
});

test('log temizleme: Telegram URL tokeni, imza, JSON anahtarlari, Bearer ve X-MBX-APIKEY gizlenir', () => {
  const tok = 'bot1234567890:AAH_abcdefghijklmnopqrstuvwxyz012345';
  assert.ok(!redact(`https://api.telegram.org/${tok}/sendMessage`).includes('AAH_abcdef'));
  const sig = '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef';
  assert.ok(!redact(`/api/v3/order?symbol=BTCUSDT&signature=${sig}`).includes(sig));
  const json = redact(JSON.stringify({ apiKey: 'AbCdEfGhIjKlMnOp', apiSecret: 'SeCrEtSeCrEtSeCrEt', passphrase: 'hunter2hunter2' }));
  for (const leaked of ['AbCdEfGhIjKlMnOp', 'SeCrEtSeCrEtSeCrEt', 'hunter2hunter2']) assert.ok(!json.includes(leaked), leaked);
  assert.ok(!redact({ headers: { 'X-MBX-APIKEY': 'AbCdEfGhIjKlMnOpQrSt' } }).includes('AbCdEfGhIjKlMnOpQrSt'));
  assert.ok(!redact('Authorization: Bearer abcdefghijklmnop12345').includes('abcdefghijklmnop12345'));
  assert.ok(!redact('listenKey=pqt79tm4rNlAvJa0Gm2mFpHMqLGXwdz1y1Bz9R7WtDQdRbMA').includes('pqt79tm4'));
});

test('log temizleme: siradan log satirlari bozulmaz', () => {
  const line = 'ALIM BTC/USDT @ 100.500000 | miktar: 0.1 BTC | komisyon: 0.01 USDT';
  assert.equal(redact(line), line);
});

test('.env izinleri: grup/diger okuyabiliyorsa 600 yapilir, zaten 600 ise dokunulmaz, dosya yoksa sessiz gecer', { skip: process.platform === 'win32' }, () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'perm-'));
  const f = path.join(dir, '.env');
  fs.writeFileSync(f, 'X=1\n', { mode: 0o644 });
  fs.chmodSync(f, 0o644);
  const r1 = tightenSecretFile(f);
  assert.equal(r1.tightened, true);
  assert.equal(fs.statSync(f).mode & 0o777, 0o600);
  const r2 = tightenSecretFile(f);
  assert.equal(r2.tightened, false);
  assert.deepEqual(tightenSecretFile(path.join(dir, 'yok.env')), { checked: false, tightened: false, mode: null, error: null });
  fs.rmSync(dir, { recursive: true, force: true });
});
