// server.js express/ws olmadan yuklenemez; bu test ayar yamasi dogrulamasinin EXTRAS BAGLANTISINI yalitik dener.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { validateExtrasPatch, normalizeExtras, KEYS } = require('../src/entryExtras');

const src = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
const grab = (startRe) => {
  const m = startRe.exec(src);
  assert.ok(m, `server.js icinde bulunamadi: ${startRe}`);
  let depth = 0, i = src.indexOf('{', m.index);
  for (let j = i; j < src.length; j++) {
    if (src[j] === '{') depth++;
    else if (src[j] === '}') { depth--; if (depth === 0) return src.slice(m.index, j + 1); }
  }
  throw new Error('govde bitmedi');
};

function loadValidator(currentSettings) {
  const fnText = grab(/function validateSettingsPatch\(/);
  const ctx = {
    state: { settings: currentSettings },
    SETTING_RULES: {},
    exchangeRegistry: { binance: {} },
    validatePortfolioPolicyPatch: () => ({}),
    validateExtrasPatch
  };
  vm.createContext(ctx);
  vm.runInContext(fnText, ctx);
  return ctx.validateSettingsPatch;
}

test('sunucu ayar yamasi extras anahtarlarini dogrular ve temiz yamaya katar', () => {
  const cur = normalizeExtras({ mode: 'paper', exchange: 'binance' });
  cur.mode = 'paper'; cur.exchange = 'binance';
  const v = loadValidator(cur);
  const ok = v({ protections: { enabled: true, cooldown: { minutes: 30 } }, timeBarrier: { enabled: true }, volatilitySizing: { enabled: true } });
  assert.equal(ok.error, undefined);
  assert.equal(ok.clean.protections.enabled, true);
  assert.equal(ok.clean.protections.cooldown.minutes, 30);
  assert.equal(ok.clean.protections.cooldown.enabled, true); // mevcut alan korunur
  assert.equal(ok.clean.timeBarrier.enabled, true);
  assert.equal(ok.clean.volatilitySizing.enabled, true);
  assert.match(v({ forager: { enabled: 'evet' } }).error, /forager\.enabled/);
  assert.match(v({ pairFilters: [] }).error, /nesne/);
  assert.deepEqual(Object.keys(v({}).clean), []);
});

test('server.js: extras anahtarlari canli-risk listesinde ve kayit sonrasi normalize ediliyor', () => {
  const m = /const LIVE_RISK_KEYS = \[([^\]]*)\]/.exec(src);
  assert.ok(m, 'LIVE_RISK_KEYS bulunamadi');
  for (const k of KEYS) assert.ok(m[1].includes(`'${k}'`), `${k} LIVE_RISK_KEYS icinde degil (canli modda yeniden dogrulama istemeli)`);
  assert.ok(/normalizeExtras\(state\.settings\)/.test(src), 'kayit sonrasi normalizeExtras cagrisi yok');
});
