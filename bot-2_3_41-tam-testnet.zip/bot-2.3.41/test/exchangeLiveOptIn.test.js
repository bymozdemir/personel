const test = require('node:test');
const assert = require('node:assert/strict');
const store = require('../src/store');
const LiveEngine = require('../src/liveEngine');
const { createExchange } = require('../src/exchanges');

const IDS = { coinbaseexchange: 'ALLOW_COINBASEEXCHANGE_TRADING', kraken: 'ALLOW_KRAKEN_TRADING', bitstamp: 'ALLOW_BITSTAMP_TRADING', okx: 'ALLOW_OKX_TRADING', okxtr: 'ALLOW_OKXTR_TRADING', bybittr: 'ALLOW_BYBITTR_TRADING', btcturk: 'ALLOW_BTCTURK_TRADING', binancetr: 'ALLOW_BINANCE_TR_TRADING' };

function withEnv(vars, fn) {
  const old = {};
  for (const k of Object.keys(vars)) { old[k] = process.env[k]; if (vars[k] === undefined) delete process.env[k]; else process.env[k] = vars[k]; }
  try { return fn(); } finally { for (const k of Object.keys(old)) { if (old[k] === undefined) delete process.env[k]; else process.env[k] = old[k]; } }
}
function engineFor(id) {
  const state = store.defaultState();
  state.settings.mode = 'live';
  Object.assign(state.settings, { maxTradeQuote: 20, killSwitchLossPct: 10, dailyLossLimitPct: 3 });
  return new LiveEngine({ exchange: createExchange(id, {}), state, store: { save() {} }, allowLive: true });
}

for (const [id, envName] of Object.entries(IDS)) {
  test(`${id}: ${envName} tek başına doğrulama kanıtı değildir; canlı başlangıç kilitli kalır`, () => {
    withEnv({ [envName]: undefined, BINANCE_ALLOW_LOCAL_BASE_URL: undefined }, () => {
      const ex = createExchange(id, {});
      assert.equal(ex.capabilities.liveTradingVerified, false);
      assert.throws(() => engineFor(id).assertStartAllowed());
    });
    withEnv({ [envName]: 'true', BINANCE_ALLOW_LOCAL_BASE_URL: undefined }, () => {
      const ex = createExchange(id, {});
      assert.equal(ex.capabilities.liveTradingVerified, false);
      assert.throws(() => engineFor(id).assertStartAllowed(), /liveTradingVerified=false|gerekli API yeteneklerini desteklemiyor/);
    });
  });
}

test('Paribu ve Midas env bayrağı olsa bile kilitli kalır (adaptör tamamlanmadı)', () => {
  withEnv({ ALLOW_PARIBU_TRADING: 'true' }, () => {
    assert.equal(createExchange('paribu', {}).capabilities.liveTradingVerified, false);
    assert.throws(() => engineFor('paribu').assertStartAllowed());
  });
  assert.equal(createExchange('midas', {}).capabilities.liveTradingVerified, false);
  assert.throws(() => engineFor('midas').assertStartAllowed());
});
