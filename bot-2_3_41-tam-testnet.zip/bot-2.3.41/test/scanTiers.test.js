'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const scanner = require('../src/autonomousScanner');

function fakeExchange(count) {
  const fetched = new Set();
  const tickers = Array.from({ length: count }, (_, i) => ({ symbol: `C${String(i).padStart(3, '0')}/USDT`, lastPrice: 1, quoteVolume: 1_000_000 - i * 1000, changePct: 0 }));
  return {
    fetched, quoteAssets: ['USDT'],
    async fetchAllTickers24h() { return tickers; },
    async fetchCandles(symbol) { fetched.add(symbol); throw new Error('test: mum yok'); }
  };
}

test('çekirdek+kuyruk: ilk N coin her turda, kuyruk dilimler halinde dönüşümlü taranır ve tüm evren sırayla görülür', async () => {
  const ex = fakeExchange(100);
  const seen = new Set(); const sizes = [];
  for (let cycle = 0; cycle < 4; cycle++) {
    ex.fetched.clear();
    const r = await scanner.scanBuyCandidates({ exchange: ex, candidateLimit: 'all', coreLimit: 20, tailSlices: 4, strategyIds: ['rsi_simple'], timeframes: ['1h'] });
    sizes.push(r.scanned);
    assert.equal(r.scanMode, 'core+tail'); assert.equal(r.universeSize, 100); assert.equal(r.tiered.core, 20); assert.equal(r.tiered.slices, 4);
    for (let i = 0; i < 20; i++) assert.ok(ex.fetched.has(`C${String(i).padStart(3, '0')}/USDT`), 'çekirdek her turda taranır');
    for (const s of ex.fetched) seen.add(s);
  }
  assert.deepEqual(sizes, [40, 40, 40, 40]); // 20 çekirdek + 80/4 kuyruk
  assert.equal(seen.size, 100, '4 turda tüm evren görülür');
});

test('çekirdek+kuyruk: coreLimit=0 veya çekirdek evrenden büyükse eski tam tarama korunur', async () => {
  const ex = fakeExchange(30);
  const full = await scanner.scanBuyCandidates({ exchange: ex, candidateLimit: 'all', coreLimit: 0, strategyIds: ['rsi_simple'], timeframes: ['1h'] });
  assert.equal(full.scanned, 30); assert.equal(full.scanMode, 'all'); assert.equal(full.tiered, null);
  const big = await scanner.scanBuyCandidates({ exchange: ex, candidateLimit: 'all', coreLimit: 500, strategyIds: ['rsi_simple'], timeframes: ['1h'] });
  assert.equal(big.scanned, 30); assert.equal(big.scanMode, 'all');
});
