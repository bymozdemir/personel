'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { selectAffordableCandidates, quoteBalanceFromLive } = require('../src/autonomousCapitalAllocator');

function exchange(mins = {}) { return { async fetchSymbolRules(symbol) { return { minNotional: mins[symbol] ?? 5 }; } }; }
const candidates = (n) => Array.from({length:n}, (_, i) => ({ symbol:`C${i}/USDT`, score:n-i }));

test('selected count is a ceiling; $5 cash does not split into 32 sub-minimum orders', async () => {
  const r = await selectAffordableCandidates({ candidates:candidates(32), maxCount:32, mode:'paper', quoteAsset:'USDT', paperCash:5,
    reserveCashPct:10, exchange:exchange(), feePct:0.1, slippagePct:0.05 });
  assert.equal(r.selected.length, 0, '4.5 spendable after reserve cannot meet 5 USDT min plus costs');
});

test('selects only as many top-ranked candidates as cash can fund', async () => {
  const r = await selectAffordableCandidates({ candidates:candidates(32), maxCount:32, mode:'paper', quoteAsset:'USDT', paperCash:30,
    reserveCashPct:10, exchange:exchange(), feePct:0.1, slippagePct:0.05 });
  assert.equal(r.selected.length, 5, '27 spendable can reserve minimums for five candidates');
  assert.deepEqual(r.selected.map(x=>x.symbol), ['C0/USDT','C1/USDT','C2/USDT','C3/USDT','C4/USDT']);
});

test('does not allocate candidates when live balance is unknown', async () => {
  const r = await selectAffordableCandidates({ candidates:candidates(3), maxCount:3, mode:'live', quoteAsset:'USDT', liveLastBalance:null, exchange:exchange() });
  assert.equal(r.selected.length, 0);
  assert.match(r.reason, /doğrulanamadı/);
});

test('live quote balance parser uses free balance only for Binance asset maps', () => {
  assert.equal(quoteBalanceFromLive({USDT:{free:'25',locked:'100'}}, 'USDT'), 25);
  assert.equal(quoteBalanceFromLive({BTC:{free:'1',locked:'0'}}, 'USDT'), 0);
});

test('live quote balance parser keeps array compatibility and uses free only', () => {
  assert.equal(quoteBalanceFromLive([{asset:'USDT', free:'5', locked:'100'}], 'USDT'), 5);
  assert.equal(quoteBalanceFromLive([], 'USDT'), 0);
  assert.equal(quoteBalanceFromLive(null, 'USDT'), null);
});

test('live allocator can fund candidates from Binance asset-keyed USDT balance', async () => {
  const r = await selectAffordableCandidates({ candidates:candidates(3), maxCount:3, mode:'live', quoteAsset:'USDT',
    liveLastBalance:{USDT:{free:'30',locked:'100'}}, reserveCashPct:10, exchange:exchange() });
  assert.equal(r.availableQuote, 30);
  assert.equal(r.spendableQuote, 27);
  assert.equal(r.selected.length, 3);
});


test('reports candidates blocked specifically by spendable cash so autonomous rotation can free funds', async () => {
  const r = await selectAffordableCandidates({ candidates:candidates(3), maxCount:3, mode:'live', quoteAsset:'USDT',
    liveLastBalance:{USDT:{free:'0',locked:'500'}}, reserveCashPct:10, exchange:exchange() });
  assert.equal(r.selected.length, 0);
  assert.equal(r.cashBlockedCandidates, 3);
  assert.equal(r.availableQuote, 0);
});

test('does not classify candidates as cash-blocked when order cap makes the minimum impossible', async () => {
  const r = await selectAffordableCandidates({ candidates:candidates(2), maxCount:2, mode:'live', quoteAsset:'USDT',
    liveLastBalance:{USDT:{free:'500',locked:'0'}}, maxTradeQuote:4, exchange:exchange() });
  assert.equal(r.selected.length, 0);
  assert.equal(r.cashBlockedCandidates, 0);
});


test('validates live balance even when all tracking slots are occupied', async () => {
  const unknown = await selectAffordableCandidates({ candidates:candidates(2), maxCount:0, mode:'live', quoteAsset:'USDT', liveLastBalance:null });
  const known = await selectAffordableCandidates({ candidates:candidates(2), maxCount:0, mode:'live', quoteAsset:'USDT', liveLastBalance:{USDT:{free:'0',locked:'500'}} });
  assert.equal(unknown.availableQuote, null);
  assert.equal(known.availableQuote, 0);
});
