const test = require('node:test');
const assert = require('node:assert/strict');
const PaperEngine = require('../src/paperEngine');
const LiveEngine = require('../src/liveEngine');
const Binance = require('../src/exchanges/binance');
const store = require('../src/store');

test('paper motor stop(): WS mum akışı kapatılır (yetim bağlantı kalmaz)', async () => {
  let closed = 0;
  const state = store.defaultState(); state.paper = store.defaultPaper(1000);
  const engine = new PaperEngine({ exchange: { quoteAssets: ['USDT'], closeMarketFeed() { closed++; } }, store: { save() {} }, state, nowFn: () => Date.now() });
  engine.log = () => {};
  state.running = true;
  await engine.stop('test', false);
  assert.equal(closed, 1);
});

test('paper motor stop(): kapatma hatası durdurmayı engellemez', async () => {
  const state = store.defaultState(); state.paper = store.defaultPaper(1000);
  const engine = new PaperEngine({ exchange: { quoteAssets: ['USDT'], closeMarketFeed() { throw new Error('x'); } }, store: { save() {} }, state, nowFn: () => Date.now() });
  engine.log = () => {};
  state.running = true;
  await engine.stop('test', false);
  assert.equal(state.running, false);
});

test('canlı motor stop(): WS mum akışı kapatılır', async () => {
  let closed = 0;
  const state = store.defaultState(); state.settings.mode = 'live';
  const engine = new LiveEngine({ exchange: { id: 'binance', quoteAssets: ['USDT'], capabilities: {}, closeMarketFeed() { closed++; } }, state, store: { save() {} }, allowLive: true, nowFn: () => Date.now() });
  engine.log = () => {};
  state.running = true;
  await engine.stop('test', false);
  assert.equal(closed, 1);
});

test('Binance adaptörü: closeMarketFeed iki kez çağrılabilir ve akış yeniden tembel kurulabilir', () => {
  const b = new Binance({ marketDataWs: true });
  const f1 = b._getCandleFeed();
  assert.ok(f1);
  b.closeMarketFeed(); b.closeMarketFeed();
  assert.equal(b.candleFeed, null);
  const f2 = b._getCandleFeed();
  assert.ok(f2 && f2 !== f1);
  b.closeMarketFeed();
});

test('paper motor: seyreltilmiş özkaynak serisi 5 dk aralıkla yazılır (equityDrawdown penceresi için)', () => {
  const src = require('fs').readFileSync(require('path').join(__dirname, '..', 'src', 'paperEngine.js'), 'utf8');
  assert.match(src, /equityHistory: this\.state\.paper\.equitySamples/);
  assert.match(src, />= 300000/);
});
