'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizeUsdtPrices, updateExternalInventoryReferences } = require('../src/reconciliation');

test('first observed valid market price is persisted as reference and not reset', () => {
  const state = { live: {} };
  const balances = { ETH: { total: 0.5 }, USDT: { total: 100 } };
  const prices = normalizeUsdtPrices([{ symbol: 'ETH/USDT', lastPrice: '3000' }]);
  updateExternalInventoryReferences(state, balances, prices, '2026-10-26T00:00:00.000Z');
  const row = state.live.externalInventoryByAsset.ETH;
  assert.equal(row.referencePrice, 3000);
  assert.equal(row.referenceQuantity, 0.5);
  assert.equal(row.referenceValueUSDT, 1500);
  assert.equal(row.provenance, 'exchange-discovered');
  updateExternalInventoryReferences(state, { ETH: { total: 0.7 } }, { ETH: 3150 }, '2026-10-27T00:00:00.000Z');
  assert.equal(row.referencePrice, 3000);
  assert.equal(row.referenceQuantity, 0.5);
  assert.equal(row.currentQuantity, 0.7);
  assert.equal(row.currentPrice, 3150);
});

test('missing initial price does not guess and initializes on first valid quote', () => {
  const state = { live: {} };
  updateExternalInventoryReferences(state, { XYZ: { total: 2 } }, {}, 't1');
  const row = state.live.externalInventoryByAsset.XYZ;
  assert.equal(row.initialized, false);
  assert.equal(row.referencePrice, null);
  updateExternalInventoryReferences(state, { XYZ: { total: 2.5 } }, { XYZ: 4 }, 't2');
  assert.equal(row.initialized, true);
  assert.equal(row.referencePrice, 4);
  assert.equal(row.referenceQuantity, 2.5);
  assert.equal(row.referenceValueUSDT, 10);
});

test('USDT price normalizer ignores invalid and non-USDT tickers', () => {
  assert.deepEqual(normalizeUsdtPrices([
    { symbol: 'ETH/USDT', lastPrice: 3 },
    { symbol: 'BTC/TRY', lastPrice: 5 },
    { symbol: 'BAD/USDT', lastPrice: 0 }
  ]), { ETH: 3 });
});
