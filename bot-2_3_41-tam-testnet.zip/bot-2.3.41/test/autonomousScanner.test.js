'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizeRequest, scanBuyCandidates, scanManagementConfigs, ALLOWED_COUNTS, evaluateHistorical, paperConfidence } = require('../src/autonomousScanner');
const { timeframeMs } = require('../src/execution');

test('autonomous request only accepts the six advertised coin counts', () => {
  for (const count of ALLOWED_COUNTS) assert.equal(normalizeRequest({ count }).count, count);
  for (const count of [0, 3, 5, 33, 'all', null]) assert.throws(() => normalizeRequest({ count }), /Coin sayısı/);
  assert.deepEqual(normalizeRequest({ count: 4, strategyId: 'ema_cross', timeframe: '1h' }), { count: 4 });
  assert.deepEqual(normalizeRequest({ count: 2, strategyId: 'not-a-real-strategy', timeframe: 'bad' }), { count: 2 });
});

test('autonomous scanner filters quote asset, stable-base and leveraged tokens', async () => {
  const exchange = {
    quoteAssets: ['USDT'],
    async fetchAllTickers24h() {
      return [
        { symbol: 'BTC/USDT', lastPrice: 100, quoteVolume: 1_000_000, changePct: 2 },
        { symbol: 'USDC/USDT', lastPrice: 1, quoteVolume: 2_000_000, changePct: 0 },
        { symbol: 'BTC/TRY', lastPrice: 3000, quoteVolume: 3_000_000, changePct: 1 },
        { symbol: 'BTCUP/USDT', lastPrice: 2, quoteVolume: 4_000_000, changePct: 3 }
      ];
    },
    async fetchCandles() { throw new Error('should not fetch because test candidate lacks enough data'); }
  };
  const result = await scanBuyCandidates({ exchange, strategyId: 'ema_cross', timeframe: '1h', quoteAsset: 'USDT', now: 1_000_000_000_000 });
  assert.equal(result.scanned, 1);
  assert.equal(result.results[0].symbol, 'BTC/USDT');
  assert.equal(result.eligible.length, 0);
});

test('autonomous scanner records per-symbol candle failures without aborting the scan', async () => {
  const exchange = {
    quoteAssets: ['USDT'],
    async fetchAllTickers24h() { return [{ symbol: 'BTC/USDT', lastPrice: 100, quoteVolume: 1_000_000, changePct: 0 }]; },
    async fetchCandles() { throw new Error('temporary market-data failure'); }
  };
  const result = await scanBuyCandidates({ exchange, strategyId: 'ema_cross', timeframe: '1h', quoteAsset: 'USDT' });
  assert.equal(result.scanned, 1);
  assert.equal(result.results[0].action, 'error');
  assert.match(result.results[0].reason, /temporary market-data failure/);
  assert.equal(result.eligible.length, 0);
});


test('scanner respects mode/timeframe policy and does not request 5m candles in live mode', async () => {
  const requested = [];
  const exchange = {
    quoteAssets: ['USDT'],
    async fetchAllTickers24h() { return [{ symbol: 'BTC/USDT', lastPrice: 100, quoteVolume: 1000000 }]; },
    async fetchCandles(symbol, timeframe) { requested.push(timeframe); throw new Error('offline fixture'); }
  };
  const result = await scanBuyCandidates({ exchange, quoteAsset: 'USDT', mode: 'live', exchangeId: 'binance', pollSeconds: 60 });
  assert.deepEqual([...new Set(requested)].sort(), ['15m', '1h', '30m', '4h'].sort());
  assert.deepEqual(result.timeframesTested.sort(), ['15m', '30m', '1h', '4h'].sort());
});

test('candidateLimit=all evaluates every eligible ticker instead of silently capping at 48', async () => {
  const tickers = Array.from({ length: 55 }, (_, i) => ({
    symbol: `COIN${String(i).padStart(2, '0')}/USDT`,
    lastPrice: 1,
    quoteVolume: 1_000_000 - i
  }));
  const exchange = {
    quoteAssets: ['USDT'],
    async fetchAllTickers24h() { return tickers; },
    async fetchCandles() { throw new Error('fixture: no candle data'); }
  };
  const result = await scanBuyCandidates({
    exchange, quoteAsset: 'USDT', candidateLimit: 'all', mode: 'live',
    exchangeId: 'binance', pollSeconds: 60
  });
  assert.equal(result.scanned, 55);
  assert.equal(result.universeSize, 55);
  assert.equal(result.universeSymbols.length, 55);
  assert.equal(result.actionCounts.error, 55);
});

test('automatic scan rotates through the full eligible universe in bounded batches', async () => {
  const tickers = Array.from({ length: 55 }, (_, i) => ({
    symbol: `COIN${String(i).padStart(2, '0')}/USDC`, lastPrice: 1, quoteVolume: 1_000_000 - i
  }));
  const exchange = {
    quoteAssets: ['USDC'],
    async fetchAllTickers24h() { return tickers; },
    async fetchCandles() { throw new Error('fixture: no candle data'); }
  };
  const seen = new Set();
  const cycles = [];
  for (let i = 0; i < 3; i++) {
    const result = await scanBuyCandidates({ exchange, quoteAsset: 'USDC', candidateLimit: 'auto', scanBatchSize: 20,
      mode: 'live', exchangeId: 'binance', pollSeconds: 60 });
    cycles.push(result);
    for (const row of result.results) seen.add(row.symbol);
  }
  assert.deepEqual(cycles.map((r) => r.scanned), [20, 20, 20]);
  assert.ok(cycles.every((r) => r.universeSize === 55 && r.scanMode === 'round_robin'));
  assert.equal(seen.size, 55, '3 cycles should cover all eligible symbols without per-coin configuration');
});

test('paper confidence is low at cold start but never disables a strategy', () => {
  const cold = paperConfidence('ema_cross', '1h', {});
  assert.equal(cold.level, 'low');
  assert.equal(cold.trades, 0);
  assert.match(cold.reason, /strateji kapatılmaz/);
  const few = paperConfidence('ema_cross', '1h', { 'ema_cross/1h': { trades: 3, netPnl: 4 } });
  assert.equal(few.level, 'low');
  const reviewed = paperConfidence('ema_cross', '1h', { 'ema_cross/1h': { trades: 4, netPnl: 2 } });
  assert.equal(reviewed.level, 'medium');
  const negative = paperConfidence('ema_cross', '1h', { 'ema_cross/1h': { trades: 4, netPnl: -1 } });
  assert.equal(negative.level, 'low');
});

test('historical gate rejects strategies without enough trades or positive net performance', () => {
  const strategy = require('../src/strategies').get('ema_cross');
  const candles = Array.from({ length: 1000 }, (_, i) => ({ t: i * 3600000, o: 100, h: 101, l: 99, c: 100, v: 1000 }));
  const tooFew = evaluateHistorical({ candles, strategy, params: strategy.defaultParams, backtestRunner: () => ({ trades: 1, returnPct: 4, maxDrawdownPct: -2, profitFactor: 2, secondHalfPct: 2 }) });
  assert.equal(tooFew.eligible, false);
  const losing = evaluateHistorical({ candles, strategy, params: strategy.defaultParams, backtestRunner: () => ({ trades: 4, returnPct: -1, maxDrawdownPct: -2, profitFactor: 1.2, secondHalfPct: 1 }) });
  assert.equal(losing.eligible, false);
  const accepted = evaluateHistorical({ candles, strategy, params: strategy.defaultParams, backtestRunner: () => ({ trades: 4, returnPct: 5, maxDrawdownPct: -3, profitFactor: 1.5, secondHalfPct: 2, winRatePct: 60 }) });
  assert.equal(accepted.eligible, true);
  assert.ok(accepted.metrics.walkForward.testedWindows >= 1);
  assert.ok(accepted.metrics.walkForward.consistencyPct >= 0);
});

test('walk-forward consistency adjustment rewards robustness even when base score is negative', () => {
  const strategy = require('../src/strategies').get('ema_cross');
  const candles = Array.from({ length: 1000 }, (_, i) => ({ t: i * 3600000, o: 100, h: 101, l: 99, c: 100, v: 1000 }));
  const run = (robust) => evaluateHistorical({
    candles, strategy, params: strategy.defaultParams,
    backtestRunner: ({ startIndex }) => ({
      trades: 4,
      returnPct: startIndex === 600 ? 1 : (robust ? 1 : -1),
      maxDrawdownPct: -20,
      profitFactor: 1.05,
      secondHalfPct: 0,
      winRatePct: 0
    })
  });
  const robust = run(true);
  const inconsistent = run(false);
  assert.equal(robust.eligible, true);
  assert.equal(inconsistent.eligible, true);
  assert.ok(robust.score > inconsistent.score, `expected robust score ${robust.score} > inconsistent score ${inconsistent.score}`);
});

test('autonomous scanner ranks current buy signals only after historical validation and returns serializable rows', async () => {
  const strategies = require('../src/strategies');
  const strategy = strategies.get('ema_cross');
  const originalEvaluate = strategy.evaluate;
  strategy.evaluate = ({ candles }) => ({ action: 'buy', reason: 'test buy signal', price: candles.at(-1).c });
  const now = Date.now();
  const exchange = {
    quoteAssets: ['USDT'],
    async fetchAllTickers24h() { return [
      { symbol: 'BTC/USDT', lastPrice: 100, quoteVolume: 1_000_000, changePct: 1 },
      { symbol: 'ETH/USDT', lastPrice: 100, quoteVolume: 2_000_000, changePct: 2 }
    ]; },
    async fetchCandles(symbol, timeframe) {
      const step = timeframeMs(timeframe);
      const end = Math.floor(now / step) * step - step;
      return Array.from({ length: 1000 }, (_, i) => ({
        t: end - (999 - i) * step, o: 100, h: 101, l: 99, c: 100, v: symbol.startsWith('ETH') ? 2000 : 100
      }));
    }
  };
  const backtestRunner = () => ({ trades: 4, returnPct: 5, maxDrawdownPct: -3, profitFactor: 1.5, secondHalfPct: 2, winRatePct: 60 });
  try {
    const result = await scanBuyCandidates({ exchange, quoteAsset: 'USDT', now, backtestRunner, mode: 'paper', pollSeconds: 60 });
    assert.equal(result.eligible.length, 2);
    assert.equal(result.eligible[0].action, 'buy');
    assert.ok(result.eligible[0].strategyId);
    assert.ok(['15m', '30m', '1h', '4h'].includes(result.eligible[0].timeframe));
    assert.equal(JSON.stringify(result).includes('rankingCandles'), false);
    assert.equal(result.autonomousSelection, true);
  } finally {
    strategy.evaluate = originalEvaluate;
  }
});

test('closed paper trade statistics are grouped only by exact strategy and timeframe', () => {
  const { buildPaperStrategyTradeStats } = require('../src/autonomousTradeStats');
  const stats = buildPaperStrategyTradeStats([
    { strategyId: 'ema_cross', timeframe: '1h', pnl: 2 },
    { strategyId: 'ema_cross', timeframe: '1h', pnl: -1 },
    { strategyId: 'ema_cross', timeframe: '4h', pnl: 9 },
    { strategyId: 'trendRegime', timeframe: '1h', pnl: 100 },
    { symbol: 'BTC/USDT', pnl: 500 }
  ]);
  assert.deepEqual(stats['ema_cross/1h'], { trades: 2, netPnl: 1, wins: 1 });
  assert.deepEqual(stats['ema_cross/4h'], { trades: 1, netPnl: 9, wins: 1 });
  assert.equal(stats['trendRegime/1h'].trades, 1);
  assert.equal(Object.keys(stats).length, 3);
});

test('scanBuyCandidates tarama sırasında ilerleme bildirir (veri eskimesi yanlış alarmı önleme)', async () => {
  const scanner = require('../src/autonomousScanner');
  const calls = [];
  const exchange = {
    quoteAssets: ['USDT'],
    async fetchAllTickers24h() { return [{ symbol: 'AAA/USDT', lastPrice: 1, quoteVolume: 10 }, { symbol: 'BBB/USDT', lastPrice: 1, quoteVolume: 9 }]; },
    async fetchCandles() { throw new Error('veri yok'); }
  };
  await scanner.scanBuyCandidates({ exchange, quoteAsset: 'USDT', candidateLimit: 'all', onProgress: (p) => calls.push(p) });
  const last = calls[calls.length - 1];
  require('node:assert').deepStrictEqual(last, { done: 2, total: 2 });
  require('node:assert').ok(calls.length >= 3);
});

test('otonom tarayıcı agresif stratejiyi ve 1m/3m/5m mumları hiçbir modda kullanmaz (hızlı kontrolde bile)', async () => {
  for (const mode of ['paper', 'live']) {
    const requested = [];
    const exchange = {
      quoteAssets: ['USDT'],
      async fetchAllTickers24h() { return [{ symbol: 'BTC/USDT', lastPrice: 100, quoteVolume: 1000000 }]; },
      async fetchCandles(symbol, timeframe) { requested.push(timeframe); throw new Error('offline fixture'); }
    };
    const result = await scanBuyCandidates({ exchange, quoteAsset: 'USDT', mode, exchangeId: 'binance', pollSeconds: 15 });
    assert.deepEqual([...new Set(requested)].sort(), ['15m', '1h', '30m', '4h'].sort(), mode);
    assert.deepEqual(result.timeframesTested.sort(), ['15m', '30m', '1h', '4h'].sort(), mode);
  }
});


test('mevcut pozisyon için yönetim profili, yeni BUY sinyali gerektirmeden coin bazında seçilir', async () => {
  const strategies = require('../src/strategies');
  const strategy = strategies.get('ema_cross');
  const originalEvaluate = strategy.evaluate;
  // Yönetim profili seçiminde evaluate() BUY döndürmek zorunda değildir.
  strategy.evaluate = () => ({ action: 'hold', reason: 'pozisyon yönetimi' });
  const now = Date.now();
  const exchange = {
    async fetchCandles(symbol, timeframe) {
      const step = timeframeMs(timeframe);
      const end = Math.floor(now / step) * step - step;
      return Array.from({ length: 1000 }, (_, i) => ({
        t: end - (999 - i) * step, o: 100, h: 101, l: 99, c: 100, v: 1000
      }));
    }
  };
  const backtestRunner = ({ startIndex }) => ({
    trades: 4, returnPct: startIndex === 600 ? 4 : 2, maxDrawdownPct: -3,
    profitFactor: 1.5, secondHalfPct: 1, winRatePct: 60
  });
  try {
    const rows = await scanManagementConfigs({ exchange, symbols: ['AAA/USDT'], strategyIds: ['ema_cross'],
      timeframes: ['1h'], now, mode: 'live', exchangeId: 'binance', backtestRunner });
    assert.equal(rows.length, 1);
    assert.equal(rows[0].symbol, 'AAA/USDT');
    assert.equal(rows[0].selected.strategyId, 'ema_cross');
    assert.equal(rows[0].selected.timeframe, '1h');
  } finally { strategy.evaluate = originalEvaluate; }
});

test('mevcut pozisyon yönetim taraması başarısızsa coin hata olarak değil yeniden denenebilir seçim yok olarak döner', async () => {
  const rows = await scanManagementConfigs({ exchange: { async fetchCandles() { throw new Error('offline'); } },
    symbols: ['AAA/USDT'], strategyIds: ['ema_cross'], timeframes: ['1h'], mode: 'live', exchangeId: 'binance' });
  assert.equal(rows.length, 1);
  assert.equal(rows[0].selected, null);
  assert.match(rows[0].reason, /offline/);
});


test('pozisyon yönetim taraması süre bütçesi dolunca profili seçmez', async () => {
  let clock = Date.now();
  const now = clock;
  const step = timeframeMs('1h');
  const exchange = { async fetchCandles() {
    clock += 2000;
    const end = Math.floor(now / step) * step - step;
    return Array.from({ length: 1000 }, (_, i) => ({ t: end - (999 - i) * step, o: 100, h: 101, l: 99, c: 100, v: 1000 }));
  } };
  const rows = await scanManagementConfigs({ exchange, symbols: ['AAA/USDT'], strategyIds: ['ema_cross'],
    timeframes: ['1h'], now, nowFn: () => clock, maxDurationMs: 1000 });
  assert.equal(rows[0].selected, null);
  assert.match(rows[0].reason, /süre bütçesi doldu/);
});

test('sıkı doğrulamadan geçen profil yoksa en iyi gevşek strateji/mum profili seçilir', async () => {
  const strategies = require('../src/strategies');
  const now = Date.now();
  const exchange = {
    async fetchCandles(symbol, timeframe) {
      const step = timeframeMs(timeframe);
      const end = Math.floor(now / step) * step - step;
      return Array.from({ length: 1000 }, (_, i) => ({ t: end - (999 - i) * step, o: 100, h: 101, l: 99, c: 100, v: 1000 }));
    }
  };
  // Getiri hep negatif (sıkı kapıdan geçmez); AAA için 4h, BBB için 1h daha iyi.
  const backtestRunner = ({ candles, strategy }) => {
    const tfMs = candles[1].t - candles[0].t;
    const good = strategy.id === 'supertrend';
    return { trades: 3, returnPct: good ? (tfMs === 4 * 3600000 ? -1 : -4) : -8, maxDrawdownPct: -6, profitFactor: 0.8, winRatePct: 33 };
  };
  const rows = await scanManagementConfigs({ exchange, symbols: ['AAA/USDT'], strategyIds: ['supertrend', 'ema_cross'],
    timeframes: ['1h', '4h'], now, mode: 'live', exchangeId: 'binance', backtestRunner });
  assert.equal(rows[0].selected.strategyId, 'supertrend');
  assert.equal(rows[0].selected.timeframe, '4h');
  assert.equal(rows[0].selected.relaxed, true);
  assert.equal(rows[0].relaxed, true);
  assert.ok(Number.isFinite(rows[0].selected.score));
  assert.ok(strategies.get('supertrend'));
});
