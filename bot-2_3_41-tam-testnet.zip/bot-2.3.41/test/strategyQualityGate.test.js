const test = require('node:test');
const assert = require('node:assert/strict');
const strategies = require('../src/strategies');

test('all 19 registered strategies apply the cost/volatility entry gate', () => {
  const list = strategies.list();
  assert.equal(list.length, 19);
  for (const item of list) {
    const s = strategies.get(item.id);
    assert.equal(s.__entryQualityGateApplied, true, `${item.id} gate missing`);
  }
});

test('entry quality gate suppresses BUY in near-flat market but never blocks SELL', () => {
  const s = strategies.get('trend_filter');
  const flat = Array.from({ length: 30 }, (_, i) => ({ t: i, o: 100, h: 100, l: 100, c: 100, v: 1 }));
  const buy = s.evaluate({ candles: [...flat.slice(0, 29), { t: 29, o: 100, h: 103, l: 99, c: 102, v: 1 }], position: null, params: { ...s.defaultParams, period: 20 } });
  assert.equal(buy.action, 'hold');
  const sell = s.evaluate({ candles: flat.slice(0, 3).concat([{ t: 3, o: 100, h: 100, l: 80, c: 80, v: 1 }]), position: { entryPrice: 100, stopPrice: 90, highWaterMark: 100 }, params: { ...s.defaultParams, period: 20 } });
  assert.equal(sell.action, 'sell');
});
