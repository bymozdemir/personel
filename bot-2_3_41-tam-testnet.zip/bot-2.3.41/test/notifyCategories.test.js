'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createNotifier } = require('../src/notify');

function setup() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bot-notify-categories-'));
  const sent = [];
  const notifier = createNotifier({
    env: { TELEGRAM_BOT_TOKEN: 'test-token', TELEGRAM_CHAT_ID: '123', BOT_DATA_DIR: dir, NOTIFY_MIN_GAP_MS: '0' },
    fetchFn: async (url, opts) => { sent.push(JSON.parse(opts.body)); return { ok: true, status: 200, json: async () => ({ ok: true, result: { message_id: sent.length } }) }; },
    logger: { log() {}, warn() {} }, sleep: async () => {}
  });
  return { dir, sent, notifier };
}

test('bildirim kategorisi kapatılıp açılabilir ve yeniden başlatmada korunur', async () => {
  const x = setup();
  x.notifier.setCategoryEnabled('scan', false);
  assert.equal(x.notifier.detail().categories.scan, false);
  const skipped = await x.notifier.send('Tarama tamamlandı', { category: 'scan' });
  assert.equal(skipped.skipped, true);
  assert.equal(x.sent.length, 0);
  await x.notifier.send('Sistem hatası', { category: 'system' });
  assert.equal(x.sent.length, 1);
  const next = createNotifier({ env: { TELEGRAM_BOT_TOKEN: 'test-token', TELEGRAM_CHAT_ID: '123', BOT_DATA_DIR: x.dir }, fetchFn: async () => ({ ok: true, status: 200, json: async () => ({ ok: true }) }), logger: { log() {}, warn() {} } });
  assert.equal(next.detail().categories.scan, false);
  next.setCategoryEnabled('scan', true);
  assert.equal(next.detail().categories.scan, true);
  fs.rmSync(x.dir, { recursive: true, force: true });
});

test('kritik bildirim kategori kapalı olsa da bastırılmaz', async () => {
  const x = setup();
  x.notifier.setCategoryEnabled('risk', false);
  const result = await x.notifier.send('Koruma hatası', { category: 'risk', priority: 'critical' });
  assert.equal(result.telegram, true);
  assert.equal(x.sent.length, 1);
  fs.rmSync(x.dir, { recursive: true, force: true });
});
