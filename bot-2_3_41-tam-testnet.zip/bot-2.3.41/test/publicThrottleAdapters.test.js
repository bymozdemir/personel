const test = require('node:test');
const assert = require('node:assert/strict');
const Btcturk = require('../src/exchanges/btcturk');
const Paribu = require('../src/exchanges/paribu');
const BinanceTr = require('../src/exchanges/binancetr');
const Kraken = require('../src/exchanges/kraken');

test('her adaptorun public butcesi var ve ortak taban sinifta calisir', async () => {
  delete process.env.PUBLIC_API_WEIGHT_PER_MIN;
  const cases = [[new Btcturk({}), 600], [new Paribu({}), 300], [new BinanceTr({}), 1200], [new Kraken({}), 300]];
  for (const [ex, per] of cases) {
    await ex._throttlePublic(1);
    assert.equal(ex.publicThrottler.maxWeight, per, ex.id);
  }
});

test('butce dolunca ag cagrisi yapilmadan rateLimited/throttled hatasi', async () => {
  delete process.env.PUBLIC_API_WEIGHT_PER_MIN;
  const ex = new Btcturk({});
  await ex._throttlePublic(600);
  let fetched = false;
  const orig = global.fetch; global.fetch = async () => { fetched = true; throw new Error('aga cikmamali'); };
  try {
    await assert.rejects(() => ex._publicGet('/ticker'), (e) => e.throttled === true && e.rateLimited === true && e.retryAfterMs > 0);
  } finally { global.fetch = orig; }
  assert.equal(fetched, false);
});

test('PUBLIC_API_WEIGHT_PER_MIN tum adaptorlerde ustune yazar; 0 kapatir', async () => {
  process.env.PUBLIC_API_WEIGHT_PER_MIN = '50';
  try {
    const a = new Paribu({}); await a._throttlePublic(1); assert.equal(a.publicThrottler.maxWeight, 50);
    process.env.PUBLIC_API_WEIGHT_PER_MIN = '0';
    const b = new Btcturk({}); await b._throttlePublic(1000); assert.equal(b.publicThrottler, null);
  } finally { delete process.env.PUBLIC_API_WEIGHT_PER_MIN; }
});
