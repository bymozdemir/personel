const test = require('node:test');
const assert = require('node:assert/strict');
const { capByRisk } = require('../src/positionSizing');
const PaperEngine = require('../src/paperEngine');
const store = require('../src/store');


test('capByRisk: Jesse risk_to_size ile uyumlu (kasa*risk/stop)', () => {
  // 10000 kasa, %1 risk, %5 stop => en fazla 2000 alim
  const r = capByRisk({ amount: 5000, equity: 10000, riskPct: 1, stopLossPct: 5 });
  assert.equal(r.capped, true);
  assert.ok(Math.abs(r.amount - 2000) < 1e-9);
});

test('capByRisk: yalniz KUCULTUR, asla buyutmez', () => {
  const r = capByRisk({ amount: 500, equity: 10000, riskPct: 1, stopLossPct: 5 });
  assert.equal(r.capped, false);
  assert.equal(r.amount, 500);
  for (const eq of [1, 100, 1e6]) for (const rp of [0.1, 1, 10]) for (const sl of [0.1, 3, 50]) {
    const x = capByRisk({ amount: 123, equity: eq, riskPct: rp, stopLossPct: sl });
    assert.ok(x.amount <= 123);
  }
});

test('capByRisk: yalnızca açıkça 0 risk sınırını kapatır; bozuk risk ayarı fail-closed olur', () => {
  assert.equal(capByRisk({ amount: 100, equity: 1000, riskPct: 0, stopLossPct: 3 }).amount, 100);
  for (const rp of [-1, NaN, undefined, null, 'x', 10.1]) {
    const x = capByRisk({ amount: 100, equity: 1000, riskPct: rp, stopLossPct: 3 });
    assert.equal(x.amount, 0); assert.equal(x.invalid, true);
  }
  for (const sl of [0, -3, NaN, undefined, 100, 150]) {
    const x = capByRisk({ amount: 100, equity: 1000, riskPct: 1, stopLossPct: sl });
    assert.equal(x.amount, 0);
    assert.equal(x.invalid, true);
  }
  assert.equal(capByRisk({ amount: 100, equity: 0, riskPct: 1, stopLossPct: 3 }).invalid, true);
  assert.ok(Number.isNaN(capByRisk({ amount: NaN, equity: 1000, riskPct: 1, stopLossPct: 3 }).amount));
});

function makeEngine(state) {
  const engine = new PaperEngine({ exchange: { quoteAssets: ['USDT'], fetchSymbolRules: async () => ({ minNotional: 1, stepSize: 0, minQty: 0 }) }, store: { save() {} }, state, nowFn: () => Date.UTC(2026, 9, 24) });
  engine.log = () => {};
  return engine;
}
function fresh(risk) {
  const state = store.defaultState();
  state.paper = store.defaultPaper(1000);
  Object.assign(state.settings, { maxTradeQuote: 0, reserveCashPct: 0, riskPerTradePct: risk });
  state.settings.protections = { enabled: false };
  return state;
}
const pair = { enabled: true, strategyId: 'rsi_simple', budgetPct: 100, params: {} };

test('paper motor: riskPerTradePct=0 iken alim tutari eskisiyle ayni (tum nakit)', async () => {
  const state = fresh(0);
  await makeEngine(state).tryBuy('BTC/USDT', pair, { reason: 't' }, { stopLossPct: 5 }, 100, 1);
  const pos = state.paper.positions['BTC/USDT'];
  assert.ok(pos.costQuote > 990);
});

test('paper motor: riskPerTradePct=1, stop %5 => maliyet ~ kasa*1%/5% = 200 ile sinirlanir', async () => {
  const state = fresh(1);
  await makeEngine(state).tryBuy('BTC/USDT', pair, { reason: 't' }, { stopLossPct: 5 }, 100, 1);
  const pos = state.paper.positions['BTC/USDT'];
  assert.ok(pos.costQuote <= 200.0001, String(pos.costQuote));
  assert.ok(pos.costQuote > 190, String(pos.costQuote));
});

test('paper motor: risk ayarı etkin ama stop geçersizse alış fail-closed atlanır', async () => {
  const state = fresh(1);
  const engine = makeEngine(state);
  const logs = []; engine.log = (m) => logs.push(m);
  await engine.tryBuy('BTC/USDT', pair, { reason: 't' }, { stopLossPct: 0 }, 100, 1);
  const pos = state.paper.positions['BTC/USDT'];
  assert.equal(pos, undefined);
  assert.ok(logs.some((m) => /güvenlik nedeniyle alım atlandı/.test(m)));
});
