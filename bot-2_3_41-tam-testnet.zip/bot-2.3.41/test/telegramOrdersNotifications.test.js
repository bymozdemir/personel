'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createTelegramCommands } = require('../src/telegramCommands');

function make({ status = {}, deps = {} } = {}) {
  const sent = [];
  const fetchFn = async (_url, opts) => { sent.push(JSON.parse(opts.body)); return { ok: true, status: 200, json: async () => ({ ok: true, result: [] }) }; };
  const bot = createTelegramCommands({ env: { TELEGRAM_BOT_TOKEN: '123:ABC', TELEGRAM_CHAT_ID: '42' }, fetchFn, logger: { log() {}, warn() {} }, getStatus: () => ({ mode: 'paper', quoteAsset: 'USDT', ...status }), ...deps });
  return { sent, say: async (text) => { await bot.processUpdate({ message: { chat: { id: 42 }, text } }); return sent.at(-1); } };
}

test('/bildirimler reports queue, pending, failures and last error without secrets', async () => {
  const { say } = make({ deps: { getNotifyInfo: () => ({ telegram: true, muted: false, queued: 2, pending: 1, channels: { telegram: { failures: 3, lastOkAt: null, lastError: 'network timeout' } }, dailySummary: { enabled: true, time: '20:00' } }) } });
  const r = await say('/bildirimler');
  assert.match(r.text, /BİLDİRİM DURUMU/);
  assert.match(r.text, /Gönderim kuyruğu: 2/);
  assert.match(r.text, /Bekleyen kritik\/kalıcı mesaj: 1/);
  assert.match(r.text, /network timeout/);
  assert.doesNotMatch(r.text, /123:ABC/);
});

test('/emirler paper mode clearly says exchange orders are not queried', async () => {
  const { say } = make({ deps: { getOpenOrders: async () => { throw new Error('must not query'); } } });
  const r = await say('/emirler');
  assert.match(r.text, /Paper modda borsaya gönderilmiş açık emir yok/);
});

test('/emirler live mode shows exchange open orders read-only', async () => {
  const { say } = make({ status: { mode: 'live' }, deps: { getOpenOrders: async () => [{ id: '123', symbol: 'BTC/USDT', side: 'sell', type: 'stop', status: 'open', amount: 0.2, filled: 0, remaining: 0.2, price: 60000 }] } });
  const r = await say('/emirler');
  assert.match(r.text, /Borsa açık emir sayısı: 1/);
  assert.match(r.text, /BTC\/USDT/);
  assert.match(r.text, /STOP/);
  assert.match(r.text, /emir oluşturmaz, iptal etmez/);
});

test('/emirler live query failure is not misreported as an empty order list', async () => {
  const { say } = make({ status: { mode: 'live' }, deps: { getOpenOrders: async () => { throw new Error('API unavailable'); } } });
  const r = await say('/emirler');
  assert.match(r.text, /API unavailable/);
  assert.match(r.text, /Emir durumu bilinmiyor/);
  assert.doesNotMatch(r.text, /Borsada açık emir bulunmuyor/);
});
