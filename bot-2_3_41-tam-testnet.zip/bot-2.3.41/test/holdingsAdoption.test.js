'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const store = require('../src/store');
const LiveEngine = require('../src/liveEngine');
const { AccountReconciler, normalizeQuotePrices } = require('../src/reconciliation');
const autonomousScanner = require('../src/autonomousScanner');

const NOW = Date.UTC(2026, 9, 28, 12, 0);
const makeStore = () => ({ saves: 0, save() { this.saves++; } });

function makeEx(extra = {}) {
  return {
    id: 'binance', environment: 'production', name: 'T', quoteAssets: ['USDT'],
    capabilities: { clientOrderId: true, orderQuery: true, balanceQuery: true, openOrdersQuery: true, userDataStream: true, oco: false, marketOrderBook: true },
    async fetchBalance() { return { USDT: { free: 0.01, locked: 0 } }; },
    async fetchOpenOrders() { return []; },
    async fetchTicker() { return { price: 0.5 }; },
    async fetchSymbolRules() { return { stepSize: 0.1, minQty: 0.1, minNotional: 5 }; },
    ...extra
  };
}

function makeLive({ autonomous = true, balances, inventory, prices } = {}) {
  const state = store.defaultState();
  state.settings.mode = 'live';
  state.pairs = {};
  state.autonomous.active = autonomous; state.autonomous.managedSymbols = [];
  state.live.safeToTrade = true;
  state.live.lastBalance = balances || { USDT: { free: 0.01, locked: 0, total: 0.01 }, XRP: { free: 100, locked: 0, total: 100 } };
  state.live.externalInventoryByAsset = inventory || { XRP: { asset: 'XRP', symbol: 'XRP/USDT', quote: 'USDT', referencePrice: 0.5, currentPrice: 0.5, currentQuantity: 100 } };
  state.live.assetPricesByQuote = prices || { USDT: { XRP: 0.5 } };
  state.live.assetPricesAt = new Date(NOW).toISOString();
  const engine = new LiveEngine({ exchange: makeEx(), state, store: makeStore(), allowLive: true, nowFn: () => NOW });
  return { state, engine };
}

test('toplam bakiye hesabı parite listesine bağlı değil: XRP listede olsa da olmasa da aynı', () => {
  const a = makeLive(); a.state.pairs = { 'XRP/USDT': { symbol: 'XRP/USDT' } };
  const b = makeLive(); b.state.pairs = { 'BTC/USDT': { symbol: 'BTC/USDT' } };
  assert.ok(Math.abs(a.engine.computeEquityByQuote().USDT - 50.01) < 1e-9);
  assert.ok(Math.abs(b.engine.computeEquityByQuote().USDT - 50.01) < 1e-9);
});

test('fiyat eskiyse (90 dk+) yalnız tablo fiyatıyla değerlenen varlık için risk hesabı atlanır', () => {
  const { state, engine } = makeLive();
  state.live.assetPricesAt = new Date(NOW - 3 * 3600 * 1000).toISOString();
  assert.deepEqual(engine.computeEquityByQuote(), {});
  state.live.lastPrices = { 'XRP/USDT': 0.5 }; // canlı tick fiyatı varsa tablo gerekmez
  assert.ok(engine.computeEquityByQuote().USDT > 50);
});

test('eski bakiye modelinden geçişte başlangıç/gün başı bakiyesi bir kez yeniden alınır, sahte zarar çıkmaz', async () => {
  const { state, engine } = makeLive();
  state.running = true;
  state.settings.killSwitchLossPct = 10; state.settings.dailyLossLimitPct = 5;
  delete state.live.equityModel;               // eski durum dosyası
  state.live.startingEquity = 1000; state.live.dayStartEquity = 1000; state.live.dayKey = engine.getRiskDayKey();
  state.live.startingEquityByQuote = { USDT: 1000 }; state.live.dayStartEquityByQuote = { USDT: 1000 };
  await engine._checkRiskGate();
  assert.equal(state.killSwitch, null);
  assert.equal(state.live.equityModel, 'account-v2');
  assert.ok(Math.abs(state.live.startingEquityByQuote.USDT - 50.01) < 1e-9);
});

test('sahiplenme: hesaptaki coin ilk görülen fiyatla bota ait pozisyon olur ve tekrar eklenmez', async () => {
  const { state, engine } = makeLive();
  const adopted = await engine._adoptExistingHoldings();
  assert.equal(adopted.length, 1);
  const pos = state.live.positions['XRP/USDT'];
  assert.equal(pos.adopted, true);
  assert.equal(pos.entryPrice, 0.5);
  assert.equal(pos.quantity, 100);
  assert.ok(Math.abs(pos.costQuote - 50) < 1e-9);
  assert.equal(pos.entryFeesVerified, true);
  assert.equal(state.pairs['XRP/USDT'].autonomousManaged, true);
  assert.equal(state.pairs['XRP/USDT'].enabled, false);
  assert.ok(state.autonomous.managedSymbols.includes('XRP/USDT'));
  assert.equal(state.settings.maxOpenOrders, 12, 'hesap devralma emir kotasını sessizce değiştirmez');
  assert.equal((await engine._adoptExistingHoldings()).length, 0, 'ikinci çağrıda tekrar sahiplenmez');
});

test('sahiplenme: kilitli miktar dahil toplam bakiye ve manuel canlı moddaki varlıklar sahiplenilir', async () => {
  const balances = {
    USDT: { free: 10, locked: 0, total: 10 }, BNB: { free: 5, locked: 0, total: 5 }, USDC: { free: 50, locked: 0, total: 50 },
    DUST: { free: 3, locked: 0, total: 3 }, LOCK: { free: 100, locked: 100, total: 200 }, NOREF: { free: 100, locked: 0, total: 100 },
    GOOD: { free: 100, locked: 0, total: 100 }
  };
  const mk = (asset, ref) => ({ asset, symbol: `${asset}/USDT`, quote: 'USDT', referencePrice: ref, currentPrice: ref });
  const inventory = { BNB: mk('BNB', 600), USDC: mk('USDC', 1), DUST: mk('DUST', 0.5), LOCK: mk('LOCK', 1), NOREF: mk('NOREF', null), GOOD: mk('GOOD', 0.5) };
  const { state, engine } = makeLive({ balances, inventory, prices: { USDT: { GOOD: 0.5, DUST: 0.5 } } });
  const adopted = await engine._adoptExistingHoldings();
  assert.deepEqual(adopted.map((x) => x.symbol), ['BNB/USDT', 'LOCK/USDT', 'GOOD/USDT']);
  assert.equal(state.live.positions['BNB/USDT'].quantity, 5, 'BNB de diğer uygun coinler gibi sahiplenilir');
  assert.equal(state.live.positions['USDC/USDT'], undefined, 'stablecoin sahiplenilmez');
  assert.match(state.live.adoptSkipped.DUST, /toz/);
  assert.equal(state.live.positions['LOCK/USDT'].quantity, 200);
  assert.equal(state.live.positions['LOCK/USDT'].freeQuantity, 100);
  assert.equal(state.live.positions['LOCK/USDT'].lockedQuantity, 100);

  const manual = makeLive({ autonomous: false });
  assert.equal((await manual.engine._adoptExistingHoldings()).length, 1, 'manuel canlı modda da sahiplenir');
  assert.ok(manual.state.live.positions['XRP/USDT']);
});



test('BNB ilk bakiyede sahiplenilir ve sahiplenmeden sonra gelen ek bakiye mevcut pozisyona eklenir', async () => {
  const balances = { USDT: { free: 100, locked: 0, total: 100 }, BNB: { free: 4, locked: 0, total: 4 } };
  const mk = (asset, price) => ({ asset, symbol: `${asset}/USDT`, quote: 'USDT', referencePrice: price, currentPrice: price });
  const inventory = { BNB: mk('BNB', 600) };
  const { state, engine } = makeLive({ balances, inventory, prices: { USDT: { BNB: 600 } } });
  const first = await engine._adoptExistingHoldings();
  assert.equal(first.length, 1);
  assert.equal(state.live.positions['BNB/USDT'].quantity, 4);
  assert.equal(state.live.positions['BNB/USDT'].costQuote, 2400);
  state.live.lastBalance.BNB = { free: 9, locked: 0, total: 9 };
  inventory.BNB.currentPrice = 650;
  state.live.assetPricesByQuote.USDT.BNB = 650;
  state.live.lastPrices['BNB/USDT'] = 650;
  const second = await engine._adoptExistingHoldings();
  assert.equal(second.length, 1);
  assert.equal(second[0].addedToExisting, true);
  assert.equal(second[0].qty, 5);
  assert.equal(state.live.positions['BNB/USDT'].quantity, 9);
  assert.equal(state.live.positions['BNB/USDT'].costQuote, 5650);
  assert.equal(state.live.positions['BNB/USDT'].entryPrice, 5650 / 9);
});

test('38 dış emir + 18 koruyucu stop/TP, 12 emirlik yeni işlem kotasını tüketmez', () => {
  const orders = {};
  for (let i = 0; i < 38; i++) orders[`external-${i}`] = { status: 'NEW', meta: { role: 'external-unclassified', external: true } };
  for (let i = 0; i < 18; i++) orders[`stop-${i}`] = { status: 'NEW', meta: { role: 'protective-stop' } };
  for (let i = 0; i < 18; i++) orders[`tp-${i}`] = { status: 'NEW', meta: { role: 'protective-tp', external: true } };
  assert.equal(LiveEngine.countActiveManagedOrders(orders), 0);
  orders['entry-pending'] = { status: 'NEW', meta: { role: 'entry' } };
  assert.equal(LiveEngine.countActiveManagedOrders(orders), 1);
  orders['entry-done'] = { status: 'FILLED', meta: { role: 'entry' } };
  assert.equal(LiveEngine.countActiveManagedOrders(orders), 1, 'terminal emirler kotayı tüketmez');
});

test('Binance OCO stop ve LIMIT_MAKER kâr ayağı doğru benimsenir', async () => {
  const { state, engine } = makeLive();
  const account = {
    balances: state.live.lastBalance,
    errors: [],
    openOrders: [
      { orderId: 501, clientOrderId: 'user-stop', symbol: 'XRPUSDT', side: 'SELL', type: 'STOP_LOSS_LIMIT', status: 'NEW', origQty: 100, executedQty: 0, stopPrice: 0.45, price: 0.449, orderListId: 77 },
      { orderId: 502, clientOrderId: 'user-tp', symbol: 'XRPUSDT', side: 'SELL', type: 'LIMIT_MAKER', status: 'NEW', origQty: 100, executedQty: 0, stopPrice: 0, price: 0.6, orderListId: 77 }
    ]
  };
  await engine._repairRecoveredState({ account });
  const position = state.live.positions['XRP/USDT'];
  assert.equal(position.stopOrderId, 'user-stop');
  assert.equal(position.tpOrderId, 'user-tp');
  assert.equal(state.liveOrders['user-stop'].meta.role, 'protective-stop');
  assert.equal(state.liveOrders['user-tp'].meta.role, 'protective-tp');
});


test('önceden yerel deftere alınmış dış stop her recoveryde pozisyona yeniden bağlanır', async () => {
  const { state, engine } = makeLive();
  engine.orderManager._record('persisted-stop', {
    clientOrderId: 'persisted-stop', exchangeOrderId: 551, symbol: 'XRP/USDT', side: 'sell',
    type: 'STOP_LOSS_LIMIT', status: 'NEW', origQty: 100, executedQty: 0,
    stopPrice: 0.45, meta: { role: 'external-unclassified', external: true }
  }, { tolerateSaveError: true });
  const account = {
    balances: state.live.lastBalance,
    errors: [],
    openOrders: [
      { orderId: 551, clientOrderId: 'persisted-stop', symbol: 'XRPUSDT', side: 'SELL', type: 'STOP_LOSS_LIMIT', status: 'NEW', origQty: 100, executedQty: 0, stopPrice: 0.45, price: 0.449 }
    ]
  };
  await engine._repairRecoveredState({ account });
  assert.equal(state.live.positions['XRP/USDT'].stopOrderId, 'persisted-stop');
  assert.equal(state.liveOrders['persisted-stop'].meta.role, 'protective-stop');
});


test('yerel stop eski/iptal edilmişse recovery borsadaki yeni stopu bağlar', async () => {
  const { state, engine } = makeLive();
  engine.orderManager._record('old-stop', {
    clientOrderId: 'old-stop', exchangeOrderId: 550, symbol: 'XRP/USDT', side: 'sell',
    type: 'STOP_LOSS_LIMIT', status: 'CANCELED', origQty: 100, executedQty: 0,
    meta: { role: 'protective-stop' }
  }, { tolerateSaveError: true });
  state.live.positions['XRP/USDT'] = {
    symbol: 'XRP/USDT', baseAsset: 'XRP', quoteAsset: 'USDT', quantity: 100,
    entryPrice: 0.5, costQuote: 50, adopted: true, stopOrderId: 'old-stop'
  };
  state.pairs['XRP/USDT'] = {
    symbol: 'XRP/USDT', enabled: false, strategyId: 'rsi_ema_macd', timeframe: '1h',
    budgetPct: 10, params: { stopLossPct: 5 }
  };
  const account = {
    balances: state.live.lastBalance,
    errors: [],
    openOrders: [
      { orderId: 552, clientOrderId: 'new-exchange-stop', symbol: 'XRPUSDT', side: 'SELL', type: 'STOP_LOSS_LIMIT', status: 'NEW', origQty: 100, executedQty: 0, stopPrice: 0.45, price: 0.449 }
    ]
  };
  await engine._repairRecoveredState({ account });
  assert.equal(state.live.positions['XRP/USDT'].stopOrderId, 'new-exchange-stop');
});

test('eşleştirilemeyen dış SELL emri varken recovery ikinci bir stop oluşturmaz', async () => {
  const { state, engine } = makeLive();
  const account = {
    balances: state.live.lastBalance,
    errors: [],
    openOrders: [
      { orderId: 601, clientOrderId: 'user-limit-sell', symbol: 'XRPUSDT', side: 'SELL', type: 'LIMIT', status: 'NEW', origQty: 25, executedQty: 0, price: 0.6 }
    ]
  };
  await assert.rejects(engine._repairRecoveredState({ account }), /eşleştirilemeyen 1 açık SELL/);
  assert.equal(state.live.positions['XRP/USDT'].stopOrderId, null);
  assert.equal(state.liveOrders['user-limit-sell'].meta.role, 'external-unclassified');
});

test('miktarı pozisyonla eşleşen normal LIMIT SELL koruyucu stop diye sahiplenilmez', async () => {
  const { state, engine } = makeLive();
  const account = {
    balances: state.live.lastBalance,
    errors: [],
    openOrders: [
      { orderId: 611, clientOrderId: 'user-full-limit-sell', symbol: 'XRPUSDT', side: 'SELL', type: 'LIMIT', status: 'NEW', origQty: 100, executedQty: 0, price: 0.6 }
    ]
  };
  await assert.rejects(engine._repairRecoveredState({ account }), /eşleştirilemeyen 1 açık SELL/);
  assert.equal(state.live.positions['XRP/USDT'].stopOrderId, null);
  assert.equal(state.liveOrders['user-full-limit-sell'].meta.role, 'external-unclassified');
});

test('UNKNOWN recovery stop aynı clientOrderId ile sorgulanır; ikinci stop gönderilmez', async () => {
  const { state, engine } = makeLive();
  let reconcileCalls = 0;
  let submitCalls = 0;
  engine.orderManager.submitStop = async ({ symbol }) => {
    submitCalls++;
    return { clientOrderId: 'recovery-stop-unknown', symbol, status: 'UNKNOWN', uncertain: true };
  };
  engine.orderManager.reconcile = async (clientOrderId) => {
    reconcileCalls++;
    assert.equal(clientOrderId, 'recovery-stop-unknown');
    return { clientOrderId, status: 'NEW', uncertain: false, exchangeOrderId: 987 };
  };
  await engine._repairRecoveredState({ account: { balances: state.live.lastBalance, errors: [], openOrders: [] } });
  assert.equal(submitCalls, 1);
  assert.equal(reconcileCalls, 1);
  assert.equal(state.live.positions['XRP/USDT'].stopOrderId, 'recovery-stop-unknown');
});

test('aynı pozisyonda birden fazla dış stop varsa recovery kilitlenir', async () => {
  const { state, engine } = makeLive();
  const mk = (orderId) => ({ orderId, clientOrderId: `user-stop-${orderId}`, symbol: 'XRPUSDT', side: 'SELL', type: 'STOP_LOSS_LIMIT', status: 'NEW', origQty: 100, executedQty: 0, stopPrice: 0.45, price: 0.449 });
  const account = { balances: state.live.lastBalance, errors: [], openOrders: [mk(701), mk(702)] };
  await assert.rejects(engine._repairRecoveredState({ account }), /birden fazla açık dış koruyucu stop/);
  assert.equal(state.live.safeToTrade, false);
});

test('sahiplenme kapatılabilir: ortam değişkeni ve ayar', async () => {
  const prev = process.env.BOT_ADOPT_EXISTING_HOLDINGS;
  try {
    process.env.BOT_ADOPT_EXISTING_HOLDINGS = 'false';
    assert.deepEqual(await makeLive().engine._adoptExistingHoldings(), []);
  } finally { if (prev === undefined) delete process.env.BOT_ADOPT_EXISTING_HOLDINGS; else process.env.BOT_ADOPT_EXISTING_HOLDINGS = prev; }
  const { state, engine } = makeLive(); state.settings.adoptExistingHoldings = false;
  assert.deepEqual(await engine._adoptExistingHoldings(), []);
});

test('sahiplenme üst sınırı (adoptMaxPositions) aşılmaz', async () => {
  const balances = { USDT: { free: 1, locked: 0, total: 1 } }; const inventory = {}; const prices = { USDT: {} };
  for (let i = 0; i < 6; i++) { const a = `C${i}`; balances[a] = { free: 100, locked: 0, total: 100 }; inventory[a] = { asset: a, symbol: `${a}/USDT`, quote: 'USDT', referencePrice: 0.5, currentPrice: 0.5 }; prices.USDT[a] = 0.5; }
  const { state, engine } = makeLive({ balances, inventory, prices }); state.settings.adoptMaxPositions = 3;
  assert.equal((await engine._adoptExistingHoldings()).length, 3);
});

test('bir hediye coin satıldıktan sonra 60 kapasite dolana kadar sıradaki Testnet bakiyesi devralınır', async () => {
  const balances = { USDT: { free: 1, locked: 0, total: 1 } }; const inventory = {}; const prices = { USDT: {} };
  for (let i = 0; i < 4; i++) { const a = `GIFT${i}`; balances[a] = { free: 100, locked: 0, total: 100 }; inventory[a] = { asset: a, symbol: `${a}/USDT`, quote: 'USDT', referencePrice: 0.5, currentPrice: 0.5 }; prices.USDT[a] = 0.5; }
  const { state, engine } = makeLive({ balances, inventory, prices }); state.settings.adoptMaxPositions = 3;
  assert.deepEqual((await engine._adoptExistingHoldings()).map((x) => x.symbol), ['GIFT0/USDT', 'GIFT1/USDT', 'GIFT2/USDT']);
  delete state.live.positions['GIFT0/USDT'];
  state.live.lastBalance.GIFT0 = { free: 0, locked: 0, total: 0 };
  const next = await engine._adoptExistingHoldings();
  assert.deepEqual(next.map((x) => x.symbol), ['GIFT3/USDT']);
  assert.equal(Object.keys(state.live.positions).length, 3);
});

function giftBalances(n) {
  const balances = { USDT: { free: 1, locked: 0, total: 1 } }; const inventory = {}; const prices = { USDT: {} };
  for (let i = 0; i < n; i++) { const a = `G${i}`; balances[a] = { free: 100, locked: 0, total: 100 }; inventory[a] = { asset: a, symbol: `${a}/USDT`, quote: 'USDT', referencePrice: 0.5, currentPrice: 0.5 }; prices.USDT[a] = 0.5; }
  return { balances, inventory, prices };
}

test('2.3.32 otonom: sahiplenme siniri secilen coin sayisi - 12 rezerv; satilan hediye coinin yerine yenisi gelmez', async () => {
  const { state, engine } = makeLive(giftBalances(30));
  state.autonomous.active = true; state.autonomous.selectedCount = 32;
  engine.exchange.fetchCandles = async () => [];
  const original = autonomousScanner.scanManagementConfigs;
  autonomousScanner.scanManagementConfigs = async ({ symbols }) => symbols.map((symbol) => ({ symbol, selected: { strategyId: 'ema_cross', timeframe: '30m', score: 7.5 } }));
  try {
    assert.equal((await engine._adoptExistingHoldings()).length, 20, '32 - 12 = 20');
    assert.match(state.live.adoptSkipped._limit, /en fazla 20 sahiplenilmiş/);
    delete state.live.positions['G0/USDT']; state.live.lastBalance.G0 = { free: 0, locked: 0, total: 0 };
    assert.equal((await engine._adoptExistingHoldings()).length, 1, 'sayi 20 altina inince bir tane tamamlanir');
    assert.equal(Object.values(state.live.positions).filter((p) => p.adopted).length, 20);
  } finally { autonomousScanner.scanManagementConfigs = original; }
});

test('2.3.32 otonom: botun kendi pozisyonları sahiplenme sınırını tüketmez; adoptEntryReserve ayarı çalışır', async () => {
  const { state, engine } = makeLive(giftBalances(30));
  state.autonomous.active = true; state.autonomous.selectedCount = 32; state.settings.adoptEntryReserve = 22;
  state.live.positions['OWN1/USDT'] = { symbol: 'OWN1/USDT', quantity: 1, entryPrice: 1 };
  state.live.positions['OWN2/USDT'] = { symbol: 'OWN2/USDT', quantity: 1, entryPrice: 1 };
  engine.exchange.fetchCandles = async () => [];
  const original = autonomousScanner.scanManagementConfigs;
  autonomousScanner.scanManagementConfigs = async ({ symbols }) => symbols.map((symbol) => ({ symbol, selected: { strategyId: 'ema_cross', timeframe: '30m', score: 7.5 } }));
  try {
    assert.equal((await engine._adoptExistingHoldings()).length, 10, '32 - 22 = 10, bota ait 2 pozisyon sayılmaz');
  } finally { autonomousScanner.scanManagementConfigs = original; }
});

function adoptedSetup(symbols) {
  const { state, engine } = makeLive();
  state.live.safeToTrade = true;
  const old = new Date(NOW - 3600 * 1000).toISOString();
  symbols.forEach(([sym, qty, price]) => {
    state.live.positions[sym] = { symbol: sym, quantity: qty, entryPrice: price, adopted: true, adoptedAt: old, openedAt: old };
    state.live.lastPrices[sym] = price;
  });
  const sold = [];
  engine.sell = async (sym) => { sold.push(sym); delete state.live.positions[sym]; };
  return { state, engine, sold };
}

test('2.3.39: güçlü yeni aday veya bekleyen slot yeni sinyal olmadan sahiplenilmiş pozisyonu satamaz', async () => {
  const { state, engine, sold } = adoptedSetup([['AAA/USDT', 100, 1], ['BBB/USDT', 1000, 1], ['CCC/USDT', 500, 1]]);
  const before = Object.keys(state.live.positions).sort();
  assert.deepEqual(await engine.rotateAdopted({ buySignalSymbols: new Set(['BBB/USDT']), waiting: 9 }), []);
  assert.deepEqual(sold, []);
  assert.deepEqual(Object.keys(state.live.positions).sort(), before);
});

async function withTestnetGates(fn) {
  const keys = ['BINANCE_ENV', 'ALLOW_BINANCE_TESTNET_TRADING', 'LIVE_TRADING_ENABLED'];
  const old = Object.fromEntries(keys.map((k) => [k, process.env[k]]));
  Object.assign(process.env, { BINANCE_ENV: 'testnet', ALLOW_BINANCE_TESTNET_TRADING: 'true', LIVE_TRADING_ENABLED: 'true' });
  try { return await fn(); } finally { for (const k of keys) { if (old[k] === undefined) delete process.env[k]; else process.env[k] = old[k]; } }
}

test('normalizeQuotePrices: farklı quote için fiyat haritası çıkarır', () => {
  const rows = [{ symbol: 'XRP/TRY', lastPrice: 20 }, { symbol: 'XRP/USDT', lastPrice: 0.5 }, { symbol: 'BAD', lastPrice: 1 }];
  assert.deepEqual(normalizeQuotePrices(rows, 'TRY'), { XRP: 20 });
  assert.deepEqual(normalizeQuotePrices(rows, 'USDT'), { XRP: 0.5 });
});

test('mutabakat: tüm quote fiyat haritasını ve ilk görülen fiyatı kaydeder', async () => {
  const state = store.defaultState(); state.settings.mode = 'live'; state.live.externalInventoryByAsset = {};
  const ex = makeEx({
    async fetchBalance() { return { USDT: { free: 1, locked: 0 }, XRP: { free: 100, locked: 0 } }; },
    async fetchAllTickers24h() { return [{ symbol: 'XRP/USDT', lastPrice: 0.5 }, { symbol: 'ADA/USDT', lastPrice: 0.4 }]; }
  });
  await new AccountReconciler({ exchange: ex, state, store: makeStore() }).reconcile();
  assert.equal(state.live.assetPricesByQuote.USDT.XRP, 0.5);
  assert.ok(state.live.assetPricesAt);
  assert.equal(state.live.externalInventoryByAsset.XRP.referencePrice, 0.5);
  assert.equal(state.live.externalInventoryByAsset.XRP.quote, 'USDT');
});

// ---- Stop emri reddi / toz güvenilirliği ----
function stopRejectSetup({ rejectSymbols = ['BAD/USDT'], rejectMessage = null, unknownOutcome = false, assets = [['GOOD1', 100], ['BAD', 100], ['GOOD2', 100]], price = 0.5 } = {}) {
  const state = store.defaultState();
  state.settings.mode = 'live'; state.pairs = {};
  state.autonomous.active = true; state.autonomous.managedSymbols = [];
  state.live.safeToTrade = true;
  const bal = { USDT: { free: 50, locked: 0, total: 50 } }, inv = {}, px = {};
  state.live.lastPrices = {};
  for (const [a, q] of assets) {
    bal[a] = { free: q, locked: 0, total: q };
    inv[a] = { asset: a, symbol: `${a}/USDT`, quote: 'USDT', referencePrice: 0.5, currentPrice: price };
    px[a] = price; state.live.lastPrices[`${a}/USDT`] = price;
  }
  state.live.lastBalance = bal; state.live.externalInventoryByAsset = inv;
  state.live.assetPricesByQuote = { USDT: px }; state.live.assetPricesAt = new Date(NOW).toISOString();
  const stops = [], calls = [];
  const ex = makeEx({
    environment: 'testnet',
    capabilities: { liveTradingVerified: true, protectiveStopImplemented: true, clientOrderId: true, orderQuery: true, balanceQuery: true, openOrdersQuery: true, userDataStream: true, oco: false, marketOrderBook: true },
    async fetchBalance() { return bal; },
    async fetchOpenOrders() { return stops.filter((o) => o.status === 'NEW'); },
    async createStopOrder(symbol, side, amount, stop, limit, cid) {
      if (rejectSymbols.includes(symbol)) { if (rejectMessage) { const e = new Error(rejectMessage); if (unknownOutcome) e.unknownOutcome = true; throw e; } }
      const status = rejectSymbols.includes(symbol) ? 'REJECTED' : 'NEW';
      const o = { status, orderId: stops.length + 10, clientOrderId: cid, symbol: symbol.replace('/', ''), side: 'SELL', executedQty: 0, origQty: amount, stopPrice: stop, type: 'STOP_LOSS' };
      stops.push(o); return o;
    },
    async createMarketOrder(symbol, side, amount, cid) { calls.push(['market', symbol, amount]); return { status: 'FILLED', orderId: 77, clientOrderId: cid, symbol: symbol.replace('/', ''), side: 'SELL', executedQty: amount, origQty: amount, cummulativeQuoteQty: amount * price }; },
    async getOrder(symbol, id, cid) { const o = stops.find((x) => String(x.orderId) === String(id) || (cid && x.clientOrderId === cid)); if (o) return o; if (String(id) === '77') return { status: 'FILLED', orderId: 77 }; throw new Error('Order does not exist.'); },
    async cancelOrder() { return { status: 'CANCELED' }; }
  });
  const engine = new LiveEngine({ exchange: ex, state, store: makeStore(), allowLive: true, nowFn: () => NOW });
  engine.log = () => {};
  const notes = []; engine.notify = (text) => notes.push(text);
  return { state, engine, notes, calls };
}

async function roundTrip(engine) {
  await engine._ensurePositionProtection();
  engine.lastReconcileAt = 0;
  await engine._reconcileIfDue();
}

test('stop reddi: tek bir sahiplenilmiş coinin stopu reddedilince bot KİLİTLENMEZ, diğerleri korunur, coin 3 denemede bırakılır', () => withTestnetGates(async () => {
  const { state, engine, notes } = stopRejectSetup();
  await engine._adoptExistingHoldings();
  for (let i = 1; i <= 4; i++) {
    await roundTrip(engine);
    assert.equal(state.live.safeToTrade, true, `tur ${i}: kilit olmamalı ${JSON.stringify({ lock: state.live.lockReason, rec: state.liveReconciliation && state.liveReconciliation.errors, rec2: state.live.reconciliation && state.live.reconciliation.errors })}`);
  }
  assert.deepEqual(Object.keys(state.live.positions).sort(), ['GOOD1/USDT', 'GOOD2/USDT']);
  assert.ok(state.live.positions['GOOD1/USDT'].stopOrderId && state.live.positions['GOOD2/USDT'].stopOrderId);
  assert.equal(state.pairs['BAD/USDT'], undefined);
  assert.ok(!state.autonomous.managedSymbols.includes('BAD/USDT'));
  assert.match(state.live.adoptSkipped.BAD, /yönetim dışı/);
  assert.ok(notes.some((n) => /BAD\/USDT/.test(n)), 'kullanıcıya bildirilmeli');
  assert.equal((await engine._adoptExistingHoldings()).length, 0, 'bekleme süresi içinde tekrar sahiplenmez');
}));

test('stop reddi: istisna fırlatan borsa hatası da aynı şekilde kilitlemez', () => withTestnetGates(async () => {
  const { state, engine } = stopRejectSetup({ rejectMessage: 'Binance -1013: Filter failure: NOTIONAL' });
  await engine._adoptExistingHoldings();
  for (let i = 0; i < 4; i++) { await roundTrip(engine); assert.equal(state.live.safeToTrade, true); }
  assert.equal(state.live.positions['BAD/USDT'], undefined);
  assert.ok(state.live.positions['GOOD1/USDT'].stopOrderId);
}));

test('sonucu belirsiz (ağ) stop hatası borsa reddi sayılmaz: coin yönetimden bırakılmaz', () => withTestnetGates(async () => {
  const { state, engine } = stopRejectSetup({ rejectMessage: 'fetch failed: ETIMEDOUT', unknownOutcome: true });
  await engine._adoptExistingHoldings();
  for (let i = 0; i < 2; i++) await roundTrip(engine);
  assert.ok(state.live.positions['BAD/USDT'], 'belirsiz sonuçta pozisyon korunur');
  assert.ok(!state.live.positions['BAD/USDT'].adoptStopFailures, 'belirsiz sonuç ret sayacına eklenmez');
}));

test('bota ait (sahiplenilmemiş) pozisyonda stop kurulamazsa eski güvenli davranış sürer: bot kilitlenir', () => withTestnetGates(async () => {
  const { state, engine } = stopRejectSetup({ rejectSymbols: ['OWN/USDT'], assets: [] });
  state.live.positions['OWN/USDT'] = { symbol: 'OWN/USDT', baseAsset: 'OWN', quoteAsset: 'USDT', quantity: 100, entryPrice: 0.5, costQuote: 50, openedAt: new Date(NOW - 3600e3).toISOString(), entryFeesVerified: true, stopOrderId: null, stopPrice: null };
  state.pairs['OWN/USDT'] = { symbol: 'OWN/USDT', enabled: true, strategyId: 'rsi_ema_macd', timeframe: '1h', budgetPct: 10, params: { stopLossPct: 3 } };
  state.live.lastPrices['OWN/USDT'] = 0.5;
  await engine._ensurePositionProtection();
  assert.equal(state.live.safeToTrade, false);
  assert.ok(state.live.positions['OWN/USDT'], 'bota ait pozisyon asla sessizce bırakılmaz');
}));

test('mutabakat: stopsuz sahiplenilmiş pozisyon uyarıdır, stopsuz bota ait pozisyon hâlâ hatadır', async () => {
  const mk = (adopted) => {
    const state = store.defaultState(); state.settings.mode = 'live';
    state.live.positions = { 'AAA/USDT': { symbol: 'AAA/USDT', baseAsset: 'AAA', quoteAsset: 'USDT', quantity: 10, entryPrice: 1, stopOrderId: null, adopted } };
    return state;
  };
  const ex = makeEx({ async fetchBalance() { return { USDT: { free: 100, locked: 0 }, AAA: { free: 10, locked: 0 } }; } });
  const rA = await new AccountReconciler({ exchange: ex, state: mk(true), store: makeStore() }).reconcile();
  assert.ok(!rA.errors.some((e) => /Koruyucu stop/.test(e)), JSON.stringify(rA.errors));
  const rB = await new AccountReconciler({ exchange: ex, state: mk(false), store: makeStore() }).reconcile();
  assert.ok(rB.errors.some((e) => /Koruyucu stop kaydı yok/.test(e)));
});

test('toz payı: minimum emir tutarının 1.5 katının altındaki coin sahiplenilmez (fiyat düşünce satılamaz hâle gelmesin)', async () => {
  // minNotional 5: 12 birim * 0.5 = 6 USDT (1.2x) atlanır; 20 birim * 0.5 = 10 USDT (2x) sahiplenilir
  const balances = { USDT: { free: 1, locked: 0, total: 1 }, NEAR: { free: 12, locked: 0, total: 12 }, SAFE: { free: 20, locked: 0, total: 20 } };
  const mk = (a) => ({ asset: a, symbol: `${a}/USDT`, quote: 'USDT', referencePrice: 0.5, currentPrice: 0.5 });
  const { engine } = makeLive({ balances, inventory: { NEAR: mk('NEAR'), SAFE: mk('SAFE') }, prices: { USDT: { NEAR: 0.5, SAFE: 0.5 } } });
  assert.deepEqual((await engine._adoptExistingHoldings()).map((x) => x.symbol), ['SAFE/USDT']);
});

test('ilk görülen fiyatın altına düşmüş coin: stop şimdiki fiyata göre konur, coin anında satılmaz ve reddedilmez', () => withTestnetGates(async () => {
  const { state, engine, calls } = stopRejectSetup({ rejectSymbols: [], assets: [['DROP', 100]], price: 0.4 }); // ilk görülen 0.5, şimdi 0.4
  await engine._adoptExistingHoldings();
  const pos0 = state.live.positions['DROP/USDT'];
  assert.equal(pos0.entryPrice, 0.5, 'giriş fiyatı ilk görülen fiyat olarak kalır');
  assert.ok(Math.abs(pos0.stopPrice - 0.4 * (1 - require('../src/strategies').get('trend_regime').defaultParams.stopLossPct / 100)) < 1e-9, 'stop şimdiki fiyatın varsayılan trend stop yüzdesi altı');
  await engine._ensurePositionProtection();
  assert.equal(calls.length, 0, 'piyasa satışı yapılmamalı');
  assert.ok(state.live.positions['DROP/USDT'].stopOrderId, 'koruyucu stop kurulmalı');
}));


test('otonom sahiplenme mevcut coin için en iyi doğrulanmış strateji ve mumu atar; BUY sinyali şartı yoktur', async () => {
  const { state, engine } = makeLive();
  state.settings.mode = 'live';
  state.autonomous.active = true;
  engine.exchange.fetchCandles = async () => [];
  const original = autonomousScanner.scanManagementConfigs;
  autonomousScanner.scanManagementConfigs = async ({ symbols }) => symbols.map((symbol) => ({
    symbol, selected: { strategyId: 'ema_cross', timeframe: '30m', score: 7.5 }
  }));
  try {
    await engine._adoptExistingHoldings();
    assert.equal(state.pairs['XRP/USDT'].strategyId, 'ema_cross');
    assert.equal(state.pairs['XRP/USDT'].timeframe, '30m');
    assert.equal(state.pairs['XRP/USDT'].managementSelectionPending, false);
    assert.equal(state.live.positions['XRP/USDT'].adopted, true);
  } finally { autonomousScanner.scanManagementConfigs = original; }
});

test('tam satıştan sonra eski bakiye görüntüsü satılan coini yeniden sahiplendirmez ve satış geliri nakde yansır', () => {
  const { state, engine } = makeLive({
    balances: { USDT: { free: 1, locked: 0, total: 1 }, XRP: { free: 100, locked: 0, total: 100 } }
  });
  const position = { symbol: 'XRP/USDT', baseAsset: 'XRP', quoteAsset: 'USDT', quantity: 100 };
  engine._applySoldToBalanceSnapshot('XRP/USDT', position, 100, 49.5, 0);
  assert.equal(state.live.lastBalance.XRP.total, 0);
  assert.equal(state.live.lastBalance.XRP.free, 0);
  assert.equal(state.live.lastBalance.USDT.free, 50.5);
  assert.ok(Number(state.live.adoptCooldown.XRP) > NOW);
});

test('koruyucu stop tam dolunca satılan coin eski bakiye görüntüsüyle yeniden sahiplenilmez (DCR çift stop-loss vakası)', async () => {
  const { state, engine } = makeLive({
    balances: { USDT: { free: 1, locked: 0, total: 1 }, XRP: { free: 0, locked: 100, total: 100 } }
  });
  const pos = { symbol: 'XRP/USDT', baseAsset: 'XRP', quoteAsset: 'USDT', quantity: 100 };
  engine._applySoldToBalanceSnapshot('XRP/USDT', pos, 100, 48, 0);
  const adopted = await engine._adoptExistingHoldings();
  assert.equal(adopted.length, 0);
  assert.equal(state.live.positions['XRP/USDT'], undefined);
});
