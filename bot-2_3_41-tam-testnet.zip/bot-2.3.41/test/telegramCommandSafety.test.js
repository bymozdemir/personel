'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createTelegramCommands } = require('../src/telegramCommands');
const { applyEmergencyStop, restoreManualPairs } = require('../src/autonomousState');

const env = { TELEGRAM_BOT_TOKEN: '123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ0123', TELEGRAM_CHAT_ID: '42' };

function make({ status = {}, deps = {} } = {}) {
  const requests = [];
  const calls = { start: 0, emergency: 0, addPair: 0, removePair: 0, setPairEnabled: 0 };
  const fetchFn = async (url, opts) => { requests.push(JSON.parse(opts.body)); return { ok: true, status: 200, json: async () => ({ ok: true, result: [] }) }; };
  const st = { mode: 'paper', running: false, killSwitch: false, exchange: 'binance', quoteAsset: 'USDT', cash: 100, positions: 0, holdings: [], settings: {}, recentLog: [], uiMode: 'manual', autonomous: { active: false, stopping: false }, ...status };
  const bot = createTelegramCommands({
    env, fetchFn, logger: { log() {}, warn() {} }, getStatus: () => st,
    startBot: async () => { calls.start++; st.running = true; },
    stopBot: async () => { st.running = false; },
    emergencyStopBot: async () => { calls.emergency++; st.running = false; return { message: 'ok' }; },
    listStrategies: () => [{ id: 'rsi_ema_macd', name: 'RSI+EMA+MACD', defaultParams: { stopLossPct: 3 } }],
    addPair: async () => { calls.addPair++; return {}; },
    removePair: async () => { calls.removePair++; return {}; },
    setPairEnabled: async () => { calls.setPairEnabled++; return {}; },
    ...deps
  });
  const say = async (text) => { await bot.processUpdate({ message: { chat: { id: 42, type: 'private' }, from: { id: 42 }, text } }); return requests.at(-1); };
  return { say, st, calls, requests };
}

test('/basla: otonom arayüz modu seçiliyken (otonom aktif değilse) manuel motoru başlatmaz', async () => {
  const { say, calls } = make({ status: { uiMode: 'autonomous' } });
  const r = await say('/basla');
  assert.equal(calls.start, 0);
  assert.match(r.text, /Otonom arayüz modu seçili/);
});

test('/basla: manuel modda hâlâ Paper motoru başlatır', async () => {
  const { say, calls } = make();
  await say('/basla');
  assert.equal(calls.start, 1);
});

test('otonom çalışırken /coin_ekle, /coin_sil, /coin_ac reddedilir; /coin_durdur (riski azaltan) çalışır', async () => {
  const { say, calls } = make({ status: { uiMode: 'autonomous', running: true, autonomous: { active: true, stopping: false }, pairs: [] } });
  for (const cmd of ['/coin_ekle PEPE/USDT', '/coin_sil PEPE/USDT', '/coin_ac PEPE/USDT']) {
    const r = await say(cmd);
    assert.match(r.text, /Otonom mod çalışırken coin ekleme\/silme\/açma kapalı/, cmd);
  }
  assert.equal(calls.addPair + calls.removePair + calls.setPairEnabled, 0);
  const r = await say('/coin_durdur PEPE/USDT');
  assert.doesNotMatch(r.text, /Otonom mod çalışırken coin ekleme/);
});

test('otonom durdurulurken (stopping) de coin değişikliği reddedilir', async () => {
  const { say } = make({ status: { running: true, autonomous: { active: false, stopping: true } } });
  assert.match((await say('/coin_ekle PEPE/USDT')).text, /kapalı/);
});

test('bekleyen coin işlemi otonom başlayınca /onayla ile uygulanmaz ve iptal edilir', async () => {
  const { say, st, calls } = make();
  await say('/coin_ekle PEPE/USDT');       // sihirbaz başlar (manuel mod)
  st.autonomous = { active: true, stopping: false };   // bu arada otonom başladı
  const r = await say('/onayla');
  assert.match(r.text, /bekleyen coin işlemi iptal edildi/);
  assert.equal(calls.addPair, 0);
});

test('/acil_durdur tek başına durdurmaz; /acil_onayla uygular; onay tek kullanımlıktır', async () => {
  const { say, calls } = make({ status: { running: true } });
  await say('/acil_durdur');
  assert.equal(calls.emergency, 0);
  await say('/acil_onayla');
  assert.equal(calls.emergency, 1);
  const again = await say('/acil_onayla');
  assert.equal(calls.emergency, 1, 'ikinci onay tekrar çalıştırmaz');
  assert.match(again.text, /Bekleyen acil durdurma yok/);
});

test('/acil_onayla bekleyen istek olmadan hiçbir şey durdurmaz; /iptal bekleyen acil durdurmayı siler', async () => {
  const a = make({ status: { running: true } });
  assert.match((await a.say('/acil_onayla')).text, /Bekleyen acil durdurma yok/);
  assert.equal(a.calls.emergency, 0);
  const b = make({ status: { running: true } });
  await b.say('/acil_durdur'); await b.say('/iptal'); await b.say('/acil_onayla');
  assert.equal(b.calls.emergency, 0);
});

test('/acil_onayla süresi dolunca (2 dk) uygulanmaz', async () => {
  const realNow = Date.now; let t = 1_000_000;
  Date.now = () => t;
  try {
    const { say, calls } = make({ status: { running: true } });
    await say('/acil_durdur');
    t += 3 * 60 * 1000;
    const r = await say('/acil_onayla');
    assert.equal(calls.emergency, 0);
    assert.match(r.text, /süresi doldu/);
  } finally { Date.now = realNow; }
});

function autonomousFixture() {
  return {
    settings: { maxConcurrentPositions: 3 },
    pairs: {
      'BTC/USDT': { symbol: 'BTC/USDT', enabled: false, autonomousManaged: false },   // kullanıcının manuel coini (otonom başlarken kapatılmıştı)
      'ETH/USDT': { symbol: 'ETH/USDT', enabled: false, autonomousManaged: false },
      'AAA/USDT': { symbol: 'AAA/USDT', enabled: true, autonomousManaged: true },      // otonom, açık pozisyonlu
      'BBB/USDT': { symbol: 'BBB/USDT', enabled: true, autonomousManaged: true }       // otonom, pozisyonsuz
    },
    autonomous: {
      active: true, stopping: false, status: 'running',
      managedSymbols: ['AAA/USDT', 'BBB/USDT'],
      manualEnabledSnapshot: { 'BTC/USDT': true, 'ETH/USDT': false },
      previousMaxConcurrentPositions: 3
    }
  };
}
const held = (sym) => sym === 'AAA/USDT';

test('acil durdurma: manuel parite ayarları ve pozisyon sınırı geri yüklenir (eskiden kapalı kalıyordu)', () => {
  const state = autonomousFixture(); state.settings.maxConcurrentPositions = 2;
  applyEmergencyStop(state, held, 'x');
  assert.equal(state.pairs['BTC/USDT'].enabled, true, 'manuel coin eski haline döner');
  assert.equal(state.pairs['ETH/USDT'].enabled, false);
  assert.equal(state.settings.maxConcurrentPositions, 3);
  assert.equal(state.autonomous.manualEnabledSnapshot, null);
  assert.equal(state.autonomous.status, 'emergency_stopped');
  assert.equal(state.autonomous.active, false);
});

test('acil durdurma: pozisyonsuz otonom parite silinir, pozisyonlu olan yönetilen listede kalır ve yeni alım yapmaz', () => {
  const state = autonomousFixture();
  applyEmergencyStop(state, held, 'x');
  assert.equal(state.pairs['BBB/USDT'], undefined);
  assert.equal(state.pairs['AAA/USDT'].enabled, false);
  assert.deepEqual(state.autonomous.managedSymbols, ['AAA/USDT']);
});

test('acil durdurmadan sonra otonom yeniden başlarsa manuel ayarlar kalıcı kaybolmaz (anlık görüntü doğru kalır)', () => {
  const state = autonomousFixture();
  applyEmergencyStop(state, held, 'x');
  // otonom yeniden başlarken anlık görüntü mevcut manuel durumdan alınır: BTC artık açık olduğu için doğru kaydedilir
  const snapshot = Object.fromEntries(Object.entries(state.pairs).filter(([, p]) => !p.autonomousManaged).map(([s, p]) => [s, p.enabled === true]));
  assert.deepEqual(snapshot, { 'BTC/USDT': true, 'ETH/USDT': false });
});

test('normal durdurma ile acil durdurma manuel ayarlarda aynı sonucu verir', () => {
  const a = autonomousFixture(); restoreManualPairs(a);
  const b = autonomousFixture(); applyEmergencyStop(b, () => false, 'x');
  assert.equal(a.pairs['BTC/USDT'].enabled, b.pairs['BTC/USDT'].enabled);
  assert.equal(a.settings.maxConcurrentPositions, b.settings.maxConcurrentPositions);
});

// ---- Canlı modda Telegram komutları (mod GEÇİŞİ yalnız panelden) ----
test('/basla CANLIDA tek başına başlatmaz: özet gösterir, /basla_onayla ile başlar, onay tek kullanımlıktır', async () => {
  const { say, calls } = make({ status: { mode: 'live', pairs: { 'BTC/USDT': { enabled: true, strategyId: 'rsi_ema_macd', timeframe: '1h' }, 'ETH/USDT': { enabled: true, strategyId: 'aggressive_breakout', timeframe: '1m' } } } });
  const first = await say('/basla');
  assert.equal(calls.start, 0);
  assert.match(first.text, /CANLI MOD/);
  assert.match(first.text, /BTC\/USDT/);
  assert.match(first.text, /kısa mum/);
  await say('/basla_onayla');
  assert.equal(calls.start, 1);
  const again = await say('/basla_onayla');
  assert.equal(calls.start, 1);
  assert.match(again.text, /Bekleyen canlı başlatma yok|zaten çalışıyor/);
});

test('/basla_onayla bekleyen istek olmadan, süre dolunca ve /iptal sonrası başlatmaz', async () => {
  const a = make({ status: { mode: 'live' } });
  await a.say('/basla_onayla'); assert.equal(a.calls.start, 0);
  const b = make({ status: { mode: 'live' } });
  await b.say('/basla'); await b.say('/iptal'); await b.say('/basla_onayla'); assert.equal(b.calls.start, 0);
  const realNow = Date.now; let t = 5_000_000; Date.now = () => t;
  try {
    const c = make({ status: { mode: 'live' } });
    await c.say('/basla'); t += 3 * 60 * 1000;
    const r = await c.say('/basla_onayla');
    assert.equal(c.calls.start, 0); assert.match(r.text, /süresi doldu/);
  } finally { Date.now = realNow; }
});

test('/basla_onayla mod bu arada paper olduysa canlı başlatma onayı geçersizdir', async () => {
  const { say, st, calls } = make({ status: { mode: 'live' } });
  await say('/basla'); st.mode = 'paper';
  const r = await say('/basla_onayla');
  assert.equal(calls.start, 0); assert.match(r.text, /canlı değil/);
});

test('/basla PAPERDA hâlâ hemen başlatır; otonom UI modu canlıda da engeller; başlatma hatası kullanıcıya iletilir', async () => {
  const p = make(); await p.say('/basla'); assert.equal(p.calls.start, 1);
  const a = make({ status: { mode: 'live', uiMode: 'autonomous' } });
  assert.match((await a.say('/basla')).text, /Otonom arayüz modu seçili/);
  const f = make({ status: { mode: 'live' }, deps: { startBot: async () => { throw new Error('Canlı kapı kapalı: kasa kilitli'); } } });
  await f.say('/basla');
  assert.match((await f.say('/basla_onayla')).text, /Bot başlatılamadı: Canlı kapı kapalı/);
});

test('canlıda /coin_ekle sihirbazı çalışır; özet CANLI uyarısı ve kısa mum uyarısı içerir; /onayla ile eklenir', async () => {
  const { say, calls } = make({ status: { mode: 'live', pairs: {}, settings: { defaultBudgetPct: 25 } }, deps: {
    listStrategies: () => [{ id: 'aggressive_breakout', name: 'Agresif Kırılım', defaultParams: { trailingStop: false } }],
    timeframes: ['1m', '3m', '5m', '15m', '30m', '1h', '4h'], validateTimeframe: () => null } });
  let r = await say('/coin_ekle PEPE/USDT'); assert.doesNotMatch(r.text, /yalnızca Paper/);
  await say('1'); await say('1m'); await say('10');
  r = await say('hayır');
  assert.match(r.text, /CANLI MOD/);
  assert.match(r.text, /Kısa mum \(1m\)/);
  assert.equal(calls.addPair, 0);
  r = await say('/onayla');
  assert.equal(calls.addPair, 1);
  assert.match(r.text, /CANLI listesine eklendi/);
});

test('canlıda /coin_sil: açık gerçek pozisyon varsa silmeyi baştan reddeder; yoksa onayla ile siler', async () => {
  const held = make({ status: { mode: 'live', pairs: { 'PEPE/USDT': { enabled: true } }, holdings: [{ symbol: 'PEPE/USDT', baseAsset: 'PEPE', quantity: 1000 }] } });
  const r = await held.say('/coin_sil PEPE/USDT');
  assert.match(r.text, /açık GERÇEK pozisyon/);
  await held.say('/onayla');
  assert.equal(held.calls.removePair, 0);
  const free = make({ status: { mode: 'live', pairs: { 'PEPE/USDT': { enabled: true } }, holdings: [] } });
  await free.say('/coin_sil PEPE/USDT');
  await free.say('/onayla');
  assert.equal(free.calls.removePair, 1);
});

test('canlıda /coin_durdur onaysız çalışır, /coin_ac onay ister (değişmedi)', async () => {
  const { say, calls } = make({ status: { mode: 'live', pairs: { 'PEPE/USDT': { enabled: true } } } });
  await say('/coin_durdur PEPE/USDT'); assert.equal(calls.setPairEnabled, 1);
  await say('/coin_ac PEPE/USDT'); assert.equal(calls.setPairEnabled, 1, 'onay beklenir');
  await say('/onayla'); assert.equal(calls.setPairEnabled, 2);
});

test('paper <-> canlı mod değiştiren bir Telegram komutu yoktur', async () => {
  const { say, st } = make({ status: { mode: 'paper' } });
  for (const cmd of ['/canli', '/live', '/paper', '/mod canli', '/mod paper', '/mod live']) await say(cmd);
  assert.equal(st.mode, 'paper');
});
