'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildPerformanceReport, periodBounds, createPerformanceScheduler } = require('../src/performanceReports');
test('haftalık rapor gerçekleşmiş ve gerçekleşmemiş K/Z tutarlarını ayrı tutar', () => {
  const now=Date.parse('2026-10-31T12:00:00+03:00');
  const b=periodBounds('weekly',now);
  const trades=[{symbol:'BTC/USDT',strategyId:'rsi',pnl:12,commissionTotal:.2,commissionQuoteTotal:.2,closedAt:new Date(b.start+1000).toISOString()},{symbol:'ETH/USDT',strategyId:'ema',pnl:-2,closedAt:new Date(b.start-1000).toISOString()}];
  const text=buildPerformanceReport({trades,holdings:[{unrealizedPnl:3}],quoteAsset:'USDT',mode:'paper',period:'weekly',now});
  assert.match(text,/Gerçekleşmiş K\/Z: \+12\.00 USDT/);
  assert.match(text,/Açık pozisyon gerçekleşmemiş K\/Z: \+3\.00 USDT/);
  assert.match(text,/Kapanan işlem: 1/);
  assert.match(text,/Quote karşılığı kayıtlı komisyon: 0\.2000 USDT/);
});
test('coin ve strateji kırılımı gruplu sonuç üretir',()=>{
  const trades=[{symbol:'BTC/USDT',strategyId:'rsi',pnl:5,closedAt:'2026-10-30T00:00:00Z'},{symbol:'BTC/USDT',strategyId:'rsi',pnl:-1,closedAt:'2026-10-30T01:00:00Z'}];
  assert.match(buildPerformanceReport({trades,group:'coin'}),/BTC\/USDT: 2 işlem/);
  assert.match(buildPerformanceReport({trades,group:'strategy'}),/rsi: 2 işlem/);
});

test('haftalık performans zamanlayıcısı aynı hafta içinde tekrarlı göndermez', async () => {
  const now=Date.parse('2026-11-02T23:55:00+03:00'); const state={notifyMeta:{}}; let sent=0, saved=0;
  const scheduler=createPerformanceScheduler({getData:()=>({trades:[],holdings:[],quoteAsset:'USDT',mode:'paper'}),notifier:{send:async()=>{sent++;return {telegram:true};},status:()=>({telegram:true,termux:false})},state,store:{save:()=>{saved++;}},env:{PERFORMANCE_SUMMARIES:'1',PERFORMANCE_SUMMARY_TIME:'23:55'},nowFn:()=>now});
  assert.equal(scheduler.tick(),true); await new Promise(r=>setImmediate(r)); assert.equal(sent,1); assert.equal(saved,1);
  assert.equal(scheduler.tick(),false); assert.equal(sent,1);
});

test('aylık performans zamanlayıcısı yalnızca ayın son gününde bir kez gönderir', async () => {
  const now=Date.parse('2026-11-30T23:55:00+03:00'); const state={notifyMeta:{}}; let sent=0;
  const scheduler=createPerformanceScheduler({getData:()=>({trades:[],holdings:[],quoteAsset:'USDT',mode:'paper'}),notifier:{send:async()=>{sent++;return {telegram:true};},status:()=>({telegram:true,termux:false})},state,store:{save(){}},env:{PERFORMANCE_SUMMARIES:'1',PERFORMANCE_SUMMARY_TIME:'23:55'},nowFn:()=>now});
  scheduler.tick(); await new Promise(r=>setImmediate(r)); assert.equal(sent,2); assert.equal(state.notifyMeta.lastMonthlyPerformance,'2026-11');
});
