'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { addWatchOnlyPairs, removeUnheldAutonomousPairs, applyEmergencyStop } = require('../src/autonomousState');

test('satılmış otonom coin Ayarlar listesinden çıkarılır', () => {
  const state = { pairs: { 'AAA/USDT': { enabled: true, autonomousManaged: true } },
    autonomous: { managedSymbols: ['AAA/USDT'] } };
  removeUnheldAutonomousPairs(state, () => false);
  assert.equal(state.pairs['AAA/USDT'], undefined);
});

test('acil durdurma açık pozisyonu korur, satılmış otonom coinleri listeden çıkarır', () => {
  const state = { settings: {}, pairs: { 'AAA/USDT': { enabled: true, autonomousManaged: true },
    'BBB/USDT': { enabled: true, autonomousManaged: true } },
    autonomous: { managedSymbols: ['AAA/USDT', 'BBB/USDT'], manualEnabledSnapshot: {}, previousMaxConcurrentPositions: 3 } };
  applyEmergencyStop(state, (symbol) => symbol === 'AAA/USDT', 'test');
  assert.equal(state.pairs['AAA/USDT'].enabled, false);
  assert.equal(state.pairs['AAA/USDT'].autonomousManaged, true);
  assert.equal(state.pairs['BBB/USDT'], undefined);
});



test('güvenli kapanış tamamlanınca otonom oturumu yeniden başlatılabilir idle duruma döner', () => {
  const { restoreManualPairs } = require('../src/autonomousState');
  const state = {
    settings: { maxConcurrentPositions: 32 },
    pairs: { 'AAA/USDT': { enabled: false, autonomousManaged: true } },
    autonomous: {
      active: false, stopping: true, status: 'closing_positions',
      managedSymbols: [], manualEnabledSnapshot: { 'AAA/USDT': true },
      previousMaxConcurrentPositions: 4
    }
  };
  restoreManualPairs(state);
  assert.equal(state.autonomous.active, false);
  assert.equal(state.autonomous.stopping, false);
  assert.equal(state.autonomous.status, 'idle');
  assert.equal(state.autonomous.managedSymbols.length, 0);
  assert.equal(state.pairs['AAA/USDT'].enabled, true);
  assert.equal(state.settings.maxConcurrentPositions, 4);
});
