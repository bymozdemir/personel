'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const sel = require('../src/autonomousSelection');
const store = require('../src/store');
const strategies = require('../src/strategies');
const LiveEngine = require('../src/liveEngine');
const { scanBuyCandidates } = require('../src/autonomousScanner');

const AGG = 'aggressive_breakout';

test('varsayılan: 19 stratejinin 18\'i açık, Agresif kapalı; mum aralıkları 15m-4h', () => {
  assert.equal(sel.allStrategyIds().length, 19);
  const d = sel.resolve(null);
  assert.equal(d.strategyIds.length, 18);
  assert.ok(!d.strategyIds.includes(AGG));
  assert.deepEqual(d.timeframes, ['15m', '30m', '1h', '4h']);
  assert.equal(d.customStrategies, false);
  assert.equal(store.defaultState().autonomous.strategyIds, null);
});

test('görünüm: 19 strateji (adlarıyla), 7 mum aralığı; 1m/3m/5m kilitli ve seçili değil', () => {
  const v = sel.view(null);
  assert.equal(v.strategies.length, 19);
  assert.ok(v.strategies.every((x) => x.name && x.id));
  assert.equal(v.strategies.find((x) => x.id === AGG).selected, false);
  assert.equal(v.strategies.filter((x) => x.selected).length, 18);
  assert.deepEqual(v.timeframes.map((x) => x.id), ['1m', '3m', '5m', '15m', '30m', '1h', '4h']);
  for (const x of v.timeframes) assert.equal(x.locked, ['1m', '3m', '5m'].includes(x.id)), assert.equal(x.selected, !x.locked);
});

test('kayıtlı seçim etkin seçime yansır; bozuk/boş kayıt varsayılana düşer', () => {
  const ids = sel.allStrategyIds();
  const r = sel.resolve({ strategyIds: [ids[2], ids[0], 'yok', ids[0]], timeframes: ['4h', '15m', '1m', 'x'] });
  assert.deepEqual(r.strategyIds, [ids[0], ids[2]], 'sıra kayıt sırasına değil strateji listesine göre, yinelenen/bilinmeyen atılır');
  assert.deepEqual(r.timeframes, ['15m', '4h'], 'kısa mum kayıtlı olsa bile otonomda kullanılmaz');
  assert.equal(r.customStrategies, true);
  for (const bad of [{ strategyIds: [] }, { strategyIds: 'x' }, { strategyIds: ['yok'] }, { timeframes: ['1m', '3m'] }, { strategyIds: [1, 2] }, undefined, {}]) {
    const d = sel.resolve(bad);
    assert.equal(d.strategyIds.length, 18); assert.deepEqual(d.timeframes, ['15m', '30m', '1h', '4h']);
  }
  // Agresif isteyerek işaretlenirse açık kalır
  assert.ok(sel.resolve({ strategyIds: [AGG] }).strategyIds.includes(AGG));
});

test('doğrulama: boş liste, bilinmeyen strateji, kısa mum ve bozuk gövde reddedilir', () => {
  const ids = sel.allStrategyIds();
  assert.equal(sel.validate({ strategyIds: [ids[0]], timeframes: ['1h'] }).ok, true);
  assert.match(sel.validate({ strategyIds: [], timeframes: ['1h'] }).error, /En az bir strateji/);
  assert.match(sel.validate({ strategyIds: [ids[0]], timeframes: [] }).error, /En az bir mum/);
  assert.match(sel.validate({ strategyIds: ['yok'], timeframes: ['1h'] }).error, /Bilinmeyen strateji/);
  for (const tf of ['1m', '3m', '5m']) assert.match(sel.validate({ strategyIds: [ids[0]], timeframes: [tf, '1h'] }).error, /yalnızca manuel/);
  assert.match(sel.validate({ strategyIds: [ids[0]], timeframes: ['2h'] }).error, /Geçersiz mum/);
  for (const body of [null, {}, { strategyIds: 'x', timeframes: 'y' }, { strategyIds: [1], timeframes: ['1h'] }]) assert.equal(sel.validate(body).ok, false);
  const ok = sel.validate({ strategyIds: [ids[3], ids[1], ids[3]], timeframes: ['1h', '15m'] });
  assert.deepEqual(ok.strategyIds, [ids[1], ids[3]]); assert.deepEqual(ok.timeframes, ['15m', '1h']);
});

test('tarayıcı yalnızca işaretli stratejileri ve mum aralıklarını dener', async () => {
  const requested = [];
  const exchange = { quoteAssets: ['USDT'],
    async fetchAllTickers24h() { return [{ symbol: 'BTC/USDT', lastPrice: 100, quoteVolume: 1000000 }]; },
    async fetchCandles(symbol, timeframe) { requested.push(timeframe); throw new Error('offline fixture'); } };
  const r = await scanBuyCandidates({ exchange, quoteAsset: 'USDT', mode: 'live', exchangeId: 'binance', pollSeconds: 60, strategyIds: ['rsi_ema_macd'], timeframes: ['1h', '4h'] });
  assert.deepEqual([...new Set(requested)].sort(), ['1h', '4h']);
  assert.equal(r.strategiesTested, 1);
  assert.deepEqual(r.timeframesTested.sort(), ['1h', '4h']);
  // kısıt yoksa (null) tüm stratejiler denenir
  const all = await scanBuyCandidates({ exchange, quoteAsset: 'USDT', mode: 'live', exchangeId: 'binance', pollSeconds: 60 });
  assert.equal(all.strategiesTested, 19);
});

test('Agresif işaretlenirse otonom 15m ve üstünde onu da dener; 5m yine hiç denenmez', async () => {
  const requested = [];
  const exchange = { quoteAssets: ['USDT'],
    async fetchAllTickers24h() { return [{ symbol: 'BTC/USDT', lastPrice: 100, quoteVolume: 1000000 }]; },
    async fetchCandles(symbol, timeframe) { requested.push(timeframe); throw new Error('offline fixture'); } };
  const r = await scanBuyCandidates({ exchange, quoteAsset: 'USDT', mode: 'paper', exchangeId: 'binance', pollSeconds: 15, strategyIds: [AGG], timeframes: ['15m', '30m', '1h', '4h'] });
  assert.equal(r.strategiesTested, 1);
  assert.deepEqual([...new Set(requested)].sort(), ['15m', '1h', '30m', '4h'].sort());
});

test('sahiplenilen coin, kullanıcının otonom için seçtiği strateji ve mum aralığını kullanır', async () => {
  const NOW = Date.UTC(2026, 9, 29, 12, 0);
  const mk = (autonomousExtra) => {
    const state = store.defaultState(); state.settings.mode = 'live'; state.pairs = {};
    Object.assign(state.autonomous, { active: true, managedSymbols: [] }, autonomousExtra);
    state.live.safeToTrade = true;
    state.live.lastBalance = { USDT: { free: 1, locked: 0, total: 1 }, XRP: { free: 100, locked: 0, total: 100 } };
    state.live.externalInventoryByAsset = { XRP: { asset: 'XRP', symbol: 'XRP/USDT', quote: 'USDT', referencePrice: 0.5, currentPrice: 0.5 } };
    state.live.assetPricesByQuote = { USDT: { XRP: 0.5 } }; state.live.assetPricesAt = new Date(NOW).toISOString();
    const ex = { id: 'binance', environment: 'production', quoteAssets: ['USDT'], capabilities: { clientOrderId: true, orderQuery: true, balanceQuery: true, openOrdersQuery: true, userDataStream: true, oco: false, marketOrderBook: true },
      async fetchBalance() { return state.live.lastBalance; }, async fetchOpenOrders() { return []; }, async fetchTicker() { return { price: 0.5 }; }, async fetchSymbolRules() { return { stepSize: 0.1, minQty: 0.1, minNotional: 5 }; } };
    return { state, engine: new LiveEngine({ exchange: ex, state, store: { save() {} }, allowLive: true, nowFn: () => NOW }) };
  };
  const ids = sel.allStrategyIds();
  const none = mk({}); await none.engine._adoptExistingHoldings();
  assert.equal(none.state.pairs['XRP/USDT'].strategyId, 'trend_regime', 'seçim yoksa varsayılan trend stratejisi (rsi_ema_macd değil)');
  assert.equal(none.state.pairs['XRP/USDT'].timeframe, '1h');
  const custom = mk({ strategyIds: [ids[4]], timeframes: ['4h'] }); await custom.engine._adoptExistingHoldings();
  assert.equal(custom.state.pairs['XRP/USDT'].strategyId, ids[4]);
  assert.equal(custom.state.pairs['XRP/USDT'].timeframe, '4h');
  assert.notEqual(strategies.get(ids[4]).id, 'rsi_ema_macd');
});

test('görünüm: her strateji panelde açıklamasıyla gelir (otonom sekmesi neyi işaretlediğini göstersin)', () => {
  const v = sel.view(null);
  assert.ok(v.strategies.every((x) => typeof x.description === 'string'));
  assert.ok(v.strategies.filter((x) => x.description.length > 10).length >= 15, 'çoğu stratejinin anlamlı açıklaması var');
});
