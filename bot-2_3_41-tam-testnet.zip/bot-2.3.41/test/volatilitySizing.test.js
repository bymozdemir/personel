const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const strategies = require('../src/strategies');
const { volatilitySizeScale, normalizeVolatilitySizing } = require('../src/volatilitySizing');
const { defaultExtras, validateExtrasPatch, normalizeExtras } = require('../src/entryExtras');
const { runPortfolioBacktest } = require('../src/backtest/portfolioSimulator');
const { flat, makeEngine, onlyPair, store } = require('./helpers');

const H = 3600000;
const bars = (n, hi, lo) => Array.from({ length: n }, (_, i) => ({ t: i * H, o: 100, h: hi, l: lo, c: 100, v: 5 }));

test('volatilitySizeScale: kapaliyken/verisizken 1; oynakta kucultur ama minScale altina inmez; sakinde asla buyutmez', () => {
  const on = { enabled: true, targetAtrPct: 1.5, minScale: 0.25 };
  assert.equal(volatilitySizeScale(bars(50, 110, 90), { enabled: false }), 1);
  assert.equal(volatilitySizeScale(bars(5, 110, 90), on), 1);                 // yetersiz veri
  assert.equal(volatilitySizeScale(bars(50, 100, 100), on), 1);               // ATR 0 -> hesaplanamaz
  assert.equal(volatilitySizeScale(bars(50, 110, 90), on), 0.25);             // %20 ATR -> alt sinir
  const mid = volatilitySizeScale(bars(50, 103, 97), { ...on, minScale: 0.01 }); // ~%6 ATR
  assert.ok(mid > 0.2 && mid < 0.3, String(mid));
  assert.equal(volatilitySizeScale(bars(50, 100.5, 99.5), on), 1);            // %1 ATR < hedef -> 1 (buyutme yok)
  assert.deepEqual(normalizeVolatilitySizing({ enabled: 'x', minScale: 5 }), { enabled: false, targetAtrPct: 1.5, atrPeriod: 14, minScale: 0.25 });
});

function withStrategy(id, evaluate, fn) {
  const reg = strategies.registry; const orig = reg[id];
  reg[id] = { ...orig, evaluate };
  return Promise.resolve(fn()).finally(() => { reg[id] = orig; });
}
async function paperCost(enabled) {
  const state = store.defaultState(); state.running = true; onlyPair(state);
  state.settings.volatilitySizing = { enabled, targetAtrPct: 1.5, minScale: 0.25 };
  const volatile = flat(300, 100).map((c) => ({ ...c, t: c.t - H, h: 110, l: 90 })).concat([{ t: Date.now(), o: 100, h: 100, l: 100, c: 100, v: 1 }]);
  const ex = { quoteAssets: ['USDT'], fetchCandles: async () => volatile, fetchSymbolRules: async () => ({ minNotional: 1 }) };
  const { engine } = makeEngine({ state, exchange: ex });
  await withStrategy('rsi_ema_macd', () => ({ action: 'buy', reason: 't', price: 100 }), () => engine.tick());
  const pos = Object.values(state.paper.positions)[0];
  return pos ? Number(pos.costQuote ?? pos.costUSDT) : 0;
}

test('paper motor: oynak parite icin alim tutari olceklenir (yaklasik %25), kapaliyken tam', async () => {
  const full = await paperCost(false);
  const scaled = await paperCost(true);
  assert.ok(full > 0 && scaled > 0);
  assert.ok(Math.abs(scaled / full - 0.25) < 0.02, `oran ${scaled / full}`);
});

test('portfoy backtest: volatilite olcegi pozisyon maliyetini kucultur', () => {
  const mk = (hi, lo) => Array.from({ length: 80 }, (_, i) => ({ t: 1_700_000_000_000 + i * H, o: 100, h: hi, l: lo, c: 100, v: 5 }));
  const holder = { id: 'h', defaultParams: { stopLossPct: 50 }, minCandles: () => 5, evaluate: ({ position }) => (position ? { action: 'hold', reason: 'tut' } : { action: 'buy', reason: 'gir' }) };
  const run = (extras) => runPortfolioBacktest({ datasets: { 'A/USDT': { candles: mk(110, 90) } }, symbols: ['A/USDT'], startIndex: 30, endIndex: 79, strategy: holder, params: holder.defaultParams, capital: 1000, maxConcurrentPositions: 1, budgetPct: 50, extras });
  const base = run({}), scaled = run({ volatilitySizing: { enabled: true, targetAtrPct: 1.5, minScale: 0.25 } });
  const cost = (r) => r.tradeList[0].exitPrice * 0 + Math.abs(r.tradeList[0].pnl / r.tradeList[0].pnlPct * 100);
  assert.ok(Math.abs(cost(scaled) / cost(base) - 0.25) < 0.01);
});

test('ayar yamasi dogrulamasi volatilitySizing icin de gecerli', () => {
  const cur = normalizeExtras({});
  assert.equal(validateExtrasPatch({ volatilitySizing: { enabled: true } }, cur).value.volatilitySizing.enabled, true);
  assert.match(validateExtrasPatch({ volatilitySizing: { minScale: 'x' } }, cur).error, /volatilitySizing\.minScale/);
});

test('canli motor ozkaynak orneklemesi: 5 dk sinirli, 500 ile kisitli, bozuk veriyi atlar', () => {
  const LiveEngine = require('../src/liveEngine');
  let t = 1_000_000;
  const self = { state: { live: {} }, nowFn: () => t };
  const rec = (eq) => LiveEngine.prototype._recordEquitySample.call(self, eq);
  rec({ USDT: 100 }); rec({ USDT: 101 });                 // 5 dk dolmadi -> ikincisi atlanir
  assert.equal(self.state.live.equityHistoryByQuote.USDT.length, 1);
  t += 301000; rec({ USDT: 102, TRY: NaN, BTC: 0 });
  assert.equal(self.state.live.equityHistoryByQuote.USDT.length, 2);
  assert.equal(self.state.live.equityHistoryByQuote.TRY, undefined);
  for (let i = 0; i < 600; i++) { t += 301000; rec({ USDT: 100 + i }); }
  assert.equal(self.state.live.equityHistoryByQuote.USDT.length, 500);
  assert.doesNotThrow(() => rec(null));
});

test('panel alanlari ile sunucu varsayilanlari/dogrulayicisi birbirinden kopmaz', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.js'), 'utf8');
  const start = src.indexOf('const EXTRAS_GROUPS = ');
  const end = src.indexOf('];\nconst xid', start);
  assert.ok(start >= 0 && end > start, 'EXTRAS_GROUPS bulunamadi');
  const groups = vm.runInNewContext(src.slice(start + 'const EXTRAS_GROUPS = '.length, end + 1));
  const defaults = defaultExtras();
  const getPath = (o, p) => p.split('.').reduce((a, k) => (a && typeof a === 'object' ? a[k] : undefined), o);
  const body = {};
  let count = 0;
  for (const [, fields] of groups) for (const [p, type] of fields) {
    count++;
    const v = getPath(defaults, p);
    assert.ok(v !== undefined, `${p}: sunucu varsayilaninda yok`);
    assert.equal(typeof v, type === 'bool' ? 'boolean' : 'number', `${p}: tur uyusmuyor`);
    const keys = p.split('.'); let o = body;
    keys.slice(0, -1).forEach((k) => { o[k] = o[k] || {}; o = o[k]; });
    o[keys.at(-1)] = v;
  }
  assert.ok(count >= 25);
  const r = validateExtrasPatch(body, defaults);
  assert.equal(r.error, undefined, r.error);
  assert.deepEqual(r.value.protections, defaults.protections); // panel -> sunucu gidis-donus kaybi yok
  assert.deepEqual(r.value.volatilitySizing, defaults.volatilitySizing);
});
