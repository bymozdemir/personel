'use strict';
// Yeni Telegram komutlari ve canli-farkinda yanitlar.
const test = require('node:test');
const assert = require('node:assert/strict');
const { createTelegramCommands } = require('../src/telegramCommands');

const env = { TELEGRAM_BOT_TOKEN: '123:ABC', TELEGRAM_CHAT_ID: '42' };
const NOW = Date.UTC(2026, 9, 19, 12, 0);

function make({ status = {}, deps = {}, failHtml = false } = {}) {
  const requests = [];
  const fetchFn = async (url, opts) => {
    const body = JSON.parse(opts.body);
    requests.push(body);
    if (failHtml && body.parse_mode) return { ok: false, status: 400, json: async () => ({ ok: false, description: "Bad Request: can't parse entities: Unsupported start tag" }) };
    return { ok: true, status: 200, json: async () => ({ ok: true, result: [] }) };
  };
  const st = { mode: 'paper', running: true, killSwitch: false, exchange: 'binance', quoteAsset: 'USDT', cash: 150, positions: 0, holdings: [], settings: {}, recentLog: [], ...status };
  const bot = createTelegramCommands({
    env, fetchFn, logger: { log() {}, warn() {} }, getStatus: () => st,
    startBot: async () => { st.running = true; }, stopBot: async () => { st.running = false; }, ...deps
  });
  const say = async (text) => { await bot.processUpdate({ message: { chat: { id: 42 }, text } }); return requests.at(-1); };
  return { bot, requests, st, say };
}

test('/pozisyonlar paper: giris, guncel fiyat, K/Z, stop ve sure gosterilir', async () => {
  const { say } = make({ status: { positions: 1, holdings: [{ symbol: 'BTC/USDT', baseAsset: 'BTC', quoteAsset: 'USDT', quantity: 0.5, entryPrice: 100, lastPrice: 110, unrealizedPnl: 5, unrealizedPct: 10, stopPrice: 95, openedAt: new Date(Date.now() - 90 * 60000).toISOString() }] } });
  const r = await say('/pozisyonlar');
  assert.equal(r.parse_mode, 'HTML');
  assert.match(r.text, /AÇIK POZİSYONLAR \(1\) — PAPER/);
  assert.match(r.text, /<b>BTC\/USDT<\/b>: <code>0\.5<\/code> BTC/);
  assert.match(r.text, /Giriş <code>100<\/code> → Şimdi <code>110<\/code> \(\+10\.00%, \+5\.00 USDT\) 🟢/);
  assert.match(r.text, /Stop <code>95<\/code> \(-13\.6%\)/);
  assert.match(r.text, /Süre 1s 30dk/);
  assert.match(r.text, /Toplam açık K\/Z: <b>\+5\.00 USDT<\/b>/);
  assert.doesNotMatch(r.text, /borsada stop emri/);
});

test('/pozisyonlar canli: korumali ve korumasiz pozisyonu ayirir; pozisyon yoksa bunu soyler', async () => {
  const { say } = make({ status: { mode: 'live', holdings: [
    { symbol: 'SOL/USDT', baseAsset: 'SOL', quoteAsset: 'USDT', quantity: 2, entryPrice: 50, lastPrice: 55, unrealizedPnl: 10, unrealizedPct: 10, protected: true },
    { symbol: 'ADA/USDT', baseAsset: 'ADA', quoteAsset: 'USDT', quantity: 10, entryPrice: 1, unrealizedPnl: undefined }
  ] } });
  const r = await say('/pozisyonlar');
  assert.match(r.text, /CANLI/);
  assert.match(r.text, /🛡 borsada stop emri var/);
  assert.match(r.text, /⚠ stop emri kaydı yok/);
  const empty = await make({}).say('/pozisyonlar');
  assert.match(empty.text, /Açık pozisyon yok/);
});

test('/loglar: varsayilan 10, "hata" yalniz hata/uyari, sayi en fazla 25, HTML kacirilir', async () => {
  const recentLog = Array.from({ length: 40 }, (_, i) => ({ t: new Date(NOW - i * 60000).toISOString(), msg: i === 3 ? 'hata <x> & y' : `kayıt ${i}`, level: i % 5 === 3 ? 'error' : i % 5 === 4 ? 'warn' : 'info' }));
  const { say } = make({ status: { recentLog } });
  const def = await say('/loglar');
  assert.match(def.text, /SON 10 LOG/);
  assert.equal(def.text.split('\n').filter((l) => /^[🔴🟡⚪]/u.test(l)).length, 10);
  assert.match(def.text, /hata &lt;x&gt; &amp; y/);
  const err = await say('/loglar hata');
  assert.match(err.text, /yalnızca hata\/uyarı/);
  assert.ok(err.text.split('\n').filter((l) => /^[🔴🟡⚪]/u.test(l)).every((l) => /^[🔴🟡]/u.test(l)));
  const many = await say('/loglar 100');
  assert.match(many.text, /SON 25 LOG/);
  const none = await make({ status: { recentLog: [{ t: 'x', msg: 'bilgi', level: 'info' }] } }).say('/loglar hata');
  assert.match(none.text, /Kayıtlı hata\/uyarı yok/);
});

test('/ayarlar: risk limitleri, bildirim kanallari, sessiz mod ve gunluk ozet saati', async () => {
  const { say } = make({
    status: { mode: 'live', settings: { pollSeconds: 60, dailyLossLimitPct: 5, killSwitchLossPct: 25, maxConcurrentPositions: 3, reserveCashPct: 10, maxTradeQuote: 0, maxOpenOrders: 12, timeframe: '1h' }, pairs: { 'BTC/USDT': { enabled: true }, 'ETH/USDT': { enabled: false } } },
    deps: { getNotifyInfo: () => ({ telegram: true, termux: false, healthcheck: true, muted: true, mutedUntil: NOW, dailySummary: { enabled: true, time: '23:55' }, channels: { telegram: { failures: 3 } } }) }
  });
  const r = await say('/ayarlar');
  assert.match(r.text, /AYARLAR \(salt-okunur\) — CANLI/);
  assert.match(r.text, /Günlük zarar limiti: 5% \| Kill switch \(toplam zarar\): 25%/);
  assert.match(r.text, /İşlem üst sınırı: sınırsız \| Açık emir üst sınırı: 12/);
  assert.match(r.text, /Takip edilen coin: 2 \(aktif 1\)/);
  assert.match(r.text, /Telegram ✅ \| Termux ❌ \| Nabız \(healthcheck\) ✅/);
  assert.match(r.text, /Sessiz mod: AÇIK/);
  assert.match(r.text, /Günlük özet: açık, her gün 23:55/);
  assert.match(r.text, /Telegram bildirim gönderimi son zamanlarda 3 kez başarısız/);
});

test('/sessiz: saat verir, durum gosterir, kapatir; gecersiz degeri reddeder; kritik uyarilar sesli kalir', async () => {
  const calls = [];
  let muted = null;
  const deps = {
    muteNotifications: ({ hours }) => { calls.push(hours); muted = NOW + hours * 3600000; return muted; },
    unmuteNotifications: () => { calls.push('unmute'); muted = null; },
    getNotifyInfo: () => ({ muted: Boolean(muted), mutedUntil: muted })
  };
  const { say } = make({ deps });
  let r = await say('/sessiz');
  assert.deepEqual(calls, [2]);
  assert.match(r.text, /Sessiz mod 2 saat açık/);
  assert.match(r.text, /KRİTİK uyarılar .* yine sesli/);
  r = await say('/sessiz 0,5');
  assert.deepEqual(calls, [2, 0.5]);
  r = await say('/sessiz durum');
  assert.match(r.text, /Sessiz mod AÇIK, bitiş:/);
  r = await say('/sessiz kapat');
  assert.deepEqual(calls.at(-1), 'unmute');
  assert.match(r.text, /Sessiz mod kapatıldı/);
  r = await say('/sessiz durum');
  assert.match(r.text, /Sessiz mod kapalı/);
  for (const bad of ['0', '99', 'abc', '-3']) {
    const before = calls.length;
    r = await say(`/sessiz ${bad}`);
    assert.match(r.text, /Kullanım: \/sessiz/);
    assert.equal(calls.length, before, `${bad} icin sessiz mod acilmamali`);
  }
  const nodeps = await make({}).say('/sessiz');
  assert.match(nodeps.text, /kullanılamıyor/);
});

test('/ozet gunluk ozeti HTML olarak gonderir; uretilemezse hata mesaji verir', async () => {
  const ok = await make({ deps: { getDailySummaryText: async () => '📅 <b>GÜNLÜK ÖZET</b>\nx' } }).say('/ozet');
  assert.equal(ok.parse_mode, 'HTML'); assert.match(ok.text, /GÜNLÜK ÖZET/);
  const bad = await make({ deps: { getDailySummaryText: async () => { throw new Error('veri yok'); } } }).say('/ozet');
  assert.match(bad.text, /Özet oluşturulamadı: veri yok/);
  assert.match((await make({}).say('/özet')).text, /kullanılamıyor/);
});

test('/durum /bakiye /rapor CANLI modda canli etiketleri ve kilit bilgisini gosterir', async () => {
  const live = { mode: 'live', running: true, cash: 420, totalEquity: 477, positions: 1, safeToTrade: false, lockReason: 'User Data Stream bağlı değil', lastTickAt: NOW - 20000, lastReconcileAt: '2026-10-19T11:55:00.000Z',
    holdings: [{ symbol: 'SOL/USDT', baseAsset: 'SOL', quoteAsset: 'USDT', quantity: 2, marketValue: 110, costQuote: 100 }], stats: { trades: 10, wins: 6, grossWin: 30, grossLoss: 12 }, startingBalance: 400 };
  const { say } = make({ status: live });
  let r = await say('/durum');
  assert.match(r.text, /Canlı nakit \(kullanılabilir\): 420\.00 USDT/);
  assert.match(r.text, /Tahmini özkaynak: 477 USDT/);
  assert.match(r.text, /Canlı işlem kapısı: KİLİTLİ — User Data Stream bağlı değil/);
  assert.match(r.text, /Son kontrol turu \(İstanbul\)/);
  assert.doesNotMatch(r.text, /Paper nakit/);
  r = await say('/bakiye');
  assert.match(r.text, /CANLI BAKİYE \/ VARLIKLAR/);
  assert.match(r.text, /borsa bakiyesi ve botun canlı pozisyon kayıtlarından/);
  assert.match(r.text, /son mutabakat: /);
  r = await say('/rapor');
  assert.match(r.text, /CANLI RAPOR/);
  assert.match(r.text, /Canlı hesabın gerçekleşen işlemleri/);
  const open = await make({ status: { ...live, safeToTrade: true } }).say('/durum');
  assert.match(open.text, /Canlı işlem kapısı: AÇIK \(güvenli\)/);
  const paper = await make({}).say('/durum');
  assert.match(paper.text, /Paper nakit: 150\.00 USDT/);
});

test('uzun yanit 4096 siniri icin bolunur (cok coinli /coinler listesi)', async () => {
  const pairs = {};
  for (let i = 0; i < 160; i++) pairs[`COIN${i}/USDT`] = { symbol: `COIN${i}/USDT`, enabled: true, strategyId: 'rsi_ema_macd', timeframe: '1h', budgetPct: 5, params: { stopLossPct: 3, takeProfitPct: 6 } };
  const { say, requests } = make({ status: { pairs } });
  await say('/coinler');
  assert.ok(requests.length >= 2, `parca sayisi ${requests.length}`);
  for (const q of requests) assert.ok(q.text.length <= 4010);
  assert.match(requests[0].text, /^\(1\/\d+\) /);
});

test('Telegram HTML etiketini reddederse yanit etiketsiz duz metin olarak yeniden gonderilir', async () => {
  const { say, requests } = make({ failHtml: true, status: { positions: 0 } });
  await say('/pozisyonlar');
  assert.equal(requests.length, 2);
  assert.equal(requests[0].parse_mode, 'HTML');
  assert.equal(requests[1].parse_mode, undefined);
  assert.doesNotMatch(requests[1].text, /<b>|<code>/);
  assert.match(requests[1].text, /AÇIK POZİSYONLAR/);
});

test('/bitir açık pozisyon varsa paper/canlı fark etmeksizin motoru durdurmayı reddeder', async () => {
  const live = make({ status: { mode: 'live', running: true, positions: 1 } });
  const r = await live.say('/bitir');
  assert.match(r.text, /Motor durdurulmadı: 1 açık pozisyon var/);
  assert.match(r.text, /\/emirler ile ayrıca doğrula/);
  const paper = await make({ status: { mode: 'paper', running: true, positions: 1 } }).say('/bitir');
  assert.match(paper.text, /Motor durdurulmadı/);
});

test('yardim yeni komutlari listeler; yetkisiz chat yeni komutlara yanit alamaz', async () => {
  const { say, bot, requests } = make({});
  const h = await say('/yardim');
  for (const c of ['/pozisyonlar', '/loglar', '/ayarlar', '/ozet', '/sessiz']) assert.match(h.text, new RegExp(c));
  const n = requests.length;
  assert.equal(await bot.processUpdate({ message: { chat: { id: 7 }, text: '/sessiz 5' } }), false);
  assert.equal(await bot.processUpdate({ message: { chat: { id: 7 }, text: '/pozisyonlar' } }), false);
  assert.equal(requests.length, n);
});

test('/mod manuel ve /mod otonom yalnızca arayüz modunu değiştirir; botu başlatmaz', async () => {
  const calls = [];
  const { say, st } = make({ status: { uiMode: 'manual', mode: 'paper', running: false }, deps: { setUiMode: async (mode) => { calls.push(mode); st.uiMode = mode; return { message: 'Seçim kaydedildi.' }; } } });
  const auto = await say('/mod otonom');
  assert.match(auto.text, /OTONOM arayüz modu seçildi/);
  assert.match(auto.text, /botu başlatmaz/);
  assert.equal(st.running, false);
  const manual = await say('/mod manuel');
  assert.match(manual.text, /MANUEL arayüz modu seçildi/);
  assert.deepEqual(calls, ['autonomous', 'manual']);
  const help = await say('/mod');
  assert.match(help.text, /MOD DURUMU/);
  assert.match(help.text, /Manuel Kağıt/);
});


test('yeni dört mod komutu 2 dakika onay ister; mod seçimi motoru başlatmaz', async () => {
  const calls = [];
  const { say, st } = make({ status: { uiMode: 'manual', mode: 'paper', running: false }, deps: {
    setTradingMode: async mode => { calls.push(`trade:${mode}`); st.mode = mode; },
    setUiMode: async mode => { calls.push(`ui:${mode}`); st.uiMode = mode; }
  } });
  let r = await say('/mod_live');
  assert.match(r.text, /HENÜZ UYGULANMADI/);
  assert.deepEqual(calls, []);
  r = await say('/mod_onay');
  assert.match(r.text, /Canlı modu seçildi/);
  assert.deepEqual(calls, ['trade:live']);
  assert.equal(st.running, false);
  r = await say('/mod_paper');
  await say('/iptal');
  assert.deepEqual(calls, ['trade:live']);
});

test('/mod_oto strateji ve yalnızca 15m+ mum seçimini onaydan sonra kaydeder; motoru başlatmaz', async () => {
  const strategies = Array.from({length:19}, (_,i)=>({id:`s${i+1}`,name:`Strateji ${i+1}`}));
  const calls = [];
  const { say, st } = make({ status: { uiMode:'manual', mode:'paper', running:false, settings:{maxConcurrentPositions:4} }, deps: {
    listStrategies: () => strategies,
    setAutonomousSelection: async x => { calls.push(['selection',x]); return {message:'seçim kaydedildi'}; },
    setUiMode: async m => { calls.push(['mode',m]); st.uiMode=m; }
  }});
  let r = await say('/mod_oto');
  assert.match(r.text, /19/);
  assert.match(r.text, /Strateji 19/);
  r = await say('1,2,19'); assert.match(r.text, /15m ve üzeri/);
  r = await say('15m,30m,1h,4h'); assert.match(r.text, /kapasite/i);
  r = await say('4'); assert.match(r.text, /henüz kaydedilmedi/);
  r = await say('/mod_onay');
  assert.match(r.text, /Motor BAŞLATILMADI/);
  assert.deepEqual(calls[0][1], {strategyIds:['s1','s2','s19'],timeframes:['15m','30m','1h','4h']});
  assert.deepEqual(calls[1], ['mode','autonomous']);
  assert.equal(st.running,false);
});

test('otonom mum sihirbazı 1m/3m/5m ve geçersiz kapasiteyi reddeder', async () => {
  const strategies = [{id:'s1',name:'Bir'}];
  const { say } = make({ deps:{ listStrategies:()=>strategies } });
  await say('/mod_oto'); await say('1');
  let r = await say('5m'); assert.match(r.text, /otonomda kullanılamaz/);
  r = await say('15m'); assert.match(r.text, /kapasite/i);
  r = await say('60'); assert.match(r.text, /1, 2, 4, 8, 16 veya 32/);
});

test('/oto_durdur iki aşamalı onay ister; onay callbacki bir kez çağrılır', async () => {
  const calls=[];
  const { say } = make({ status:{ uiMode:'autonomous', mode:'live', running:true, autonomous:{active:true,stopping:false} }, deps:{
    stopAutonomousImmediate: async()=>{calls.push('handoff'); return {message:'stoplar doğrulandı'};}
  }});
  let r=await say('/oto_durdur');
  assert.match(r.text,/HENÜZ UYGULANMADI/);
  assert.deepEqual(calls,[]);
  r=await say('/oto_durdur_onay');
  assert.match(r.text,/Otonomdan Manuel moda devredildi/);
  assert.deepEqual(calls,['handoff']);
  r=await say('/oto_durdur_onay');
  assert.match(r.text,/onayı yok veya süresi doldu/);
  assert.deepEqual(calls,['handoff']);
});

test('canlı /oto_basla önce açık onay ister; onaysız motor başlamaz', async () => {
  const calls=[];
  const { say, st } = make({ status:{mode:'live',uiMode:'autonomous',running:false,settings:{maxConcurrentPositions:4},autonomous:{active:false,stopping:false},autonomousSelection:{strategies:[{id:'a',name:'A',selected:true}],timeframes:[{id:'15m',selected:true,locked:false}]}}, deps:{
    startAutonomous: async x=>{calls.push(x);st.running=true;return {message:'started'};}
  }});
  let r=await say('/oto_basla 4');
  assert.match(r.text,/HENÜZ BAŞLATILMADI/);
  assert.deepEqual(calls,[]);
  r=await say('/oto_basla_onay');
  assert.match(r.text,/Canlı otonom sistem başlatıldı/);
  assert.deepEqual(calls,[{count:4}]);
});

test('/saglik /tarama /risk salt-okunur sistem ve otonom durumunu raporlar', async () => {
  const { say, st } = make({ status: {
    mode: 'live', uiMode: 'autonomous', running: true, safeToTrade: false, lockReason: 'mutabakat bekleniyor',
    lastTickAt: Date.now() - 120000, killSwitch: true, positions: 2,
    settings: { dailyLossLimitPct: 3, killSwitchLossPct: 8, maxConcurrentPositions: 4, maxTradeQuote: 50 },
    autonomous: { active: true, status: 'running', scanned: 124, lastScanAt: new Date().toISOString(), message: '124 aday tarandı', managedSymbols: ['BTC/USDT'], candidates: [{ symbol: 'ETH/USDT', status: 'Alım sinyali', eligible: true }] }
  }, deps: { getNotifyInfo: () => ({ telegram: true, queued: 1, pending: 2, channels: { telegram: { failures: 1, lastError: 'network timeout' } } }) } });
  const health = await say('/saglik');
  assert.match(health.text, /SİSTEM SAĞLIĞI/);
  assert.match(health.text, /Bekleyen kritik bildirim: 2/);
  assert.match(health.text, /KİLİTLİ/);
  const scan = await say('/tarama');
  assert.match(scan.text, /124/);
  assert.match(scan.text, /ETH\/USDT/);
  assert.match(scan.text, /son taramanın kayıtlı önizlemesi/);
  const risk = await say('/risk');
  assert.match(risk.text, /Günlük zarar limiti: 3%/);
  assert.match(risk.text, /KİLİTLİ/);
  assert.equal(st.running, true);
});

test('/tarama sayfalı evren listesini 50 pariteyle böler', async () => {
  const symbols = Array.from({ length: 123 }, (_, i) => `COIN${i}/USDT`);
  const { say } = make({ status: { autonomous: { universeSymbols: symbols, scanned: 123, universeSize: 123, scanMode: 'all', actionCounts: {} } } });
  const first = await say('/tarama 1');
  assert.match(first.text, /sayfa 1\/3/);
  assert.match(first.text, /COIN0\/USDT/);
  assert.match(first.text, /COIN49\/USDT/);
  assert.doesNotMatch(first.text, /COIN50\/USDT/);
  const last = await say('/tarama 3');
  assert.match(last.text, /sayfa 3\/3/);
  assert.match(last.text, /COIN122\/USDT/);
});

test('Telegram komutları denetim kaydına ham argümanlar olmadan yazılır', async () => {
  const audit = [];
  const { say } = make({ deps: { auditCommand: async (entry) => audit.push(entry) } });
  await say('/durum');
  await say('/bakiye');
  assert.equal(audit.length, 2);
  assert.equal(audit[0].command, '/durum');
  assert.equal(audit[1].command, '/bakiye');
  assert.ok(audit.every((entry) => entry.at && entry.outcome === 'handled'));
  assert.ok(audit.every((entry) => !('args' in entry) && !('chatId' in entry)));
});

test('/acil_durdur motoru hemen durdurur ve mevcut borsa emirlerini değiştirmediğini açıklar', async () => {
  let called = '';
  const { say, st } = make({
    status: { mode: 'live', running: true, positions: 2, autonomous: { active: true } },
    deps: { emergencyStopBot: async (reason) => { called = reason; st.running = false; return { message: 'Acil durdurma kaydedildi.' }; } }
  });
  const first = await say('/acil_durdur');
  assert.equal(called, '', 'ilk komut yalnız onay ister, motoru durdurmaz');
  assert.match(first.text, /henüz UYGULANMADI/);
  const r = await say('/acil_onayla');
  assert.equal(called, 'Telegram /acil_durdur komutu');
  assert.match(r.text, /ACİL DURDURMA UYGULANDI/);
  assert.match(r.text, /Borsaya daha önce gönderilmiş emirler iptal edilmedi/);
  assert.match(r.text, /otomatik çıkış yönetimi durur/);
});

test('/acil_durdur yapılandırılmamışsa yanlış başarı bildirmez', async () => {
  const { say } = make({ status: { running: true, positions: 1 } });
  await say('/acil_durdur');
  const r = await say('/acil_onayla');
  assert.match(r.text, /Acil durdurma uygulanamadı/);
});

test('/alim_durdur ve /alim_baslat yeni girişleri duraklatır/açar; callback sonucu doğrulanır', async () => {
  const calls = [];
  const { say } = make({ deps: { setEntriesPaused: async (paused) => { calls.push(paused); return { message: 'Ayar kalıcı olarak kaydedildi.' }; } } });
  let r = await say('/alim_durdur');
  assert.deepEqual(calls, [true]);
  assert.match(r.text, /Yeni alışlar durduruldu/);
  assert.match(r.text, /Açık pozisyonların satış, stop ve risk yönetimi devam ediyor/);
  r = await say('/alim_baslat');
  assert.deepEqual(calls, [true, false]);
  assert.match(r.text, /Yeni alışlar yeniden açıldı/);
  const unavailable = await make({}).say('/alim_durdur');
  assert.match(unavailable.text, /yapılandırılmadı/);
});

test('/alim_mod, /alim_bekleyen, /alim_onay ve /alim_reddet komutları açıkça doğrulanır', async () => {
  const calls = [];
  const { say } = make({
    deps: {
      setEntryApprovalMode: async (mode) => { calls.push(['mode', mode]); return { message: 'kaydedildi' }; },
      listPendingEntries: async () => [{ id: 'BTC-abc', symbol: 'BTC/USDT', timeframe: '15m', price: 100, expiresAt: NOW + 60000 }],
      approvePendingEntry: async (id) => { calls.push(['approve', id]); return { ok: true, item: { symbol: 'BTC/USDT' } }; },
      rejectPendingEntry: async (id) => { calls.push(['reject', id]); return { ok: true, item: { symbol: 'BTC/USDT' } }; }
    }
  });
  assert.match((await say('/alim_mod onaylı')).text, /TELEGRAM ONAYLI/);
  assert.match((await say('/alim_bekleyen')).text, /BTC-abc/);
  assert.match((await say('/alim_onay BTC-abc')).text, /motor sinyali.*yeniden doğrular/i);
  assert.match((await say('/alim_reddet BTC-abc')).text, /alım sinyali reddedildi/i);
  assert.deepEqual(calls, [['mode', 'telegram'], ['approve', 'BTC-abc'], ['reject', 'BTC-abc']]);
});

test('/rapor haftalik ve strateji parametreleri ayrı performans raporu üretir', async () => {
  const now = Date.now();
  const trades = [{ symbol: 'BTC/USDT', strategyId: 'rsi_ema_macd', pnl: 5, pnlPct: 2, commissionTotal: 0.1, closedAt: new Date(now).toISOString() }];
  const { say } = make({ status: { trades, holdings: [{ symbol: 'ETH/USDT', unrealizedPnl: 3 }] } });
  assert.match((await say('/rapor haftalik')).text, /HAFTALIK PERFORMANSI/);
  assert.match((await say('/rapor strateji')).text, /STRATEJİ PERFORMANSI/);
});

test('/sessiz HH:MM-HH:MM günlük sessiz saat planını kaydeder; kapat komutu devre dışı bırakır', async () => {
  const calls=[]; const {say}=make({deps:{muteNotifications:()=>Date.now()+3600000,unmuteNotifications:()=>{},setQuietHours:(a,b,on)=>{calls.push([a,b,on]);return {start:a,end:b,enabled:on};},getNotifyInfo:()=>({quietHours:{enabled:true,start:'22:00',end:'08:00'}})}});
  assert.match((await say('/sessiz 22:00-08:00')).text,/Her gün 22:00-08:00/);
  assert.match((await say('/sessiz durum')).text,/22:00-08:00/);
  await say('/sessiz kapat');
  assert.deepEqual(calls,[['22:00','08:00',true],['22:00','08:00',false]]);
});
