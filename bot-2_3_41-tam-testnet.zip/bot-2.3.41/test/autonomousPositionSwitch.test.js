'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { shouldDeferConfigSwitch, buildPositionManagementUpdate } = require('../src/autonomousPositionSwitch');

test('open position always defers pair-level strategy/timeframe changes', () => {
  const result = shouldDeferConfigSwitch({
    hasOpenPosition: true,
    activeStrategyId: 'trend_regime',
    activeTimeframe: '4h',
    candidate: { action: 'buy', strategyId: 'bollinger', timeframe: '1h' }
  });
  assert.deepEqual(result, { defer: true, reason: 'position-open' });
});

test('flat position permits a qualified different strategy/timeframe candidate', () => {
  const result = shouldDeferConfigSwitch({
    hasOpenPosition: false,
    activeStrategyId: 'trend_regime',
    activeTimeframe: '4h',
    candidate: { action: 'buy', strategyId: 'bollinger', timeframe: '1h' }
  });
  assert.deepEqual(result, { defer: false, reason: 'flat-position-qualified-candidate' });
});

test('same config and malformed/non-buy candidates are not applied', () => {
  assert.equal(shouldDeferConfigSwitch({
    hasOpenPosition: false,
    activeStrategyId: 'trend_regime', activeTimeframe: '4h',
    candidate: { action: 'buy', strategyId: 'trend_regime', timeframe: '4h' }
  }).reason, 'same-config');
  for (const candidate of [null, {}, { action: 'hold', strategyId: 'bollinger', timeframe: '1h' },
    { action: 'buy', strategyId: '', timeframe: '1h' }]) {
    assert.equal(shouldDeferConfigSwitch({ hasOpenPosition: false, candidate }).defer, true);
  }
});


test('position management switch preserves entry metadata and existing protective orders', () => {
  const pair = { strategyId: 'rsi_ema_macd', timeframe: '1h', params: { old: true } };
  const position = { entryPrice: 100, quantity: 2, stopOrderId: 'existing-stop', tpOrderId: null, stopPrice: 90 };
  const update = buildPositionManagementUpdate({
    pair, position,
    selected: { strategyId: 'trend_regime', timeframe: '4h', score: 2.5, params: { stopLossPct: 3 } },
    now: '2026-10-31T12:00:00.000Z'
  });
  assert.equal(update.pair.strategyId, 'trend_regime');
  assert.equal(update.pair.timeframe, '4h');
  assert.equal(update.position.entryStrategyId, 'rsi_ema_macd');
  assert.equal(update.position.entryTimeframe, '1h');
  assert.equal(update.position.activeManagementStrategyId, 'trend_regime');
  assert.equal(position.stopOrderId, 'existing-stop');
  assert.equal(position.stopPrice, 90);
  assert.equal(position.quantity, 2);
});

test('position management switch does not change an already matching configuration', () => {
  assert.equal(buildPositionManagementUpdate({
    pair: { strategyId: 'trend_regime', timeframe: '4h' },
    position: { quantity: 1 },
    selected: { strategyId: 'trend_regime', timeframe: '4h', score: 1 }
  }), null);
});
