const test = require('node:test');
const assert = require('node:assert/strict');
const store = require('../src/store');

test('fresh install starts without hard-coded coin pairs and keeps 150 USDT only as Paper seed', () => {
  const state = store.defaultState({ freshInstall: true });
  assert.deepEqual(Object.keys(state.pairs), []);
  assert.equal(state.settings.paperStartingBalance, 150);
  assert.equal(state.settings.mode, 'paper');
  assert.equal(state.paper.cashByAsset.USDT, 150);
});

test('legacy/defaultState template remains available for existing test fixtures', () => {
  const state = store.defaultState();
  assert.ok(state.pairs['BTC/USDT']);
  assert.ok(state.pairs['ETH/USDT']);
});
