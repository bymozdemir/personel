'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { OrderManager } = require('../src/orderManager');

function mk(open, calls) {
  const orders = {};
  for (let i = 1; i <= 5; i++) orders[`stop-${i}`] = { clientOrderId: `stop-${i}`, symbol: `A${i}/USDT`, side: 'sell', status: 'NEW', exchangeOrderId: String(i), executedQty: 0, quoteQty: 0, amount: 1, uncertain: false, meta: { role: 'protective-stop' } };
  const exchange = {
    id: 'binance', capabilities: { orderQuery: true, openOrdersQuery: true, clientOrderId: true, liveTrading: true },
    fetchOpenOrders: async () => open,
    getOrder: async (sym, id, cid) => { calls.push(cid); return { orderId: id, clientOrderId: cid, symbol: sym.replace('/', ''), side: 'SELL', status: 'NEW', origQty: '1', executedQty: '0', cummulativeQuoteQty: '0' }; }
  };
  const state = { liveOrders: orders, settings: {} };
  const om = new OrderManager({ exchange, state, store: { save() {} } });
  om.assertLiveCapability = () => {};
  return om;
}

test('refreshPending: açık ve değişmemiş NEW emirler tek tek sorgulanmaz', async () => {
  const calls = [];
  const open = [1, 2, 3, 4].map((i) => ({ orderId: String(i), status: 'NEW', executedQty: 0 }));
  const om = mk(open, calls);
  const r = await om.refreshPending();
  assert.deepEqual(calls, ['stop-5']); // yalnızca açık listede olmayan emir sorgulanır
  assert.equal(r.failed, 0);
});

test('refreshPending: açık liste alınamazsa eski davranış (hepsi sorgulanır)', async () => {
  const calls = [];
  const om = mk([], calls);
  om.exchange.fetchOpenOrders = async () => { throw new Error('ağ'); };
  await om.refreshPending();
  assert.equal(calls.length, 5);
});


test('refreshPending: çok sayıda belirsiz emir sınırlı paralellikle sorgulanır (mutabakat kuyruğu seri kilitlenmez)', async () => {
  const calls = [];
  const om = mk([], calls);
  let active = 0, peak = 0;
  om.exchange.getOrder = async (sym, id, cid) => {
    active++; peak = Math.max(peak, active);
    await new Promise((resolve) => setTimeout(resolve, 15));
    active--; calls.push(cid);
    return { orderId: id, clientOrderId: cid, symbol: sym.replace('/', ''), side: 'SELL',
      status: 'NEW', origQty: '1', executedQty: '0', cummulativeQuoteQty: '0' };
  };
  const result = await om.refreshPending({ concurrency: 3 });
  assert.equal(result.failed, 0);
  assert.equal(calls.length, 5);
  assert.equal(peak, 3);
});
