'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createHourlyReport, buildHourlyData, hourlyText, problems } = require('../src/hourlyReport');
const { decide, parseEnv, messageFor } = require('../scripts/bekci');

const NOW = Date.UTC(2026, 10, 1, 18, 5, 0); // Istanbul 21:05

function baseOk(extra = {}) {
  return { mode: 'live', running: true, killSwitch: false, safeToTrade: true, lastTickAt: NOW - 60000, quoteAsset: 'USDT', equity: 123456.7,
    autonomous: { active: true, lastScanAt: NOW - 120000, message: '482/482 uygun USDT paritesi analiz edildi (all); 55/32 coin yönetiliyor. Testnet' }, errorCount: 0, warnCount: 2, lastError: null, ...extra };
}

test('saat başı rapor: son 1 saat alım/satış/sahiplenme ve pozisyon dağılımı doğru sayılır', () => {
  const state = {
    settings: { mode: 'live' },
    live: {
      rotation: { count: 9 },
      positions: {
        'A/USDT': { adopted: true, adoptedAt: new Date(NOW - 10 * 60000).toISOString() },
        'B/USDT': { adopted: true, adoptedAt: new Date(NOW - 5 * 3600000).toISOString() },
        'C/USDT': { adopted: false }
      },
      trades: [{ closedAt: new Date(NOW - 20 * 60000).toISOString(), pnl: 5 }, { closedAt: new Date(NOW - 40 * 60000).toISOString(), pnl: -2 }, { closedAt: new Date(NOW - 3 * 3600000).toISOString(), pnl: 99 }]
    },
    liveOrders: {
      o1: { side: 'buy', status: 'FILLED', createdAt: new Date(NOW - 30 * 60000).toISOString() },
      o2: { side: 'buy', status: 'CANCELED', createdAt: new Date(NOW - 30 * 60000).toISOString() },
      o3: { side: 'buy', status: 'FILLED', createdAt: new Date(NOW - 4 * 3600000).toISOString() },
      o4: { side: 'sell', status: 'FILLED', createdAt: new Date(NOW - 30 * 60000).toISOString() }
    }
  };
  const d = buildHourlyData({ base: baseOk(), state, nowMs: NOW });
  assert.deepEqual(d.positions, { total: 3, adopted: 2, own: 1 });
  assert.equal(d.lastHour.buys, 1); assert.equal(d.lastHour.sells, 2); assert.equal(d.lastHour.pnl, 3); assert.equal(d.lastHour.adoptions, 1);
  assert.equal(d.rotationToday, 9); assert.equal(d.autonomous.managed, '55/32');
  const text = hourlyText(d);
  assert.match(text, /SAAT BAŞI RAPORU/); assert.match(text, /Sağlıklıyım, çalışıyorum/); assert.match(text, /55\/32/); assert.match(text, /alım 1 \| satış 2/);
  assert.deepEqual(problems(d), []);
});

test('saat başı rapor: sorun varsa başlıkta DİKKAT yazar', () => {
  const d = buildHourlyData({ base: baseOk({ killSwitch: true, safeToTrade: false, lastTickAt: NOW - 30 * 60000 }), state: { settings: { mode: 'live' }, live: {} }, nowMs: NOW });
  const text = hourlyText(d);
  assert.match(text, /DİKKAT/); assert.match(text, /kill switch/); assert.match(text, /kilitli/); assert.match(text, /30 dk önce/);
  assert.doesNotMatch(text, /Sağlıklıyım/);
});

test('saat başı rapor: saatin ilk 20 dakikasında saat başına bir kez gönderilir; HOURLY_REPORT=0 kapatır', async () => {
  let now = NOW; const sent = [];
  const notifier = { status: () => ({ telegram: true }), send: async (body, opt) => { sent.push({ body, opt }); return { telegram: true }; } };
  const state = {};
  const getData = (nowMs) => buildHourlyData({ base: baseOk(), state: { settings: { mode: 'live' }, live: {} }, nowMs });
  const hr = createHourlyReport({ getData, notifier, state, store: { save() {} }, nowFn: () => now, env: {}, logger: { warn() {} } });
  assert.equal(await hr.tick(), true); assert.equal(sent.length, 1); assert.equal(sent[0].opt.priority, 'quiet');
  now = NOW + 5 * 60000; assert.equal(await hr.tick(), false, 'aynı saat ikinci rapor yok');
  now = NOW + 30 * 60000; assert.equal(await hr.tick(), false, 'saatin ilk 20 dakikası dışında gönderilmez');
  now = NOW + 60 * 60000; assert.equal(await hr.tick(), true, 'yeni saat'); assert.equal(sent.length, 2);
  const off = createHourlyReport({ getData, notifier, state: {}, store: { save() {} }, nowFn: () => NOW, env: { HOURLY_REPORT: '0' } });
  assert.equal(await off.tick(), false); assert.equal(off.isEnabled(), false);
});

test('saat başı rapor: gönderim başarısızsa aynı saat içinde sınırlı yeniden denenir, sonra durur', async () => {
  let calls = 0; const state = {};
  const notifier = { status: () => ({ telegram: true }), send: async () => { calls += 1; return { telegram: false }; } };
  const hr = createHourlyReport({ getData: (n) => buildHourlyData({ base: baseOk(), state: { settings: { mode: 'live' } }, nowMs: n }), notifier, state, store: { save() {} }, nowFn: () => NOW, env: {}, logger: { warn() {} } });
  for (let i = 0; i < 6; i++) await hr.tick();
  assert.equal(calls, 3); assert.equal(state.notifyMeta?.lastHourlyReportKey, undefined);
});

test('bekçi: nabız eskirse alarm, tekrar hatırlatma, geri gelince haber; temiz kapanışta sessiz', () => {
  const T = 1_000_000_000_000;
  const fresh = { lastAliveAt: T - 60000, cleanExit: false };
  const stale = { lastAliveAt: T - 6 * 60000, cleanExit: false };
  assert.equal(decide({ now: T, marker: fresh }).action, null);
  assert.equal(decide({ now: T, marker: stale }).action, 'dead');
  assert.equal(decide({ now: T, marker: stale, prev: { alerted: true, lastAlertAt: T - 10 * 60000 } }).action, null);
  assert.equal(decide({ now: T, marker: stale, prev: { alerted: true, lastAlertAt: T - 31 * 60000 } }).action, 'repeat');
  assert.equal(decide({ now: T, marker: fresh, prev: { alerted: true, lastAlertAt: T - 60000 } }).action, 'recovered');
  assert.equal(decide({ now: T, marker: { ...stale, cleanExit: true } }).action, null);
  assert.equal(decide({ now: T, marker: null }).action, null);
  assert.match(messageFor('dead', 6 * 60000), /NABZI KESİLDİ.*6 dakika/);
  assert.deepEqual(parseEnv('A=1\n# x\nTELEGRAM_CHAT_ID="42"\nB = "q"'), { A: '1', TELEGRAM_CHAT_ID: '42', B: 'q' });
});
