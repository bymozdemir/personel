'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const approval = require('../src/entryApproval');
function state() { return { autonomous: { uiMode: 'autonomous', entryApprovalMode: 'telegram' } }; }
test('Telegram onayı yalnızca aynı sembol ve aynı kapanmış mum için tek kullanımlıdır', () => {
  const s = state(); const now = 1_800_000_000_000;
  const q = approval.request(s, { symbol: 'BTC/USDT', candleT: 123, price: 100, reason: 'test', now });
  assert.equal(q.created, true);
  assert.equal(approval.request(s, { symbol: 'BTC/USDT', candleT: 123, price: 100, now }).created, false);
  const a = approval.approve(s, q.item.id, now + 1000);
  assert.equal(a.ok, true);
  assert.equal(approval.consume(s, 'BTC/USDT', 124, now + 1100), false);
  assert.equal(approval.consume(s, 'BTC/USDT', 123, now + 1200), false);
  const q2 = approval.request(s, { symbol: 'ETH/USDT', candleT: 456, price: 20, now });
  assert.equal(approval.approve(s, q2.item.id, now + 1000).ok, true);
  assert.equal(approval.consume(s, 'ETH/USDT', 456, now + 1100), true);
  assert.equal(approval.consume(s, 'ETH/USDT', 456, now + 1200), false);
});
test('süresi dolan onay talebi kabul edilmez', () => {
  const s=state(), now=100000;
  const q=approval.request(s,{symbol:'SOL/USDT',candleT:10,price:2,now});
  assert.equal(approval.approve(s,q.item.id,now+approval.TTL_MS+1).ok,false);
  const q2=approval.request(s,{symbol:'ADA/USDT',candleT:11,price:1,now});
  assert.equal(approval.reject(s,q2.item.id,now+approval.TTL_MS+1).ok,false);
});
test('ilk 8 karakteri aynı olan çiftler farklı onay kimliği alır ve doğru çift onaylanır', () => {
  const s = state(), now = 1_800_000_000_000;
  const a = approval.request(s, { symbol: '1000SATS/USDT', candleT: 99, price: 1, now });
  const b = approval.request(s, { symbol: '1000SATS/USDC', candleT: 99, price: 1, now });
  assert.notEqual(a.item.id, b.item.id);
  assert.equal(approval.approve(s, b.item.id, now + 1).item.symbol, '1000SATS/USDC');
  assert.equal(approval.consume(s, '1000SATS/USDT', 99, now + 2), false);
  assert.equal(approval.consume(s, '1000SATS/USDC', 99, now + 2), true);
});
