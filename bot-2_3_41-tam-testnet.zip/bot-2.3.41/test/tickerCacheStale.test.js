'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const BinanceAdapter = require('../src/exchanges/binance');

function tickerRows() {
  return [{ symbol: 'ABCUSDT', lastPrice: '1', priceChangePercent: '2', quoteVolume: '3', highPrice: '1', lowPrice: '1' }];
}

test('fetchAllTickers24h: kısa önbellek süresinde aynı başarılı sonuç döner', async () => {
  const ex = new BinanceAdapter({ environment: 'testnet', tickerCacheTtlMs: 5000 });
  let calls = 0;
  ex._publicGet = async () => { calls++; return tickerRows(); };

  const first = await ex.fetchAllTickers24h();
  const second = await ex.fetchAllTickers24h();
  assert.equal(calls, 1);
  assert.deepEqual(second, first);
  assert.notEqual(second, first, 'çağırana önbelleğin iç dizisi verilmemeli');

  ex._tickers24hCache.at -= 6000;
  await ex.fetchAllTickers24h();
  assert.equal(calls, 2, 'önbellek süresi dolunca yeni REST isteği yapılmalı');
});

test('fetchAllTickers24h: süresi dolmuş önbellek ağ hatasında kullanılmaz', async () => {
  const ex = new BinanceAdapter({ environment: 'testnet', tickerCacheTtlMs: 5000 });
  let fail = false;
  ex._publicGet = async () => {
    if (fail) throw new Error('zaman aşımı');
    return tickerRows();
  };

  const first = await ex.fetchAllTickers24h();
  ex._tickers24hCache.at -= 6000;
  fail = true;
  await assert.rejects(() => ex.fetchAllTickers24h(), /zaman aşımı/);
  assert.deepEqual(ex._tickers24hCache.rows, first, 'eski veri yalnızca önbellekte kalır; çağırana verilmez');
});

test('fetchAllTickers24h: eşzamanlı çağrılar tek REST isteğini paylaşır', async () => {
  const ex = new BinanceAdapter({ environment: 'testnet', tickerCacheTtlMs: 5000 });
  let calls = 0;
  let release;
  ex._publicGet = async () => {
    calls++;
    await new Promise((resolve) => { release = resolve; });
    return tickerRows();
  };

  const aPromise = ex.fetchAllTickers24h();
  const bPromise = ex.fetchAllTickers24h();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(calls, 1);
  release();
  const [a, b] = await Promise.all([aPromise, bPromise]);
  assert.deepEqual(a, b);
  assert.equal(calls, 1);
});

test('fetchAllTickers24h: bozuk veya boş yanıt başarılı önbelleğe yazılmaz', async () => {
  const ex = new BinanceAdapter({ environment: 'testnet' });
  ex._publicGet = async () => [];
  await assert.rejects(() => ex.fetchAllTickers24h(), /kullanılabilir USDT paritesi/);
  assert.equal(ex._tickers24hCache, undefined);
});
