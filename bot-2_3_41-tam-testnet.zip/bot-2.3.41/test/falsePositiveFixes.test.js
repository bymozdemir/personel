'use strict';
// 2.3.30 regresyonları: sahte kill switch, çökme sonrası kopya 'external' emir kilidi.
const test = require('node:test');
const assert = require('node:assert/strict');
const eng = require('./chaos/engineChaos');
const multi = require('./chaos/multiChaos');

function quiet(fn) {
  return async () => {
    const saved = { log: console.log, warn: console.warn, error: console.error };
    console.log = console.warn = console.error = () => {};
    try { return await fn(); } finally { Object.assign(console, saved); }
  };
}

test('satış geliri anlık bakiyeye iki kez eklenmez: gerçek zarar yokken kill switch tetiklenmez (eski hatalı tohumlar)', quiet(async () => {
  for (const seed of [52, 68, 101, 164, 236]) {
    const r = await eng.runSeed(seed, { risk: true });
    assert.deepEqual(r.violations, [], `seed=${seed}`);
    assert.equal(r.killed, false, `seed=${seed}`);
  }
}));

test('çökme sonrası kurtarma, borsa kimliği yazılmamış emir için kopya external kayıt açmaz (eski kalıcı kilit tohumları)', quiet(async () => {
  for (const seed of [41, 61, 65, 94]) {
    const r = await multi.runSeed(seed, { crash: true });
    assert.deepEqual(r.violations, [], `seed=${seed}`);
    assert.equal(r.locked, false, `seed=${seed}: ${r.lockReason}`);
  }
}));
