'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const LiveEngine = require('../src/liveEngine');
const scanner = require('../src/autonomousScanner');

test('autonomous live scan adopts existing open positions and switches active manager without touching stop', async () => {
  const original = scanner.scanManagementConfigs;
  let calls = 0;
  scanner.scanManagementConfigs = async ({ symbols, strategyIds, timeframes }) => {
    calls++;
    assert.deepEqual(symbols, ['BTC/USDT']);
    assert.deepEqual(strategyIds, ['trend_regime']);
    assert.deepEqual(timeframes, ['4h']);
    return [{ symbol: 'BTC/USDT', selected: {
      strategyId: 'trend_regime', timeframe: '4h', score: 3.2,
      params: { stopLossPct: 4 }
    } }];
  };
  try {
    const engine = Object.create(LiveEngine.prototype);
    engine.state = {
      autonomous: { active: true, strategyIds: ['trend_regime'], timeframes: ['4h'], managedSymbols: [] },
      settings: { mode: 'live', quoteAsset: 'USDT', pollSeconds: 60, maxMarketSlippagePct: 0.5 },
      killSwitch: null,
      pairs: { 'BTC/USDT': { symbol: 'BTC/USDT', enabled: true, strategyId: 'rsi_ema_macd', timeframe: '1h', params: {} } },
      live: { safeToTrade: true, positions: { 'BTC/USDT': {
        symbol: 'BTC/USDT', quantity: 0.01, entryPrice: 50000,
        stopOrderId: 'existing-stop-1', stopPrice: 47000, strategyId: 'rsi_ema_macd'
      } } }
    };
    engine.exchange = { id: 'binance', quoteAssets: ['USDT'] };
    engine.orderManager = { listPending: () => [] };
    engine.nowFn = () => Date.parse('2026-10-31T12:00:00.000Z');
    engine.lastManagementScanAt = 0;
    engine.managementScanEveryMs = 30 * 60 * 1000;
    engine._safePersist = () => {};
    engine.log = () => {};

    const changed = await engine._refreshAutonomousPositionManagement();
    assert.equal(calls, 1);
    assert.equal(changed.length, 1);
    assert.equal(engine.state.pairs['BTC/USDT'].strategyId, 'trend_regime');
    assert.equal(engine.state.pairs['BTC/USDT'].timeframe, '4h');
    assert.equal(engine.state.pairs['BTC/USDT'].enabled, false);
    const position = engine.state.live.positions['BTC/USDT'];
    assert.equal(position.entryStrategyId, 'rsi_ema_macd');
    assert.equal(position.entryTimeframe, '1h');
    assert.equal(position.activeManagementStrategyId, 'trend_regime');
    assert.equal(position.stopOrderId, 'existing-stop-1');
    assert.equal(position.stopPrice, 47000);
    assert.equal(position.quantity, 0.01);
    assert.deepEqual(engine.state.autonomous.managedSymbols, ['BTC/USDT']);

    await engine._refreshAutonomousPositionManagement();
    assert.equal(calls, 1, 'scan interval prevents repeated heavy strategy scan');
  } finally {
    scanner.scanManagementConfigs = original;
  }
});

test('gevşek (kapısız) seçim eski etiketin yerine geçer, sonra sıkı doğrulanmış profil skora bakılmadan onun yerine geçer; stop değişmez', async () => {
  const original = scanner.scanManagementConfigs;
  let result = { strategyId: 'supertrend', timeframe: '4h', score: 9, params: {}, relaxed: true };
  scanner.scanManagementConfigs = async () => [{ symbol: 'ETH/USDT', selected: result }];
  try {
    const engine = Object.create(LiveEngine.prototype);
    engine.state = {
      autonomous: { active: true, strategyIds: ['rsi_ema_macd', 'trend_regime', 'supertrend', 'ema_cross'], timeframes: ['15m', '1h', '4h'], managedSymbols: [] },
      settings: { mode: 'live', quoteAsset: 'USDT', pollSeconds: 60, maxMarketSlippagePct: 0.5 },
      killSwitch: null,
      pairs: { 'ETH/USDT': { symbol: 'ETH/USDT', enabled: false, autonomousManaged: true, strategyId: 'rsi_ema_macd', timeframe: '1h', params: {} } },
      live: { safeToTrade: true, positions: { 'ETH/USDT': { symbol: 'ETH/USDT', quantity: 1, entryPrice: 2000, stopOrderId: 's1', stopPrice: 1900 } } }
    };
    engine.exchange = { id: 'binance', quoteAssets: ['USDT'] };
    engine.orderManager = { listPending: () => [] };
    engine.nowFn = () => Date.parse('2026-10-31T12:00:00.000Z');
    engine.lastManagementScanAt = 0;
    engine.managementScanEveryMs = 30 * 60 * 1000;
    engine._safePersist = () => {};
    engine.log = () => {};

    await engine._refreshAutonomousPositionManagement({ force: true });
    const pair = engine.state.pairs['ETH/USDT'];
    assert.equal(pair.strategyId, 'supertrend');
    assert.equal(pair.timeframe, '4h');
    assert.equal(pair.managementRelaxed, true);
    assert.equal(engine.state.live.positions['ETH/USDT'].stopOrderId, 's1');
    assert.equal(engine.state.live.positions['ETH/USDT'].stopPrice, 1900);

    result = { strategyId: 'ema_cross', timeframe: '1h', score: 0.5, params: {} };
    await engine._refreshAutonomousPositionManagement({ force: true });
    assert.equal(pair.strategyId, 'ema_cross');
    assert.equal(pair.timeframe, '1h');
    assert.equal(pair.managementRelaxed, false);
  } finally {
    scanner.scanManagementConfigs = original;
  }
});

test('trendFallback: rsi_ema_macd asla varsayılan değil; yalnızca seçili stratejilerden trend seçilir', () => {
  const sel = require('../src/autonomousSelection');
  assert.equal(sel.trendFallback(['rsi_ema_macd', 'supertrend', 'trend_regime']), 'trend_regime');
  assert.equal(sel.trendFallback(['rsi_ema_macd', 'supertrend']), 'supertrend');
  assert.notEqual(sel.trendFallback(['rsi_ema_macd', 'bollinger_reversion']), 'rsi_ema_macd');
});


test('ilk yönetim profili taraması seçimsiz kalan ilk 12 coin üzerinde takılı kalmaz', async () => {
  const original = scanner.scanManagementConfigs;
  const calls = [];
  scanner.scanManagementConfigs = async ({ symbols }) => {
    calls.push([...symbols]);
    return symbols.map((symbol) => ({ symbol, selected: null }));
  };
  try {
    const symbols = Array.from({ length: 25 }, (_, i) => `COIN${String(i + 1).padStart(2, '0')}/USDT`);
    const positions = Object.fromEntries(symbols.map((symbol) => [symbol, {
      symbol, quantity: 1, entryPrice: 10, stopOrderId: `stop-${symbol}`
    }]));
    const pairs = Object.fromEntries(symbols.map((symbol) => [symbol, {
      symbol, enabled: false, strategyId: 'supertrend', timeframe: '1h', params: {}
    }]));
    const engine = Object.create(LiveEngine.prototype);
    engine.state = {
      autonomous: { active: true, strategyIds: ['supertrend', 'trend_regime'], timeframes: ['15m', '1h'], managedSymbols: [] },
      settings: { mode: 'live', quoteAsset: 'USDT', pollSeconds: 60, maxMarketSlippagePct: 0.5, defaultTimeframe: '1h' },
      killSwitch: null, pairs, live: { safeToTrade: true, positions }
    };
    engine.exchange = { id: 'binance', quoteAssets: ['USDT'] };
    engine.orderManager = { listPending: () => [] };
    engine.nowFn = () => Date.parse('2026-11-02T20:00:00.000Z');
    engine.lastManagementScanAt = 0;
    engine.managementScanEveryMs = 30 * 60 * 1000;
    engine.pairSupported = () => true;
    engine._safePersist = () => {};
    engine.log = () => {};

    await engine._refreshAutonomousPositionManagement({ force: true });
    assert.equal(calls[0].length, 12);
    assert.equal(symbols.filter((symbol) => pairs[symbol].managementAttemptedAt).length, 12);

    await engine._refreshAutonomousPositionManagement({ force: true });
    assert.equal(calls[1].length, 12);
    assert.notDeepEqual(calls[1], calls[0]);
    assert.equal(symbols.filter((symbol) => pairs[symbol].managementAttemptedAt).length, 24);

    await engine._refreshAutonomousPositionManagement({ force: true });
    assert.equal(calls[2].length, 1);
    assert.equal(symbols.filter((symbol) => pairs[symbol].managementAttemptedAt).length, 25);

    // İlk değerlendirme kuyruğundan sonra normal tarama da en fazla 12 sembol alır
    // ve kalıcı cursor ile kalan coinlere sırayla ulaşır.
    await engine._refreshAutonomousPositionManagement({ force: true });
    assert.equal(calls[3].length, 12);
    await engine._refreshAutonomousPositionManagement({ force: true });
    assert.equal(calls[4].length, 12);
    assert.notDeepEqual(calls[4], calls[3]);
    await engine._refreshAutonomousPositionManagement({ force: true });
    assert.equal(calls[5].length, 1);
    for (const symbol of symbols) {
      assert.equal(pairs[symbol].managementAttemptStatus, 'no-validated-profile');
      assert.ok(pairs[symbol].managementAttemptedAt);
      assert.equal(positions[symbol].stopOrderId, `stop-${symbol}`);
    }
  } finally {
    scanner.scanManagementConfigs = original;
  }
});

test('2.3.41: yönetim taraması 12\'den fazla pozisyonda sonsuza kadar 2 dakikada bir dönmez; devir bitince 30 dk bekler', async () => {
  const original = scanner.scanManagementConfigs;
  scanner.scanManagementConfigs = async ({ symbols }) => symbols.map((symbol) => ({ symbol, selected: null }));
  try {
    const symbols = Array.from({ length: 25 }, (_, i) => `COIN${String(i + 1).padStart(2, '0')}/USDT`);
    const positions = Object.fromEntries(symbols.map((symbol) => [symbol, { symbol, quantity: 1, entryPrice: 10, stopOrderId: `stop-${symbol}` }]));
    const pairs = Object.fromEntries(symbols.map((symbol) => [symbol, { symbol, enabled: false, strategyId: 'supertrend', timeframe: '1h', params: {} }]));
    const engine = Object.create(LiveEngine.prototype);
    const NOW = Date.parse('2026-11-02T20:00:00.000Z');
    engine.state = {
      autonomous: { active: true, strategyIds: ['supertrend', 'trend_regime'], timeframes: ['15m', '1h'], managedSymbols: [] },
      settings: { mode: 'live', quoteAsset: 'USDT', pollSeconds: 60, maxMarketSlippagePct: 0.5, defaultTimeframe: '1h' },
      killSwitch: null, pairs, live: { safeToTrade: true, positions }
    };
    engine.exchange = { id: 'binance', quoteAssets: ['USDT'] };
    engine.orderManager = { listPending: () => [] };
    engine.nowFn = () => NOW; engine.lastManagementScanAt = 0; engine.managementScanEveryMs = 30 * 60 * 1000;
    engine.pairSupported = () => true; engine._safePersist = () => {}; engine.log = () => {};
    const FAST = NOW - engine.managementScanEveryMs + 2 * 60 * 1000;
    const last = [];
    for (let i = 0; i < 6; i++) { await engine._refreshAutonomousPositionManagement({ force: true }); last.push(engine.lastManagementScanAt); }
    // 1-2. ilk profil kuyruğunda hâlâ seçimsiz sembol var -> hızlı; 3. kuyruk bitti -> normal aralık
    assert.deepEqual(last.slice(0, 3), [FAST, FAST, NOW]);
    // 4-5. periyodik devirde imleç başa dönmedi -> hızlı; 6. devir tamamlandı -> normal aralık (eskiden hep hızlı kalıyordu)
    assert.deepEqual(last.slice(3), [FAST, FAST, NOW]);
  } finally { scanner.scanManagementConfigs = original; }
});
