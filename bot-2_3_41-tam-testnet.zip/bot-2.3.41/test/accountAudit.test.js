'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildReadOnlyAccountAudit, normalizeTickers } = require('../src/accountAudit');

function mock(overrides = {}) {
  const calls = [];
  return {
    id: 'binance',
    environment: 'testnet',
    calls,
    async fetchBalance() {
      calls.push('fetchBalance');
      return {
        USDT: { free: 100, locked: 5 },
        PYTH: { free: 20, locked: 2 },
        ENA: { free: 3, locked: 0 },
        UNKNOWN: { free: 7, locked: 0 }
      };
    },
    async fetchOpenOrders() { calls.push('fetchOpenOrders'); return []; },
    async fetchAllTickers24h() {
      calls.push('fetchAllTickers24h');
      return [
        { symbol: 'PYTH/USDT', lastPrice: 0.5 },
        { symbol: 'ENA/USDT', lastPrice: 1.25 }
      ];
    },
    ...overrides
  };
}

test('ticker map accepts only valid direct USDT prices', () => {
  assert.deepEqual([...normalizeTickers([
    { symbol: 'BTC/USDT', lastPrice: '60000' },
    { symbol: 'ETH/BTC', lastPrice: '0.05' },
    { symbol: 'BAD/USDT', lastPrice: '-1' }
  ])], [['BTC', 60000]]);
});

test('read-only audit uses exchange balances and produces sale preview without orders', async () => {
  const ex = mock();
  const report = await buildReadOnlyAccountAudit(ex, { now: () => new Date('2026-01-01T00:00:00Z') });
  assert.equal(report.readOnly, true);
  assert.equal(report.ordersSubmitted, 0);
  assert.equal(report.freeUSDT, 100);
  assert.equal(report.lockedUSDT, 5);
  assert.equal(report.estimatedEquityUSDT, 119.75);
  assert.deepEqual(report.saleCandidates.map(x => x.asset), ['PYTH', 'ENA', 'UNKNOWN']);
  assert.equal(report.saleCandidates[0].estimatedValueUSDT, 10);
  assert.equal(report.saleCandidates[2].status, 'no_direct_usdt_market');
  assert.deepEqual(ex.calls, ['fetchBalance', 'fetchOpenOrders', 'fetchAllTickers24h']);
});

test('production adapter is rejected before any account call', async () => {
  const ex = mock({ environment: 'production' });
  await assert.rejects(() => buildReadOnlyAccountAudit(ex), /yalnızca Binance Spot Testnet/);
  assert.deepEqual(ex.calls, []);
});

test('balance errors propagate instead of fabricating an empty portfolio', async () => {
  const ex = mock({ async fetchBalance() { throw new Error('bad signature'); } });
  await assert.rejects(() => buildReadOnlyAccountAudit(ex), /bad signature/);
});
