const test = require('node:test');
const assert = require('node:assert/strict');
const { PaperStress, PROFILES, makeRng, profileName } = require('../src/paperStress');
const strategies = require('../src/strategies');
const { flat, makeEngine, onlyPair, store } = require('./helpers');

const withProfile = (name, fn) => {
  const prev = process.env.PAPER_STRESS_PROFILE;
  process.env.PAPER_STRESS_PROFILE = name;
  return Promise.resolve(fn()).finally(() => {
    if (prev === undefined) delete process.env.PAPER_STRESS_PROFILE; else process.env.PAPER_STRESS_PROFILE = prev;
  });
};

function withStrategy(id, evaluate, fn) {
  const reg = strategies.registry;
  const orig = reg[id];
  reg[id] = { ...orig, evaluate };
  return Promise.resolve(fn()).finally(() => { reg[id] = orig; });
}

function liveCandles() {
  const base = flat(300, 100).map((c) => ({ ...c, t: c.t - 3600000 }));
  return base.concat([{ t: Date.now(), o: 100, h: 100, l: 100, c: 100, v: 1 }]);
}

test('varsayilan profil off: hicbir ek etki yok', () => {
  delete process.env.PAPER_STRESS_PROFILE;
  const s = new PaperStress({ settings: {}, rng: makeRng(1) });
  assert.equal(s.name, 'off');
  assert.equal(s.feeMult, 1);
  assert.equal(s.entryExtraSlipPct(), 0);
  assert.equal(s.exitExtraSlipPct('stop-loss'), 0);
  assert.equal(s.rejectEntry(), false);
  assert.equal(s.entryFillFraction(), 1);
  assert.equal(s.failExit(), false);
  assert.equal(s.exitFillFraction(), 1);
});

test('gecersiz profil adi off sayilir', () => {
  assert.equal(profileName({ paperStressProfile: 'cok-kotu' }), 'off');
  assert.equal(profileName({ paperStressProfile: 'PESSIMISTIC' }), 'pessimistic');
});

test('ayni tohum ayni sonuclari verir (tekrarlanabilir)', () => {
  const a = new PaperStress({ settings: { paperStressProfile: 'pessimistic' }, rng: makeRng(42) });
  const b = new PaperStress({ settings: { paperStressProfile: 'pessimistic' }, rng: makeRng(42) });
  for (let i = 0; i < 50; i++) {
    assert.equal(a.entryExtraSlipPct(), b.entryExtraSlipPct());
    assert.equal(a.rejectEntry(), b.rejectEntry());
    assert.equal(a.failExit(), b.failExit());
  }
});

test('profiller daha kotuye gittikce monoton kotulesir', () => {
  const order = ['off', 'realistic', 'pessimistic', 'extreme'];
  for (let i = 1; i < order.length; i++) {
    const lo = PROFILES[order[i - 1]], hi = PROFILES[order[i]];
    assert.ok(hi.feeMult >= lo.feeMult);
    assert.ok(hi.entrySlipPct[1] >= lo.entrySlipPct[1]);
    assert.ok(hi.stopExitSlipPct[1] >= lo.stopExitSlipPct[1]);
    assert.ok(hi.entryRejectProb >= lo.entryRejectProb);
    assert.ok(hi.exitFailProb >= lo.exitFailProb);
  }
});

test('stop benzeri cikis normal cikistan daha fazla kayma alir', () => {
  const s = new PaperStress({ settings: { paperStressProfile: 'pessimistic' }, rng: makeRng(7) });
  let stopSum = 0, normalSum = 0;
  for (let i = 0; i < 200; i++) { stopSum += s.exitExtraSlipPct('stop-loss'); normalSum += s.exitExtraSlipPct('strateji sinyali'); }
  assert.ok(stopSum > normalSum);
});

test('pessimistic profilinde paper alimi daha kotu fiyattan ve daha az miktarla dolar, nakit negatife dusmez', async () => {
  const run = async (profile) => {
    process.env.PAPER_STRESS_SEED = '123';
    return withProfile(profile, async () => {
      const state = store.defaultState();
      state.running = true;
      onlyPair(state);
      const { engine } = makeEngine({ state, exchange: { quoteAssets: ['USDT'], fetchCandles: async () => liveCandles(), fetchSymbolRules: async () => ({ minNotional: 10 }) } });
      await withStrategy('rsi_ema_macd', () => ({ action: 'buy', reason: 't', price: 100 }), async () => { await engine.tick(); });
      return { state, engine };
    });
  };
  const base = await run('off');
  const bad = await run('extreme');
  delete process.env.PAPER_STRESS_SEED;
  const basePos = Object.values(base.state.paper.positions)[0];
  assert.ok(basePos, 'off profilinde pozisyon acilmali');
  const badPos = Object.values(bad.state.paper.positions)[0];
  if (badPos) {
    assert.ok(badPos.entryPrice >= basePos.entryPrice, 'extreme dolum fiyati daha kotu (yuksek) olmali');
    assert.ok(badPos.quantity <= basePos.quantity + 1e-12);
  }
  assert.ok(bad.state.paper.cash >= 0);
});

test('satis reddi pozisyonu acik birakir ve sonraki turda yeniden denenir', async () => {
  await withProfile('off', async () => {
    const state = store.defaultState();
    onlyPair(state);
    state.paper.cash = 0;
    state.paper.positions['BTC/USDT'] = { symbol: 'BTC/USDT', entryPrice: 100, quantity: 1, costQuote: 100, costUSDT: 100, stopPrice: null, highWaterMark: 100 };
    const { engine } = makeEngine({ state });
    engine._stress = new PaperStress({ settings: { paperStressProfile: 'extreme' }, rng: () => 0 }); // rng=0 -> her ret/hata tetiklenir
    process.env.PAPER_STRESS_PROFILE = 'extreme';
    const ok = engine.sellAt('BTC/USDT', state.paper.positions['BTC/USDT'], 100, 'stop-loss');
    delete process.env.PAPER_STRESS_PROFILE;
    assert.equal(ok, false);
    assert.ok(state.paper.positions['BTC/USDT'], 'pozisyon acik kalmali');
    assert.equal(state.paper.cash, 0);
  });
});

test('kismi satis: dolan kisim nakde gecer, kalan acik kalir, sonraki tam satista kar-zarar toplam maliyetle hesaplanir', async () => {
  const state = store.defaultState();
  onlyPair(state);
  state.paper.cash = 0;
  state.settings.paperFeePct = 0;
  state.settings.paperSlippagePct = 0;
  state.paper.positions['BTC/USDT'] = { symbol: 'BTC/USDT', entryPrice: 100, quantity: 10, costQuote: 1000, costUSDT: 1000, stopPrice: null, highWaterMark: 100 };
  const { engine } = makeEngine({ state });
  // 1) kismi satis: rng cagri sirasi failExit, ek kayma, kismi tetik, kismi oran
  const seq = [0.99, 0.5, 0.0, 0.5, 0.5]; // failExit, exitSlip, partialTetik, partialOran
  let i = 0;
  engine._stress = new PaperStress({ settings: { paperStressProfile: 'extreme' }, rng: () => seq[Math.min(i++, seq.length - 1)] });
  process.env.PAPER_STRESS_PROFILE = 'extreme';
  state.settings.paperStressProfile = 'extreme';
  const first = engine.sellAt('BTC/USDT', state.paper.positions['BTC/USDT'], 110, 'strateji');
  assert.equal(first, false);
  const pos = state.paper.positions['BTC/USDT'];
  assert.ok(pos && pos.quantity > 0 && pos.quantity < 10, 'kalan miktar 0 ile 10 arasinda olmali');
  assert.ok(state.paper.cash > 0, 'dolan kisim nakde gecmeli');
  assert.ok(Math.abs((pos.costQuote + pos.partialCost) - 1000) < 1e-9, 'maliyet korunmali');
  // 2) kalan kismi tam sat: stres kapali
  state.settings.paperStressProfile = 'off';
  delete process.env.PAPER_STRESS_PROFILE;
  engine._stress = null;
  const second = engine.sellAt('BTC/USDT', state.paper.positions['BTC/USDT'], 110, 'strateji');
  assert.equal(second, true);
  assert.equal(state.paper.positions['BTC/USDT'], undefined);
  const slip = state.paper.costs.slippage; // kismi satisa uygulanan ek kayma maliyeti
  assert.ok(slip > 0, 'ek kayma maliyete islenmeli');
  assert.ok(Math.abs(state.paper.cash + slip - 1100) < 1e-6, `nakit+kayma 1100 olmali, ${state.paper.cash} + ${slip}`);
  assert.ok(Math.abs(state.paper.trades[0].pnl + slip - 100) < 1e-6, `kar+kayma 100 olmali, ${state.paper.trades[0].pnl}`);
});
