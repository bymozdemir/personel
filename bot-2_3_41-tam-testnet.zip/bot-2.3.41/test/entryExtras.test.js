const test = require('node:test');
const assert = require('node:assert/strict');
const strategies = require('../src/strategies');
const { flat, makeEngine, onlyPair, store } = require('./helpers');
const { validateExtrasPatch, normalizeExtras } = require('../src/entryExtras');
const { checkPairFilters } = require('../src/pairFilters');
const { timeBarrierExit } = require('../src/timeBarrier');

const H = 3600000;
function withStrategy(id, evaluate, fn) {
  const reg = strategies.registry; const orig = reg[id];
  reg[id] = { ...orig, evaluate };
  return Promise.resolve(fn()).finally(() => { reg[id] = orig; });
}
const liveCandles = () => flat(300, 100).map((c) => ({ ...c, t: c.t - H })).concat([{ t: Date.now(), o: 100, h: 100, l: 100, c: 100, v: 1 }]);
const makeState = () => { const st = store.defaultState(); st.running = true; onlyPair(st); return st; };
const exchange = () => ({ quoteAssets: ['USDT'], fetchCandles: async () => liveCandles(), fetchSymbolRules: async () => ({ minNotional: 10 }) });

test('varsayilan ayarlarda ek katmanlar kapali ve alim eskisi gibi acilir', async () => {
  const state = makeState();
  assert.equal(state.settings.protections.enabled, false);
  assert.equal(state.settings.pairFilters.enabled, false);
  assert.equal(state.settings.timeBarrier.enabled, false);
  state.paper.trades = [{ symbol: 'BTC/USDT', closedAt: new Date().toISOString(), pnl: -1, pnlPct: -1, reason: 'stop-loss' }];
  const { engine } = makeEngine({ state, exchange: exchange() });
  await withStrategy('rsi_ema_macd', () => ({ action: 'buy', reason: 't', price: 100 }), () => engine.tick());
  assert.equal(Object.keys(state.paper.positions).length, 1);
});

test('cooldown acikken yakin zamanda kapanan paritede alim engellenir ve karar kaydina yazilir', async () => {
  const state = makeState();
  state.settings.protections = { enabled: true, cooldown: { enabled: true, minutes: 60 }, stoplossGuard: { enabled: false }, maxDrawdown: { enabled: false } };
  state.paper.trades = [{ symbol: 'BTC/USDT', closedAt: new Date().toISOString(), pnl: 1, pnlPct: 1, reason: 'sinyal' }];
  const { engine } = makeEngine({ state, exchange: exchange() });
  await withStrategy('rsi_ema_macd', () => ({ action: 'buy', reason: 't', price: 100 }), () => engine.tick());
  assert.equal(Object.keys(state.paper.positions).length, 0);
  assert.match(state.decisions['BTC/USDT'].blockedBy, /koruma kilidi \(cooldown/);
});

test('cooldown suresi gectiyse alim yapilir', async () => {
  const state = makeState();
  state.settings.protections = { enabled: true, cooldown: { enabled: true, minutes: 60 } };
  state.paper.trades = [{ symbol: 'BTC/USDT', closedAt: new Date(Date.now() - 3 * H).toISOString(), pnl: 1, pnlPct: 1, reason: 'sinyal' }];
  const { engine } = makeEngine({ state, exchange: exchange() });
  await withStrategy('rsi_ema_macd', () => ({ action: 'buy', reason: 't', price: 100 }), () => engine.tick());
  assert.equal(Object.keys(state.paper.positions).length, 1);
});

test('parite filtresi: yetersiz gecmis (yas) alimi engeller', async () => {
  const state = makeState();
  state.settings.pairFilters = { enabled: true, minCandles: 5000 };
  const { engine } = makeEngine({ state, exchange: exchange() });
  await withStrategy('rsi_ema_macd', () => ({ action: 'buy', reason: 't', price: 100 }), () => engine.tick());
  assert.equal(Object.keys(state.paper.positions).length, 0);
  assert.match(state.decisions['BTC/USDT'].blockedBy, /parite filtresi \(age\)/);
});

test('zaman bariyeri: strateji tutsa bile suresi dolmus ve hedefe ulasmamis pozisyon kapanir', async () => {
  const state = makeState();
  state.settings.timeBarrier = { enabled: true, maxHoldBars: 10, minProfitPct: 0.5 };
  state.paper.cash = 50;
  state.paper.positions['BTC/USDT'] = { symbol: 'BTC/USDT', entryPrice: 100, quantity: 1, costUSDT: 100, costQuote: 100, stopPrice: null, highWaterMark: 100, openedAt: new Date(Date.now() - 50 * H).toISOString() };
  const { engine } = makeEngine({ state, exchange: exchange() });
  await withStrategy('rsi_ema_macd', () => ({ action: 'hold', reason: 'bekle', price: 100 }), () => engine.tick());
  assert.equal(Object.keys(state.paper.positions).length, 0);
  assert.match(state.paper.trades[0].reason, /zaman bariyeri/);
});

test('zaman bariyeri kapaliyken ayni pozisyon acik kalir', async () => {
  const state = makeState();
  state.paper.cash = 50;
  state.paper.positions['BTC/USDT'] = { symbol: 'BTC/USDT', entryPrice: 100, quantity: 1, costUSDT: 100, costQuote: 100, stopPrice: null, highWaterMark: 100, openedAt: new Date(Date.now() - 50 * H).toISOString() };
  const { engine } = makeEngine({ state, exchange: exchange() });
  await withStrategy('rsi_ema_macd', () => ({ action: 'hold', reason: 'bekle', price: 100 }), () => engine.tick());
  assert.equal(Object.keys(state.paper.positions).length, 1);
});

test('timeBarrierExit: kar hedefine ulasmis pozisyon cikmaz; gecersiz girdi null', () => {
  const closed = Array.from({ length: 20 }, (_, i) => ({ t: 1000 + i * H, c: 100 }));
  const pos = { openedAt: new Date(1000).toISOString(), entryPrice: 100 };
  const cfg = { enabled: true, maxHoldBars: 10, minProfitPct: 1 };
  assert.equal(timeBarrierExit({ position: pos, closedCandles: closed, price: 103, config: cfg }), null);
  assert.ok(timeBarrierExit({ position: pos, closedCandles: closed, price: 100, config: cfg }));
  assert.equal(timeBarrierExit({ position: { openedAt: 'x', entryPrice: 100 }, closedCandles: closed, price: 100, config: cfg }), null);
});

test('checkPairFilters: hacim ve volatilite kurallari', () => {
  const c = Array.from({ length: 200 }, (_, i) => ({ t: i * H, o: 100, h: 101, l: 99, c: 100, v: 10 }));
  assert.equal(checkPairFilters({ closedCandles: c, timeframeMs: H, config: { enabled: true, minQuoteVolume24h: 1e9 } }).rule, 'volume');
  assert.equal(checkPairFilters({ closedCandles: c, timeframeMs: H, config: { enabled: true, minAtrPct: 5 } }).rule, 'volatility');
  assert.equal(checkPairFilters({ closedCandles: c, timeframeMs: H, config: { enabled: true, maxAtrPct: 0.5 } }).rule, 'volatility');
  assert.equal(checkPairFilters({ closedCandles: c, timeframeMs: H, config: { enabled: true, minQuoteVolume24h: 100, minAtrPct: 0.1, maxAtrPct: 10 } }).ok, true);
  assert.equal(checkPairFilters({ closedCandles: c, timeframeMs: H, config: { enabled: false, minCandles: 99999 } }).ok, true);
});

test('validateExtrasPatch: kismi yama mevcut ayarlarla birlesir, tip hatasi acik hata verir', () => {
  const cur = normalizeExtras({}); 
  const ok = validateExtrasPatch({ protections: { enabled: true, cooldown: { minutes: 30 } } }, cur);
  assert.equal(ok.value.protections.enabled, true);
  assert.equal(ok.value.protections.cooldown.minutes, 30);
  assert.equal(ok.value.protections.cooldown.enabled, true); // mevcut alan korunur
  assert.match(validateExtrasPatch({ protections: 'evet' }, cur).error, /nesne/);
  assert.match(validateExtrasPatch({ timeBarrier: { maxHoldBars: 'on' } }, cur).error, /timeBarrier\.maxHoldBars/);
  assert.match(validateExtrasPatch({ pairFilters: { minAtrPct: NaN } }, cur).error, /sayı/);
  assert.deepEqual(validateExtrasPatch({}, cur).value, {});
});

test('eski state.json (yeni ayar anahtarlari yok) sorunsuz yuklenir ve varsayilanlar kapali kalir', async () => {
  const state = makeState();
  for (const k of ['protections', 'pairFilters', 'timeBarrier', 'forager']) delete state.settings[k];
  const { engine } = makeEngine({ state, exchange: exchange() });
  await withStrategy('rsi_ema_macd', () => ({ action: 'buy', reason: 't', price: 100 }), () => engine.tick());
  assert.equal(Object.keys(state.paper.positions).length, 1);
  assert.equal(state.settings.protections.enabled, false);
  assert.equal(state.settings.forager.enabled, false);
});

test('ciddi kilit Telegram bildirimi gonderir (6 saatte bir), rutin cooldown gondermez', async () => {
  const sent = [];
  const mk = (protections) => {
    const state = makeState();
    state.settings.protections = protections;
    state.paper.trades = [1, 2, 3].map((n) => ({ symbol: 'BTC/USDT', closedAt: new Date(Date.now() - n * 60000).toISOString(), pnl: -1, pnlPct: -1, reason: 'stop-loss' }));
    const { engine } = makeEngine({ state, exchange: exchange() });
    engine.notifier = { send: (text, opts) => { sent.push({ text, opts }); return Promise.resolve({ telegram: true }); }, ping: () => Promise.resolve() };
    return { state, engine };
  };
  const a = mk({ enabled: true, cooldown: { enabled: false }, stoplossGuard: { enabled: true, tradeLimit: 3, lookbackMinutes: 600, lockMinutes: 600 }, maxDrawdown: { enabled: false } });
  await withStrategy('rsi_ema_macd', () => ({ action: 'buy', reason: 't', price: 100 }), () => a.engine.tick());
  assert.equal(sent.length, 1);
  assert.match(sent[0].text, /alım kilidi/);
  assert.equal(sent[0].opts.minIntervalMs, 6 * 3600 * 1000);
  const b = mk({ enabled: true, cooldown: { enabled: true, minutes: 600 }, stoplossGuard: { enabled: false }, maxDrawdown: { enabled: false } });
  sent.length = 0;
  await withStrategy('rsi_ema_macd', () => ({ action: 'buy', reason: 't', price: 100 }), () => b.engine.tick());
  assert.equal(sent.length, 0);
  assert.match(b.state.decisions['BTC/USDT'].blockedBy, /cooldown/);
});

test('sıkı doğrulama: geçersiz/aralık dışı/bilinmeyen alan sessizce varsayılana düşmez, açık hata verir', () => {
  const { validateExtrasPatch } = require('../src/entryExtras');
  const bad = [
    { timeBarrier: { maxHoldBars: 0 } }, { timeBarrier: { maxHoldBars: 1.5 } }, { timeBarrier: { bogus: 1 } },
    { pairFilters: { minAtrPct: 500 } }, { pairFilters: { minCandles: -1 } },
    { forager: { volumeDropPct: 500 } }, { forager: { weights: { volume: -1 } } },
    { protections: { stoplossGuard: { tradeLimit: 0 } } }, { protections: { bogus: true } },
    { protections: { cooldown: { minutes: -5 } } }, { protections: { equityDrawdown: { maxDrawdownPct: 0 } } },
    { volatilitySizing: { minScale: 5 } }, { volatilitySizing: { targetAtrPct: 0 } }
  ];
  for (const patch of bad) assert.ok(validateExtrasPatch(patch, {}).error, JSON.stringify(patch));
  const good = [
    { timeBarrier: { enabled: true, maxHoldBars: 24, minProfitPct: 1 } },
    { pairFilters: { enabled: true, minAtrPct: 0.3, maxAtrPct: 8 } },
    { forager: { enabled: true, volumeDropPct: 25, weights: { volume: 2 } } },
    { protections: { enabled: true, cooldown: { minutes: 30, adverseMinutes: 60 }, equityDrawdown: { enabled: true, maxDrawdownPct: 6 } } },
    { volatilitySizing: { enabled: true, targetAtrPct: 2, minScale: 0.5 } }
  ];
  for (const patch of good) assert.equal(validateExtrasPatch(patch, {}).error, undefined, JSON.stringify(patch));
});

test('describeLocks (/api/protections): aktif kilitler pariteye göre döner; kapalıyken boş', () => {
  const { describeLocks } = require('../src/entryExtras');
  const NOW = Date.UTC(2026, 9, 24, 12, 0, 0);
  const trades = [{ symbol: 'BTC/USDT', closedAt: new Date(NOW - 10 * 60000).toISOString(), pnl: 1, pnlPct: 1, reason: 'sinyal' }];
  const pairs = { 'BTC/USDT': {}, 'ETH/USDT': {} };
  const on = describeLocks({ settings: { protections: { enabled: true, cooldown: { enabled: true, minutes: 60 }, stoplossGuard: { enabled: false }, maxDrawdown: { enabled: false } } }, pairs, trades, now: NOW });
  assert.deepEqual(Object.keys(on.locks), ['BTC/USDT']);
  assert.equal(on.locks['BTC/USDT'].rule, 'cooldown');
  assert.equal(on.locks['BTC/USDT'].remainingMinutes, 50);
  const off = describeLocks({ settings: { protections: { enabled: false } }, pairs, trades, now: NOW });
  assert.deepEqual(off.locks, {});
  assert.equal(describeLocks({ settings: {}, pairs: null, trades: null, now: NOW }).enabled, false);
});
