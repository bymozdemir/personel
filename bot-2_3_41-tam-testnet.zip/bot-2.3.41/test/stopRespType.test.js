'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const BinanceAdapter = require('../src/exchanges/binance');

test('Binance STOP_LOSS ve TAKE_PROFIT emirleri newOrderRespType=RESULT ile gönderilir (ACK yanıtı status içermez, bot UNKNOWN sayıp kilitlerdi)', async () => {
  const ex = new BinanceAdapter({});
  const calls = [];
  ex._signedRequest = async (method, path, params) => { calls.push({ method, path, params }); return { orderId: 1, clientOrderId: params.newClientOrderId, symbol: params.symbol, status: 'NEW' }; };
  const stop = await ex.createStopOrder('ZRO/USDT', 'sell', 1.5, 1.6, 0, 'stop-t1');
  await ex.createTakeProfitOrder('ZRO/USDT', 'sell', 1.5, 2.0, 0, 'tp-t1');
  assert.equal(stop.status, 'NEW');
  assert.equal(calls[0].params.type, 'STOP_LOSS'); assert.equal(calls[0].params.newOrderRespType, 'RESULT');
  assert.equal(calls[1].params.type, 'TAKE_PROFIT'); assert.equal(calls[1].params.newOrderRespType, 'RESULT');
});
