# 2.3.40 — otonom yönetim tarama kuyruğu ve dış satış kimliği

## Düzeltmeler
- Otonom pozisyon yönetiminde profil seçimi bulunamayan ilk 12 sembolün tekrar tekrar taranıp sonraki sembolleri aç bırakması düzeltildi. Her sembolün tarama denemesi kalıcı işaretlenir; ilk tarama partileri sırayla ilerler, seçimsiz profiller sonraki periyodik çevrimlerde yeniden denenir.
- Yönetim profili bulunamadığında mevcut strateji, pozisyon miktarı ve koruyucu stop aynen korunur. Deneme durumu kaydedilir ve uyarı sembol başına saatlik sınırlandırılır.
- Yönetim taraması metadata değişiklikleri de diske kaydedilir; seçimsiz sonuçlar veya aynı profilde kalan seçimler yeniden başlatmada kaybolmaz.
- Binance manuel/dış SELL fill kayıtlarında trade ID artık sembolle birlikte tekilleştirilir. Binance trade ID'leri sembol kapsamlı olduğundan farklı piyasalardaki aynı sayısal ID'ler birbirini yutamaz.
- 2.3.39'daki sinyalsiz rotasyon yasağı, dış satış fail-closed mutabakatı ve Telegram 429/backoff düzeltmeleri korunmuştur.

## Bilinçli güvenlik sınırı
Manuel/dış SELL işlemlerinin REST işlem geçmişinden otomatik P/L muhasebesine alınması ve kısmi satış sonrası stopun yeniden kurulması henüz otomatikleştirilmemiştir. Böyle bir olay tespit edilirse canlı işlem kapısı kapalı kalır; doğrulanmamış muhasebe ile işlem devam etmez. Bu alan Testnet'te uçtan uca doğrulanmadan tamamlandı sayılmaz.

## Testler
- Otonom yönetim tarama kuyruğunun 25 sembolde 12+12+1 şeklinde ilerlemesi ve her pozisyonun stopunu koruması için regresyon testi eklendi.
- Aynı sayısal trade ID'nin iki farklı sembolde ayrı kayıt oluşturması ve aynı sembolde tekrarın tekilleştirilmesi için regresyon testi eklendi.
