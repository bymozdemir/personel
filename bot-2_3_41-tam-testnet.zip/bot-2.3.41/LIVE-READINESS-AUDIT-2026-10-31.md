# Live Readiness Audit & Repair — 2026-10-31 (2.3.15)

## Scope and safety
The uploaded archive identified itself as package version 2.3.14 but its root folder was named `bot-2.3.12-recovery-fix`. This repair release is version 2.3.15. No real-account order was sent and no private API key was used.

## Repairs made
- Removed the archive's machine-specific `.env`. It had `LIVE_TRADING_ENABLED=true` and `ALLOW_BINANCE_TESTNET_TRADING=true`; these are not safe distributable defaults.
- Added `.env.example` with Paper-safe defaults. Testnet order permission, Production permission, and every other exchange's live opt-in default to false.
- Corrected Binance Spot's `liveTradingVerified` capability from a hard-coded true to false.
- Corrected the shared exchange verification gate: `ALLOW_*_TRADING=true` is an operator opt-in, not exchange-side proof. It can no longer mark an untested exchange as verified. All real exchanges remain production-locked until verification evidence is deliberately added after sandbox/account testing.
- Binance Spot Testnet remains separately available only when `BINANCE_ENV=testnet`, `ALLOW_BINANCE_TESTNET_TRADING=true`, and `LIVE_TRADING_ENABLED=true` are all explicitly set and the official Testnet hostname is used.
- Fixed the curated test manifest: `test/autonomousState.test.js` existed but was missing from `group6`, causing the batched test runner to stop before running the suite.
- Removed the stale `server.js.orig` backup from the distributable.
- Bumped package metadata to 2.3.15.

## Validation completed
- ZIP source extraction: passed.
- `node scripts/offlinePreflight.js`: passed; 6 critical files present, 19 strategy defaults valid, Paper default, live safety lock closed, no obvious secrets in source resources.
- Focused safety and regression tests: 41/41 passed (`exchangeLiveOptIn`, `exchangeCapabilitySafety`, `mergeRegression`, `liveRecovery`, `binanceTestnetOptIn`).
- The interrupted offline-stop recovery fixture was corrected to identify its simulated order as `STOP_LOSS_LIMIT`; the recovery path now verifies and adopts that existing protective stop rather than treating an untyped SELL as protection.
- `test/autonomousState.test.js`: 2/2 passed.
- `test/httpBodyTimeout.test.js`: 2/2 passed.
- `scripts/liveContractAudit.js`: intentionally exits non-zero because there are unresolved exchange certification blockers. Binance, BTCTurk, Binance TR, Coinbase Exchange, Kraken, Bitstamp, OKX, OKX TR and Bybit TR have code-level contracts but no external validation evidence (YELLOW). Paribu and Midas remain incomplete (RED).
- Curated manifest now matches all 140 test files exactly. Individual-file runs passed for 139/140 files (including all 140 except the server integration test). `test/serverIntegration.test.js` could not run because `express`, `dotenv` and `ws` were not installed; `npm ci` timed out while trying to fetch dependencies in this environment. No full-suite pass is claimed.
- Binance Testnet public connectivity could not be verified in this environment because DNS resolution failed (`EAI_AGAIN`) in the prior attempt. No API-key authentication, private account query, test order, partial-fill recovery, or offline-stop recovery was performed against the real Testnet service.

## Exchange readiness matrix

| Exchange | Code-level contract | External verification | Production/live status |
|---|---|---|---|
| Binance Spot | Present | Not verified in this run | Testnet only after explicit opt-in; Production locked |
| Binance TR | Present | Not verified | Locked |
| BTCTurk | Present | Not verified | Locked |
| OKX | Present | Not verified | Locked |
| OKX TR | Present | Not verified | Locked |
| Bybit TR | Present | Not verified | Locked |
| Kraken | Present | Not verified | Locked |
| Bitstamp | Present | Not verified | Locked |
| Coinbase Exchange | Present | Not verified | Locked |
| Paribu | Incomplete client-order identity/protective stop contract | Not verified | Locked |
| Midas | No verified crypto Spot API adapter | Not verified | Locked |

## Required before real-money production
1. Run the Binance Spot Testnet public preflight on the target phone/server and confirm DNS, HTTPS and clock drift.
2. Create a dedicated Binance Spot Testnet key with only the permissions required by the bot; never paste secrets into chat or put them in a ZIP.
3. Run the read-only account audit and verify balances, open orders, symbol rules, order lookup semantics and permissions.
4. On Testnet only, validate a minimum-size market buy, partial fill, restart/recovery, protective stop placement, stop fill while offline, cancellation race, fee accounting and final balance reconciliation.
5. Only after the evidence is reviewed should a separate production enablement change be considered. Testnet success alone does not prove production behavior or profitability.
6. Each other exchange requires its own sandbox/test account, API contract validation, order identity/recovery tests, stop semantics, precision/minimums, fees, rate limits and restart/reconciliation tests. Do not turn on its `ALLOW_*_TRADING` flag before that work is complete.

## Important
This package is safer than the uploaded archive but is **not certified for real-money production trading**. There is no honest way to certify every exchange without credentials, sandbox access and exchange-side execution evidence. The repaired defaults intentionally prevent accidental live trading.
