# Manuel/Dış Satış Muhasebesi — 2.3.40 durumu

## Tamamlanan güvenlik davranışı
- Botun yerel emir defterinde bulunmayan SELL + TRADE olayları User Data Stream'den yakalanır.
- Kayıtlar sembol + trade ID bazında tekrarsız saklanır.
- Olay, sembol, borsa emir kimliği, trade kimliği, miktar, quote tutarı ve komisyon bilgilerini taşır.
- Tespit edildiğinde canlı işlem kapısı kapanır.
- Sonraki temiz bakiye mutabakatı bu kilidi otomatik açamaz.

## Henüz otomatikleştirilmemiş muhasebe
- REST `myTrades` ile dış emrin tüm fill'lerinin alınması ve eksiksiz olduğunun doğrulanması.
- Fill'lerin pozisyonun maliyet tabanına karşı idempotent biçimde işlenmesi.
- Önce mevcut stop/OCO emrinin güvenli biçimde iptal edilmesi, iptal sırasındaki eşzamanlı fill'lerin hesaba katılması.
- Kısmi dış satış sonrası kalan miktara doğru stopun tekrar kurulması.
- Tam satış sonrası pozisyonun kapatılması ve yalnızca tüm kayıtlar doğrulandıktan sonra inceleme kilidinin kaldırılması.

Bu akışın otomatik yapılması yalnızca `myTrades` çağrısı eklemekten ibaret değildir: dış satış ile mevcut stop emri aynı anda gerçekleşebilir. REST ve User Data Stream olaylarının yarış koşullarında çift muhasebe veya fazla satış (oversell) oluşmaması gerekir. Bu nedenle 2.3.40 bu olayı fail-closed tutar. Otomatik P/L muhasebesi bu pakette tamamlanmış olarak sunulmaz.

## Ön koşul
Bu özellik uçtan uca Testnet senaryolarında kısmi fill, tam fill, komisyonun base/quote/BNB ile alınması, stop iptalinde eşzamanlı fill, ağ kopması ve yeniden başlatma testlerinden geçmeden otomatikleştirilmemelidir.
