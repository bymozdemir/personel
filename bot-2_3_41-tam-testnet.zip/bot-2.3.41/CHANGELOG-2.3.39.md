# 2.3.39 — portföy çıkış güvenliği ve mutabakat kilidi

- Otonom slot/aday rotasyonu üzerinden pozisyon satışı devre dışı bırakıldı. Yeni aday, mevcut pozisyonun kendi satış sinyali değildir. Eski `rotateAdopted()` çağrıları geriye dönük uyumluluk için no-op.
- Tanınmayan manuel/dış SELL fill kayıtları, REST işlem geçmişiyle doğrulanıp muhasebeleştirilene kadar sonraki hesap mutabakatlarında da canlı işlem kapısını kapalı tutar. Önceki sürümde temiz bir sonraki mutabakat bu kilidi yanlışlıkla açabiliyordu.
- Telegram komut polling'i 429 `retry_after` değerine uyar; ağ hatalarında üstel geri çekilme uygular. Sabit 3 saniyelik yeniden sorgu döngüsü kaldırıldı.
- Üretim işlemi izinleri veya Testnet güvenlik kapıları gevşetilmedi.

## Bilinçli güvenlik sınırı

Manuel/dış satışın REST `myTrades` üzerinden otomatik P/L defterine alınması ve kısmi satış sonrası stop yenilemesi bu sürümde tamamlanmış sayılmaz. Bu nedenle tespit edilen dış satış kaydı otomatik olarak temizlenmez; canlı işlemler fail-closed kalır. Bu kayıtlar için otomatik muhasebe, ayrıca uçtan uca Testnet senaryosu ve idempotency doğrulaması gerektirir.

## Test kapsamı

- Rotasyonun satış yapmadığını doğrulayan regresyon testi eklendi.
- Manuel/dış satış inceleme kilidinin temiz mutabakatla açılamadığını doğrulayan regresyon testi eklendi.
- Telegram 429 retry-after ve backoff davranışı kod seviyesinde güncellendi.
