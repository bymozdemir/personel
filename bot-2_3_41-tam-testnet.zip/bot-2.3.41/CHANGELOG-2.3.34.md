# 2.3.34 — Çekirdek+kuyruk tarama (hızlandırma) + 2.3.33 (saat başı rapor, bekçi)

(2.3.33 içeriği bu sürümde de bulunur: bkz. CHANGELOG-2.3.33.md.)

**Sorun:** Otonom tarama her turda tüm evreni (≈482 coin × 4 zaman dilimi) mum çekip stratejilerle değerlendiriyor; telefonda tek tarama 6,25 dk sürüyor (`lastScanDurationMs` = 375246). Tarama motorla aynı Node sürecinde çalıştığı için motorun dakikalık kontrolü gecikebiliyor (SOLV alım sinyali 6 dk geç işlenip "eski sinyal" diye reddedildi).

**Kayıttan çıkan veri:** İki ayrı taramada (2.3.19 ve 2.3.31 dönemi) bulunan 13 alım sinyalinin tamamı hacme göre ilk %24'te (en kötü sıra 114/483). Likit coinlerde yoğunlaşıyor, ama bu yalnızca iki tarama; örneklem küçük.

**Değişiklik (`src/autonomousScanner.js`, `server.js`):**
- Hacme göre ilk `BOT_SCAN_CORE` (varsayılan 160) coin HER turda taranır. Kalan kuyruk `BOT_SCAN_TAIL_SLICES` (varsayılan 4) dilime bölünüp her turda bir dilim taranır; tüm evren 4 turda (≈ 40 dk) bir kez görülür. Tur başına yaklaşık 160 + 80 = 240 coin (≈ %50 daha az iş).
- `BOT_SCAN_CORE=0` eski tam taramaya döner. Açık pozisyonların yönetim taraması etkilenmez.
- Mesaj: "… analiz edildi (çekirdek 160 + kuyruk dilimi 2/4)". Saat başı raporu son tarama süresini gösterir.
- Bir coin kuyruktaysa sinyali en geç 4 tur gecikmeyle görülebilir; bu değiş tokuş bilinçli.

**Testler:** `test/scanTiers.test.js` (2 yeni test) ve `test/hourlyReport.test.js` (5 test). Bu ortamda tüm `test/*.test.js` çalıştırıldı: 1404 testten 1403 geçti. Kalan, gerçek `server.js`'i başlatan `serverIntegration.test.js`; bu ortamda `node_modules` olmadığı için 2.3.32'de de aynı şekilde başarısız. `npm test`'i telefonda çalıştırmanız gerekir.
